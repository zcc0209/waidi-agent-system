@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「知识库Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-A5B45664-3A0D9523"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-A5B45664-3A0D9523","name":"知识库Agent","description":"外贸企业知识库构建（AI Search优选）。7大模块：公司档案结构化+产品百科+FAQ 80-100个+案例库+Schema.org标记（JSON-LD）+阿里AI优选适配+ChatGPT/Perplexity引用优化；4周建设路线图；让买家搜索时AI主动推荐你而不是竞品。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「知识库Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
