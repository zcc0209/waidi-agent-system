@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「知识库Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-A5B45664-3A0D9523"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-A5B45664-3A0D9523","name":"知识库Agent","description":"外贸企业知识库构建（AI Search优选）。7大模块：公司档案结构化+产品百科+FAQ 80-100个+案例库+Schema.org标记（JSON-LD）+阿里AI优选适配+ChatGPT/Perplexity引用优化；4周建设路线图；让买家搜索时AI主动推荐你而不是竞品。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「知识库Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
