# 知识库Agent

外贸企业知识库构建（AI Search优选）。7大模块：公司档案结构化+产品百科+FAQ 80-100个+案例库+Schema.org标记（JSON-LD）+阿里AI优选适配+ChatGPT/Perplexity引用优化；4周建设路线图；让买家搜索时AI主动推荐你而不是竞品。

分类：运营诊断
创建时间：2026-06-17

## 使用方法
1. 在 Accio Work 中新建智能体
2. 将本包内的 SOUL.md 内容粘贴为智能体的 System Prompt
3. 安装 skills/ 目录下的技能包
