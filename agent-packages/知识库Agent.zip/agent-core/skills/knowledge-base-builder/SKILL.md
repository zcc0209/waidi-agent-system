---
name: knowledge-base-builder
description: 外贸企业知识库构建智能体（AI Search 优选）。当用户要求"知识库/知识图谱/AI 优选/被 AI 搜到/结构化数据/企业资料整理/FAQ/产品百科/AI Search/ChatGPT 引用/Google SGE/AI Overview/被 AI 推荐/Rich Snippet/Schema.org/结构化标记"时触发，把企业散落的产品资料/FAQ/认证/案例/公司介绍结构化为 AI 搜索引擎可优选的知识图谱，覆盖阿里国际站 AI 优选 + Google SGE/AI Overview + ChatGPT/Perplexity 引用 + 独立站 Schema.org 标记 + 12 sheet Excel + 诚实提醒。
version: 1.0.0
---

# 外贸企业知识库构建智能体（AI Search 优选版）

> 一句话定位：把你散落在脑子里、Excel 里、聊天记录里的企业知识，整理成 AI 搜索引擎能读懂、会推荐的结构化知识库——让买家搜的时候 AI 把你排在前面。

---

## 触发场景

- "怎么让 AI 搜索优先推荐我们"
- "阿里国际站的 AI 优选怎么做"
- "Google SGE 怎么引用我的产品"
- "我的企业资料很散，帮我整理成知识库"
- "产品 FAQ 怎么结构化"
- "ChatGPT 能搜到我的产品吗"
- "Schema.org 标记怎么加到独立站"

---

## 输入要求

| 项目 | 必须 | 示例 |
|---|---|---|
| 公司基础信息 | ✅ | 名称/品类/年限/规模/认证 |
| 现有产品资料 | ✅ | 产品表/参数表/认证书/图册 |
| 现有 FAQ | - | 客户常问的问题 |
| 官网/独立站 URL | - | 用于 Schema 标记 |
| 阿里国际站链接 | - | 用于 AI 优选分析 |
| 目标市场/语言 | ✅ | 美国英语/欧洲多语 |
| 核心品类 | ✅ | LED 照明 |

---

## 工作流

### Phase 1：AI 搜索引擎生态理解

```
2026 年外贸买家的搜索路径正在变化：

传统路径：
Google 搜关键词 → 点击前 10 结果 → 逐个看网站 → 发询盘

AI 路径（正在替代）：
├── Google AI Overview → 直接给答案 + 推荐 3-5 个品牌
├── ChatGPT/Perplexity → "推荐 3 个中国的 LED 面板灯工厂" → 直接列品牌
├── 阿里国际站 AI 选品 → 买家描述需求 → AI 推荐供应商
├── Amazon Rufus → 买家问问题 → AI 从 Listing 中提取答案
└── Bing Copilot → 综合搜索+推荐

核心逻辑变化：
├── 传统 SEO：优化关键词排名 → 让买家点进来
├── AI 优选：让 AI 理解你的内容 → AI 主动推荐你
└── 区别：AI 不看关键词密度，看内容是否"回答了买家的问题"

你需要做的事：
├── 把企业知识结构化 → 让 AI 能"读懂"
├── 提供权威信号 → 让 AI "信任"你的内容
├── 覆盖买家问题 → 让 AI 在回答时"引用"你
└── 在多平台一致呈现 → 让 AI 交叉验证
```

### Phase 2：知识库 7 大模块

#### 模块 1：公司档案（Company Profile）

```
结构化信息清单（每项都是 AI 可提取的信号）：

├── 基础信息
│   ├── 公司全称（中英文）
│   ├── 成立年份
│   ├── 注册资本
│   ├── 员工人数
│   ├── 工厂面积（m²）
│   ├── 月产能（units/containers）
│   ├── 年出口额
│   └── 出口国家数+Top 5 国家
│
├── 核心能力
│   ├── OEM / ODM / OBM（哪些能做）
│   ├── 自有设备清单（关键设备型号+数量）
│   ├── 研发团队人数+专利数
│   ├── 打样周期
│   └── 最小起订量（按品类）
│
├── 认证墙
│   ├── 质量体系：ISO 9001 / ISO 14001 / IATF 16949
│   ├── 产品认证：CE / UL / FCC / RoHS / REACH / FDA
│   ├── 社会责任：BSCI / Sedex / SA8000
│   ├── 行业特殊：GRS（纺织）/ FSC（木制品）/ HACCP（食品）
│   └── 证书编号+有效期+发证机构
│
└── 联系方式
    ├── 官网 URL
    ├── 阿里国际站链接
    ├── 邮箱（不建议放个人邮箱，用 info@/sales@）
    └── 社媒链接（LinkedIn/YouTube）
```

#### 模块 2：产品百科（Product Knowledge Base）

```
每个产品/品类需要的结构化信息：

├── 产品名称（英文标准名 + 行业通用别名）
│   示例：LED Panel Light = LED Flat Panel = LED Troffer
│
├── 技术参数表（Specifications）
│   ├── 所有参数用标准格式：Key: Value + Unit
│   ├── 示例：Power: 40W | Color Temperature: 4000K ±200K
│   ├── 包含公差范围（AI 可理解精度水平）
│   └── 按国际标准单位（SI）标注
│
├── 应用场景
│   ├── 主要应用：Office / Hospital / School / Retail
│   ├── 安装方式：Recessed / Surface / Suspended
│   └── 适用空间面积（m²）
│
├── 认证与合规
│   ├── 已获认证列表
│   ├── 适用国家/地区
│   └── 能效等级
│
├── 对比信息
│   ├── vs 传统方案（荧光灯 vs LED：节能 60%、寿命 5x）
│   ├── vs 竞品（不点名，用"同品类平均"）
│   └── ROI 计算（投资回报周期）
│
└── FAQ（5-10 个常见问题 + 简洁回答）
    ├── "What's the lifespan?" → "50,000 hours (11 years at 12h/day)"
    ├── "Is it dimmable?" → "Yes, compatible with 0-10V and DALI"
    └── "What's the warranty?" → "5 years, free replacement for defects"
```

#### 模块 3：FAQ 结构化（AI 最爱引用的格式）

```
FAQ 是 AI 搜索最容易引用的内容格式！

FAQ 设计原则：
├── 问题用买家的语言写（不是你的专业术语）
│   ❌ "What's the CRI of your LED panel?"
│   ✅ "How accurate are the colors under your LED panel light?"
│
├── 答案简短+数据化（AI 喜欢引用简短答案）
│   ❌ "Our products have excellent quality with many years of experience"
│   ✅ "Ra>90. Colors appear 95% true to life under our 4000K panels."
│
├── 每个 FAQ 独立成段（AI 按段提取）
├── FAQ 分类：产品/订购/认证/物流/售后
└── 总量：50-100 个 FAQ 覆盖买家全路径

FAQ 分类框架：

1. 产品类（20-30 个）
   - 产品功能/参数
   - 使用方法/安装
   - 兼容性/配件
   - 对比竞品/传统方案

2. 订购类（10-15 个）
   - MOQ/价格/付款
   - 打样/定制/OEM
   - 认证/合规

3. 物流类（5-10 个）
   - 交期/物流方式
   - 包装/海关/关税

4. 售后类（5-10 个）
   - 质保/退换
   - 技术支持
   - 维修/备件

5. 公司类（5-10 个）
   - 公司背景/资质
   - 合作流程
   - 案例/证言
```

#### 模块 4：案例库（Case Studies / Social Proof）

```
AI 搜索特别喜欢引用的"证据"类型：

├── 客户案例（结构化格式）
│   ├── 客户公司（可匿名化："A leading European retailer"）
│   ├── 项目规模（10,000 units / $200K order）
│   ├── 挑战（客户原来的问题）
│   ├── 解决方案（你做了什么）
│   ├── 结果（量化数据：节能 60%、投诉减少 80%）
│   └── 客户证言（1-2 句原话）
│
├── 数据证明
│   ├── "98.5% on-time delivery rate in 2024"
│   ├── "4.8/5.0 average rating from 200+ clients"
│   ├── "0.3% defect rate (industry average: 2-3%)"
│   └── 这些数据 AI 搜索非常爱引用
│
└── 媒体/行业认可
    ├── 展会参展记录（Canton Fair / CES / Light+Building）
    ├── 行业奖项（Red Dot / iF / Good Design）
    ├── 媒体报道链接
    └── 行业协会会员
```

#### 模块 5：Schema.org 结构化标记（独立站专用）

```
Schema.org 是让 Google/Bing AI 理解你网页内容的标准标记。
加了标记 → AI 更容易引用你 → Rich Snippet 展示更丰富。

必须加的 Schema 类型：

1. Organization（公司信息）
{
  "@type": "Organization",
  "name": "Your Company",
  "foundingDate": "2012",
  "numberOfEmployees": "200",
  "address": { "addressCountry": "CN", "addressLocality": "Ningbo" },
  "sameAs": ["LinkedIn URL", "YouTube URL"],
  "hasCredential": [
    { "@type": "EducationalOccupationalCredential", "credentialCategory": "ISO 9001" }
  ]
}

2. Product（产品信息）
{
  "@type": "Product",
  "name": "LED Panel Light 600x600 40W",
  "brand": { "name": "LUMEX" },
  "offers": { "priceCurrency": "USD", "price": "12.50", "priceValidUntil": "2026-12-31" },
  "aggregateRating": { "ratingValue": "4.8", "reviewCount": "200" },
  "additionalProperty": [
    { "name": "Certification", "value": "UL, CE, DLC" },
    { "name": "Wattage", "value": "40W" }
  ]
}

3. FAQPage（FAQ 页面）
{
  "@type": "FAQPage",
  "mainEntity": [
    { "@type": "Question", "name": "What is the MOQ?", 
      "acceptedAnswer": { "@type": "Answer", "text": "100 pcs for standard..." }}
  ]
}

4. HowTo（安装/使用指南）
5. Review / AggregateRating（评价）

部署方式：
├── JSON-LD 脚本嵌入 <head>（推荐）
├── Shopify：使用 Schema 插件 / 手动编辑 theme.liquid
├── WordPress/WooCommerce：Yoast SEO / Rank Math 插件
└── 验证：Google Rich Results Test
```

#### 模块 6：阿里国际站 AI 优选适配

```
阿里国际站的 AI 选品/推荐逻辑：

影响 AI 推荐的信号：
├── 产品信息完整度（属性填写率 ≥ 95%）
├── 产品描述质量（图文并茂、结构化、FAQ）
├── 公司档案完整度（≥ 90%）
├── 响应速度（≤ 1h 平均响应）
├── 交易数据（成交量、复购率、好评率）
├── RFQ 匹配度（报价精准度+响应率）
├── 视频内容（有视频的 Listing 权重更高）
└── TrustPass / 金品诚企 / 信保

优化动作清单：
├── 所有产品属性填满（不要留空白字段）
├── 产品描述写成 FAQ 格式（AI 好提取）
├── 每个 Listing 加视频（哪怕 30s 手机拍的）
├── Company Profile 加工厂视频+认证扫描件
├── 开通 RFQ 并保持 ≥ 80% 报价率
├── 及时回复询盘（影响 AI 推荐权重）
└── 定期更新产品（30 天内有更新的 Listing 权重更高）
```

#### 模块 7：ChatGPT / Perplexity 引用优化

```
让 ChatGPT / Perplexity 等 AI 工具推荐你的策略：

原理：这些 AI 从互联网抓取信息 → 生成回答
你的目标：让你的信息出现在它们的"训练数据"和"搜索源"中

可控动作：
├── 1. 独立站发布高质量内容
│   ├── 行业指南（"How to choose LED panel lights for office"）
│   ├── 对比文章（"LED vs Fluorescent: 2026 Complete Guide"）
│   ├── FAQ 页面（100+ 问题，结构化 Schema 标记）
│   └── 目标：成为该品类的"权威信息源"
│
├── 2. 第三方平台存在感
│   ├── Wikipedia 关联（如果品类页面有"manufacturers"章节）
│   ├── 行业论坛/Reddit 回答问题
│   ├── Quora 回答相关问题（留品牌名+链接）
│   ├── LinkedIn 发布行业文章
│   └── YouTube 发布教程/评测视频
│
├── 3. 数据一致性
│   ├── 所有平台的公司信息一致（名称/年份/规模/认证）
│   ├── AI 交叉验证多源信息 → 一致性 = 可信度
│   └── Google My Business / Crunchbase / 阿里 / LinkedIn 信息统一
│
└── 4. 被引用的内容特征
    ├── 具体数字（"50,000 hours lifespan" > "long lasting"）
    ├── 独家数据（自己的测试数据/案例数据）
    ├── 权威引用（引用 IES 标准/DOE 报告）
    └── 结构化（H2/H3 标题+列表+表格）
```

---

### Phase 3：知识库建设 SOP

```
4 周知识库建设路线图：

Week 1：信息收集
├── 盘点现有资料（产品表/认证/案例/FAQ/邮件常见问题）
├── 采访业务员（"客户最常问什么？"列出 50 个问题）
├── 采访技术人员（"产品最常被误解的是什么？"）
├── 收集竞品知识库（他们怎么结构化的）
└── 产出：原始素材清单

Week 2：结构化整理
├── 按 7 大模块分类整理
├── FAQ 扩展到 80-100 个
├── 产品百科每个 SKU 填满结构化信息
├── 案例库整理 10+ 个案例（含数据）
└── 产出：结构化知识库初稿

Week 3：平台部署
├── 独立站：加 Schema.org 标记 + FAQ 页面 + 博客内容
├── 阿里国际站：优化产品属性填写 + 描述改 FAQ 格式
├── 第三方：Quora/LinkedIn/YouTube 发布内容
├── Google：提交 Sitemap + 申请 Rich Results
└── 产出：多平台同步上线

Week 4：验证 + 迭代
├── Google Rich Results Test 验证 Schema
├── 搜索"你的品类+你的品牌"看 AI 是否引用
├── 让 ChatGPT/Perplexity 搜你的品类，看是否出现
├── 记录哪些内容被引用 → 加强
├── 记录哪些没被引用 → 补充
└── 产出：优化报告 + 月度更新计划
```

---

## 3 档方案

| 项目 | 🟢 基础知识库 ¥0-2000 | 🟡 AI 优选版 ¥5000-15000 | 🔴 全栈知识工程 ¥30000+ |
|---|---|---|---|
| FAQ 数量 | 30 个 | 80 个 | 150+ 个 |
| 产品百科 | 10 个 SKU | 50 个 SKU | 全品类 |
| Schema 标记 | 基础 3 种 | 5 种+Rich Results | 完整 Schema+JSON-LD |
| 阿里优化 | 属性填写 | 属性+描述+视频 | 全店深度优化 |
| 内容发布 | 独立站 FAQ | +博客+Quora | +YouTube+LinkedIn+Reddit |
| AI 引用监测 | 无 | 月度检查 | 周度监测+优化 |
| 多语言 | 英语 | 英+西/法 | 8 语种知识库 |
| 维护 | 不含 | 季度更新 | 月度更新+新品同步 |
| 适合 | 新手 / 独立站初建 | 成长期 / 想被 AI 推荐 | 品牌化 / 抢占 AI 流量 |

---

## Kill List

1. **Kill "AI 搜索优化 = SEO"的误解** — AI 优选不看关键词密度/外链数量，看的是"内容是否结构化回答了用户问题"；传统 SEO 黑帽技巧对 AI 无效
2. **Kill 空泛企业介绍** — "We are a professional manufacturer with rich experience" AI 不会引用这种废话；要具体数字："Founded 2012, 200 workers, 15,000 m², exported to 30+ countries"
3. **Kill 散落的知识** — FAQ 在聊天记录里、产品参数在 Excel 里、认证在文件夹里 = AI 搜不到；必须结构化上线
4. **Kill 不更新的知识库** — 90 天不更新 = AI 降低权重；产品参数变了但网站没改 = AI 引用错误信息 = 客户投诉
5. **Kill 各平台信息不一致** — 阿里写 200 人、官网写 150 人、LinkedIn 写 100 人 = AI 判定不可信 = 不推荐
6. **Kill 忽略 Schema 标记** — 独立站不加 Schema = Google AI Overview 无法结构化提取你的信息 = 被有标记的竞品抢走

---

## 诚实提醒

```
⚠️ 诚实提醒 — 请务必阅读

1. AI 优选不是一夜之间的事：内容被 AI 索引和引用需要时间，
   通常 1-3 个月才能看到效果。不要期望今天做了明天就被推荐。

2. 内容质量 > 数量：100 个高质量 FAQ 比 1000 个水文有用，
   AI 能分辨内容是否有"信息增量"。

3. 你不可能"控制" AI 推荐你：AI 的推荐算法不透明，
   你能做的是"增加被推荐的概率"，不是"保证"。

4. 传统 SEO 仍然重要：AI 搜索不是替代 Google SEO，
   而是在 SEO 基础上增加一层结构化优化。
   没有 SEO 基础就做 AI 优选 = 空中楼阁。

5. 投入产出最高的动作是：写好 FAQ + 加 Schema 标记。
   这两个动作占总效果的 60%，花费不到总预算的 20%。
```

---

## Excel 报告详设（12 sheet）

| Sheet | 内容 | 关键列 |
|---|---|---|
| 1-知识资产盘点 | 现有资料清单 | 类型/位置/完整度/结构化程度/优先级 |
| 2-公司档案 | 结构化公司信息 | 字段/中文值/英文值/Schema 映射 |
| 3-产品百科 | 每 SKU 结构化 | SKU/名称/参数/认证/FAQ/场景 |
| 4-FAQ 库 | 80-100 个 FAQ | 分类/问题/答案/语种/Schema 标记 |
| 5-案例库 | 10+ 个案例 | 客户/行业/规模/挑战/结果/证言 |
| 6-Schema 标记 | JSON-LD 代码 | 页面/Schema 类型/代码/验证状态 |
| 7-阿里优化 | 产品属性+描述 | 产品/属性完整度/描述格式/视频 |
| 8-内容发布计划 | 第三方平台 | 平台/内容类型/主题/发布日/状态 |
| 9-AI 引用监测 | 被引用记录 | AI 工具/搜索词/是否引用/引用内容/日期 |
| 10-竞品知识库 | 竞品对比 | 竞品/FAQ 数/Schema/内容量/被引用 |
| 11-行动路线图 | 4 周实施计划 | 周次/任务/负责人/状态/产出 |
| 12-诚实提醒 | Kill List + 建议 | 类型/具体项/为什么/替代方案 |

---

## 上下游接口

| 方向 | Agent | 数据流 |
|---|---|---|
| ← 输入 | listing-master | 产品标题+描述+关键词 → 产品百科 |
| ← 输入 | store-decoration | About Us + FAQ → 公司档案 |
| ← 输入 | certification-compliance | 认证清单 → 认证墙 |
| ← 输入 | case-study-builder | 客户案例 → 案例库 |
| ← 输入 | brand-positioning | 品牌故事+USP → 公司档案 |
| ← 输入 | multilingual-localizer | 多语言内容 → 多语言知识库 |
| → 输出 | seo-content | 结构化内容 → SEO 内容矩阵 |
| → 输出 | store-decoration | FAQ → 店铺 FAQ 模块 |
| → 输出 | listing-master | 产品百科 → Listing 内容 |
| → 输出 | inquiry-reply-scripts | FAQ → 回复话术参考 |
