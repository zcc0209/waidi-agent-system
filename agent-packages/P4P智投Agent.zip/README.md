# P4P智投Agent

阿里国际站P4P直通车/智投托管优化。P4P+智投双模式诊断：日预算分配（旺季/淡季/ROI阈值）+关键词出价矩阵（精确/短语/广泛三匹配策略）+ROI监控看板（CTR/CVR/CPC/ROI红绿灯）+自动调价规则（超时/超预算/低CTR触发）+竞品广告反查+12 sheet Excel。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
