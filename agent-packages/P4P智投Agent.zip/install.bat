@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「P4P智投Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\p4p-smart-ads"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"p4p-smart-ads\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"P4P智投Agent\",\r\n  \"description\": \"阿里国际站P4P直通车/智投托管优化。P4P+智投双模式诊断：日预算分配（旺季/淡季/ROI阈值）+关键词出价矩阵（精确/短语/广泛三匹配策略）+ROI监控看板（CTR/CVR/CPC/ROI红绿灯）+自动调价规则（超时/超预算/低CTR触发）+竞品广告反查+12 sheet Excel。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「P4P智投Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
