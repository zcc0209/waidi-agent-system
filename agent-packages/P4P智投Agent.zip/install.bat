@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「P4P智投Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-73FCE03E-12525E53"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-73FCE03E-12525E53","name":"P4P智投Agent","description":"阿里国际站P4P直通车/智投托管优化。P4P+智投双模式诊断：日预算分配（旺季/淡季/ROI阈值）+关键词出价矩阵（精确/短语/广泛三匹配策略）+ROI监控看板（CTR/CVR/CPC/ROI红绿灯）+自动调价规则（超时/超预算/低CTR触发）+竞品广告反查+12 sheet Excel。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「P4P智投Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
