@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「P4P智投Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-73FCE03E-12525E53"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-73FCE03E-12525E53","name":"P4P智投Agent","description":"阿里国际站P4P直通车/智投托管优化。P4P+智投双模式诊断：日预算分配（旺季/淡季/ROI阈值）+关键词出价矩阵（精确/短语/广泛三匹配策略）+ROI监控看板（CTR/CVR/CPC/ROI红绿灯）+自动调价规则（超时/超预算/低CTR触发）+竞品广告反查+12 sheet Excel。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「P4P智投Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
