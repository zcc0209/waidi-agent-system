@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「销量预测Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-3A0D49C6-B27E0BC5"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-3A0D49C6-B27E0BC5`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"销量预测Agent`",`r`n  `"description`": `"外贸销量预测与备货预警。四模型加权预测（历史趋势×季节性×客户预订×宏观因子）未来3/6/12个月销量；输出3档预测（保守/中性/乐观）+备货建议+库存预警（滞销/断货）+产能预警+现金流预测+关键不确定性提示，让备货决策有数据而不是靠感觉拍脑袋。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「销量预测Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
