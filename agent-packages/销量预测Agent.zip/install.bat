@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「销量预测Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-3A0D49C6-B27E0BC5"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-3A0D49C6-B27E0BC5","name":"销量预测Agent","description":"外贸销量预测与备货预警。四模型加权预测（历史趋势×季节性×客户预订×宏观因子）未来3/6/12个月销量；输出3档预测（保守/中性/乐观）+备货建议+库存预警（滞销/断货）+产能预警+现金流预测+关键不确定性提示，让备货决策有数据而不是靠感觉拍脑袋。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「销量预测Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
