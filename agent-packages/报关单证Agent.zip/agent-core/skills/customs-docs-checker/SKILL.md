---
name: customs-docs-checker
description: 外贸报关单证智能起草与审核。当用户要求"报关单证/商业发票/装箱单/原产地证/提单审单/CO办理/Form A/FE/CE合格声明/FDA注册号/出口单证检查"时触发，输出标准模板（CI/PL/BL/CO/各国证书）或对现有单证做合规扫描+L/C 单证一致性检查+不符点修改+目的国特殊单证清单+常见拒收原因预警。
version: 1.0.0
---

# 报关单证 Agent

## 触发场景
- L/C 收到要审单不符点
- 客户要求 CO/Form A/FE 等原产地证不知道办哪个
- 提单 BL 字段错了不知道怎么改
- 商业发票/装箱单总被海关挑毛病
- 目的国要特殊单证（如沙特 SASO / 巴西 LI）

## 输入

必需任一：
- 起草模式：订单关键信息（卖方/买方/产品/数量/金额/装运信息）
- 审单模式：现有单证文本（CI/PL/BL/CO/L/C 等）
- 目的国（必须，决定特殊单证要求）

可选：
- L/C 副本（用于一致性检查）
- HS Code
- 产品价值结构（用于关税优惠原产地判定）

## 标准外贸单证清单

### 基础 5 大单证（每单必备）

1. **Commercial Invoice 商业发票**
2. **Packing List 装箱单**
3. **Bill of Lading B/L 提单**（海运） / Air Waybill AWB（空运）
4. **Certificate of Origin CO 原产地证**
5. **Beneficiary's Certificate 受益人证明**（L/C 常要求）

### 特殊单证（按客户/国家/品类）

| 单证 | 用途 |
|---|---|
| Form A 普惠制原产地证 | 享发达国家普惠关税（GSP） |
| FORM E（中-东盟） / FORM F（中-巴基斯坦） | 自贸协定优惠 |
| FORM N（中-新西兰） / FORM L（中-韩国） | 自贸协定 |
| RCEP 原产地证 | 亚太 15 国自贸 |
| 商检证书 CIQ | 部分品类 |
| 熏蒸证 Fumigation Cert | 木质包装/食品 |
| 装运前检验证 PSI | 部分非洲国家强制（COC） |
| 健康证 Health Cert | 食品/药品 |
| 农产品检疫证 | 食品/植物 |
| Certificate of Analysis COA | 化学品/食品 |
| MSDS 化学品安全说明书 | 化工/带电品/液体 |
| Free Sale Certificate 自由销售证书 | 化妆品/医疗器械 |
| ATA 单证册 | 临时进出口（展品） |
| EUR.1 | 欧盟自贸协定 |

### 各国强制特殊单证

| 国家 | 单证 |
|---|---|
| 沙特 SA | SABER 平台合规证书 + COC |
| 阿联酋 AE | ECAS / G-Mark 证书 |
| 印度 IN | BIS 证书 + AD Code |
| 巴西 BR | Licença de Importação LI + INMETRO 证书 |
| 阿根廷 AR | SIMI 进口许可 |
| 俄罗斯 RU | EAC 证书 + GTD 报关单 |
| 阿尔及利亚 DZ | 装船前检验 PSI |
| 尼日利亚 NG | SONCAP COC |
| 肯尼亚 KE | KEBS PVoC |
| 埃及 EG | GOEIC 装船前 |
| 伊朗 IR | COI / SGS PSI |

## 工作流

### Step 1: 模式判断 + 单证清单生成

接收订单信息+目的国 → 输出该订单"必备单证清单"（带必填字段+办理周期+办理渠道）。

### Step 2: 单证起草（起草模式）

**Commercial Invoice 必备 18 字段**：
1. Invoice No. + Date
2. Seller (Name + Address + Tel + Email + Tax ID)
3. Buyer (Name + Address + Tel + Tax ID)
4. Notify Party（如有）
5. PO/Contract No.
6. Vessel/Voyage / Flight No.
7. Port of Loading / Discharge / Final Destination
8. INCOTERMS (FOB/CIF/DDP + 港口)
9. Currency + Payment Terms
10. HS Code
11. Description of Goods（要详细，不能"electronic products"）
12. Specifications / Model
13. Quantity + Unit
14. Unit Price
15. Total Amount (figures + words)
16. Net Weight + Gross Weight
17. Country of Origin
18. Manufacturer Name + Address (often required)
+ 卖方签字盖章

**Packing List 必备字段**：
- Package No. (1 to N)
- Package Type (Carton/Pallet)
- Contents per Package
- Quantity per Package
- N.W. + G.W. per Package
- Dimensions L×W×H
- 总计 Totals (Cartons / Qty / NW / GW / CBM)

**Bill of Lading 必备字段**：
- Shipper / Consignee / Notify Party（与 L/C 完全一致）
- Vessel / Voyage / B/L No.
- Port of Loading / Discharge / Place of Delivery
- Marks and Numbers / Description / Quantity / Weight / Measurement
- Freight Prepaid / Collect
- On Board Date
- Number of Originals (3 originals 标准)

### Step 3: 单证一致性审查（审单模式核心）

L/C / Sales Contract / Commercial Invoice / Packing List / B/L / CO 之间必须**所有字段完全一致**：

```
═══ 单证一致性扫描 ═══
检查项 1: Beneficiary 名称地址
  L/C: Yichen Auto Parts Co., Ltd, 123 Main St, Wenzhou
  CI:  YICHEN Auto Parts Co., Ltd, No. 123 Main Street, Wenzhou ❌ 不符
  → 大小写/缩写也要严格一致，否则银行不符点

检查项 2: 货物描述
  L/C: "Power Window Regulator, Model XYZ-100, 5000 PCS"
  CI:  "Power Window Regulator, Model XYZ-100, 5000 PCS" ✅ OK

检查项 3: 装运港/目的港
  L/C: Shanghai → Hamburg
  B/L: Ningbo → Hamburg ❌ 装运港不符
  → 拒付风险

检查项 4: 装运期 vs 议付期
  L/C: Latest shipment 2026-06-30, expiry 2026-07-15
  B/L: On Board 2026-07-02 ❌ 已超装运期
  → 严重不符点

...（共 20+ 检查项）
═══════════════
```

### Step 4: 不符点修改建议

每个不符点给：
- 具体不符位置
- 标准修改文本
- 修改方式（船公司改 BL / 商检局改 CO / 自行改 CI）
- 改单费用预估
- 时效预估

### Step 5: 原产地证办理建议

按目的国推荐最优类型：
- 享 RCEP 优惠？→ 申请 RCEP CO（节税 5-15%）
- 享中欧关税？→ Form A
- 享中-东盟？→ Form E
- 通用 → 一般原产地证 CO

办理渠道：
- CCPIT 中国国际贸易促进委员会
- 各地海关 / 商检局
- 部分自贸区可线上申报

### Step 6: 输出 Excel 单证管理表

**Sheet 1: 单证清单**（按订单+目的国生成必备单证清单）
**Sheet 2: 单证起草模板**（CI/PL/BL/CO 标准模板）
**Sheet 3: 一致性检查报告**（如审单模式）
**Sheet 4: 不符点修改清单**（具体位置+修改文本+渠道+费用+时效）
**Sheet 5: 原产地证决策树**（最优类型+办理渠道+预计时间+省税额）
**Sheet 6: 目的国特殊单证**（如 SASO/INMETRO/BIS 等）
**Sheet 7: 单证时间表**（哪天交什么单证给货代/银行/客户）
**Sheet 8: 常见拒收原因 Top 20**（针对该国家的常见翻车点）

## 常见拒收原因 Top 20

1. CI 与 L/C 货物描述大小写/标点不符
2. CI 金额数字与文字不符
3. PL 件数与 BL 件数不符
4. BL 装运港 / 目的港与 L/C 不符
5. BL On Board 日期晚于 L/C 装运期
6. CO 受益人名称简写
7. CO 货物描述与 CI 不一致
8. CI 缺 Manufacturer 信息（部分国家强制）
9. CI 缺 HS Code 或填错
10. 缺 Beneficiary's Certificate（L/C 要求）
11. 单证套数不足（L/C 要 3 正 3 副，实交 3 正 2 副）
12. 单证签字字迹潦草不可辨
13. 商检证 CIQ 过期
14. 熏蒸证缺失（木质包装强制）
15. MSDS 缺失（带电品快递强制）
16. EUR.1 / FORM A / RCEP 单证选错（不能享优惠）
17. 阿语单证翻译错（中东国家拒收）
18. 价格条款 INCOTERMS 不规范（如 "FOB Shanghai" 要写 "FOB Shanghai, China INCOTERMS 2020"）
19. 议付期内未交单（L/C 失效）
20. 提单背书人错（"To order" 没 endorse 给 consignee）

## 注意事项

- **L/C 审单一字不差**：UCP 600 严苛，"Co.,Ltd" 和 "CO LTD" 都算不符点
- **CO 优先级 RCEP > Form A > 一般 CO**：根据目的国关税优惠最大的选
- **HS Code 不能瞎填**：填错被海关查到会归类申诉，时间长且罚款
- **货物描述要详细**：不能"electronic products"，要"Power Window Regulator for Toyota Camry 2018, Model XYZ-100, OEM #12345"
- **装运期 vs 议付期**：议付期>装运期+15 天，否则装船完没时间交单
- **三套正本+三套副本**：L/C 标准要求，少一份银行就拒付
- **单证日期顺序**：CI 日期 ≤ B/L On Board ≤ Latest Shipment ≤ Expiry
- **去 AI 化**：报告不要"建议规范单证"，要"CI 第 3 行 'Buyer Address' 与 L/C 第 5 段不符，请改为：[具体文本]"
- **大客户要求自留底稿**：所有单证草稿要客户书面确认（邮件保存）后再签发，避免后期改单

## 验证

- 起草的 CI 是否含 18 个必备字段
- 一致性扫描是否真的逐字段对比（不是只看大项）
- 不符点修改建议是否给具体位置+标准修改文本（不是模糊地说"建议修改"）
- 原产地证推荐是否给出"省税额"对比（让用户知道选 RCEP vs 普通 CO 的差额）
- 目的国特殊单证是否覆盖（比如沙特漏 SABER / 巴西漏 LI 直接清不了关）
