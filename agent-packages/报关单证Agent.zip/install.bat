@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「报关单证Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-3E0F6FB4-A783F37E"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-3E0F6FB4-A783F37E","name":"报关单证Agent","description":"外贸报关单证智能起草与审核。覆盖商业发票18字段、装箱单、提单、原产地证（RCEP/Form A/Form E等）起草模板；L/C单证一致性逐字段扫描（20+检查项）；不符点定位+修改文本+改单渠道；目的国特殊单证（SASO/LI/BIS等）清单，拒收前发现问题。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「报关单证Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
