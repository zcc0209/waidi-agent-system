@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「报关单证Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\customs-docs-checker"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"customs-docs-checker\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"报关单证Agent\",\r\n  \"description\": \"外贸报关单证智能起草与审核。覆盖商业发票18字段、装箱单、提单、原产地证（RCEP/Form A/Form E等）起草模板；L/C单证一致性逐字段扫描（20+检查项）；不符点定位+修改文本+改单渠道；目的国特殊单证（SASO/LI/BIS等）清单，拒收前发现问题。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「报关单证Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
