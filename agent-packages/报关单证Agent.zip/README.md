# 报关单证Agent

外贸报关单证智能起草与审核。覆盖商业发票18字段、装箱单、提单、原产地证（RCEP/Form A/Form E等）起草模板；L/C单证一致性逐字段扫描（20+检查项）；不符点定位+修改文本+改单渠道；目的国特殊单证（SASO/LI/BIS等）清单，拒收前发现问题。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
