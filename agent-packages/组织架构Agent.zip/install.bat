@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「组织架构Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-37857006-0E62439F"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-37857006-0E62439F`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"组织架构Agent`",`r`n  `"description`": `"外贸公司组织架构设计（团队体系地基）。按5阶段规模（1-5/5-15/15-50/50-200/200+人）×4业务模式（贸易/工厂/品牌商/平台店）输出3套架构方案（保守/推荐/激进）+前中后台划分+管理半径检查+5大误区诊断+阶段升级路线图，帮老板从一线管理中解放出来。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「组织架构Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
