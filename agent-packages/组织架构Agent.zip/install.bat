@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「组织架构Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "REAL_ACCT_ID="
        for /d %%B in ("%%A\agents\*") do (
            if exist "%%B\profile.jsonc" if not defined REAL_ACCT_ID (
                for /f "tokens=* usebackq" %%L in ("%%B\profile.jsonc") do (
                    echo %%L | findstr /i "accountId" >nul 2>&1 && (
                        for /f "tokens=2 delims=:, " %%V in ("%%L") do (
                            set "TMP=%%V"
                            set "TMP=!TMP: =!"
                            set "TMP=!TMP:"=!"
                            if not "!TMP!"=="" set "REAL_ACCT_ID=!TMP!"
                        )
                    )
                )
            )
        )
        if not defined REAL_ACCT_ID (
            for /f "tokens=1 delims=_" %%C in ("!DIR_NAME!") do set "REAL_ACCT_ID=%%C"
        )
        set "TARGET=%%A\agents\DID-37857006-0E62439F"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        set "PROF=!TARGET!\profile.jsonc"
        powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-37857006-0E62439F`",`r`n  `"accountId`": `"!REAL_ACCT_ID!`",`r`n  `"name`": `"组织架构Agent`",`r`n  `"description`": `"外贸公司组织架构设计（团队体系地基）。按5阶段规模（1-5/5-15/15-50/50-200/200+人）×4业务模式（贸易/工厂/品牌商/平台店）输出3套架构方案（保守/推荐/激进）+前中后台划分+管理半径检查+5大误区诊断+阶段升级路线图，帮老板从一线管理中解放出来。`",`r`n  `"model`": {`"provider`": `"auto`",`"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"toolPreset`": `"full`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n'; Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME! (accountId=!REAL_ACCT_ID!)
        set "REAL_ACCT_ID="
    )
)
echo.
echo ================================================
echo   [完成] 「组织架构Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标→退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
