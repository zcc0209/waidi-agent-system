@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「谈判教练Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-15CCAD9B-CEDF3102"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-15CCAD9B-CEDF3102","name":"谈判教练Agent","description":"外贸谈判实战教练。粘贴客户邮件（砍价/比价/要账期/拖延/质疑/消失），输出：客户意图判读+心理画像+谈判筹码盘点+3档应对策略（强势/中性/让步）+风险预警+下一步话术，让每封难搞的邮件都有可直接发出的回复方案。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「谈判教练Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
