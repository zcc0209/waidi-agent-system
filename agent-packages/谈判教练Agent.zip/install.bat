@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「谈判教练Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-15CCAD9B-CEDF3102"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-15CCAD9B-CEDF3102","name":"谈判教练Agent","description":"外贸谈判实战教练。粘贴客户邮件（砍价/比价/要账期/拖延/质疑/消失），输出：客户意图判读+心理画像+谈判筹码盘点+3档应对策略（强势/中性/让步）+风险预警+下一步话术，让每封难搞的邮件都有可直接发出的回复方案。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「谈判教练Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
