@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「物流方案Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-8B58BA1E-AE89E0C5"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-8B58BA1E-AE89E0C5","name":"物流方案Agent","description":"外贸物流方案智能比价。按目的国×货量×时效×预算输出5种方案对比（海运整柜/拼箱/空运/快递/海外仓），含体积重计算、目的港关税预测（含301加征/双反/VAT）、DDP全链路报价模板、清关风险预警、旺季舱位预警、物流商推荐（带价格区间）。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「物流方案Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
