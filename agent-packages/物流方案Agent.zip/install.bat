@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「物流方案Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-8B58BA1E-AE89E0C5"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-8B58BA1E-AE89E0C5`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"物流方案Agent`",`r`n  `"description`": `"外贸物流方案智能比价。按目的国×货量×时效×预算输出5种方案对比（海运整柜/拼箱/空运/快递/海外仓），含体积重计算、目的港关税预测（含301加征/双反/VAT）、DDP全链路报价模板、清关风险预警、旺季舱位预警、物流商推荐（带价格区间）。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「物流方案Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
