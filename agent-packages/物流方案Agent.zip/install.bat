@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「物流方案Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-8B58BA1E-AE89E0C5"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-8B58BA1E-AE89E0C5","name":"物流方案Agent","description":"外贸物流方案智能比价。按目的国×货量×时效×预算输出5种方案对比（海运整柜/拼箱/空运/快递/海外仓），含体积重计算、目的港关税预测（含301加征/双反/VAT）、DDP全链路报价模板、清关风险预警、旺季舱位预警、物流商推荐（带价格区间）。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「物流方案Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
