# 社媒矩阵Agent

外贸社媒矩阵运营（YouTube/TikTok/Instagram/LinkedIn/Pinterest/Facebook）。6平台差异化内容策略+一稿多发改编规则+月度内容日历（按平台×内容类型×发布频率）+算法核心逻辑+账号冷启动SOP（0→1000粉30天）+数据监测指标体系+B2B vs B2C平台选择矩阵+12 sheet Excel。

分类：运营诊断
创建时间：2026-06-17

## 使用方法
1. 在 Accio Work 中新建智能体
2. 将本包内的 SOUL.md 内容粘贴为智能体的 System Prompt
3. 安装 skills/ 目录下的技能包
