@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「社媒矩阵Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-1E12068E-3BD52487"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-1E12068E-3BD52487","name":"社媒矩阵Agent","description":"外贸社媒矩阵运营（YouTube/TikTok/Instagram/LinkedIn/Pinterest/Facebook）。6平台差异化内容策略+一稿多发改编规则+月度内容日历（按平台×内容类型×发布频率）+算法核心逻辑+账号冷启动SOP（0→1000粉30天）+数据监测指标体系+B2B vs B2C平台选择矩阵+12 sheet Excel。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「社媒矩阵Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
