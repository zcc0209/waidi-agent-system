@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「社媒矩阵Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\social-media-matrix"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"social-media-matrix\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"社媒矩阵Agent\",\r\n  \"description\": \"外贸社媒矩阵运营（YouTube/TikTok/Instagram/LinkedIn/Pinterest/Facebook）。6平台差异化内容策略+一稿多发改编规则+月度内容日历（按平台×内容类型×发布频率）+算法核心逻辑+账号冷启动SOP（0→1000粉30天）+数据监测指标体系+B2B vs B2C平台选择矩阵+12 sheet Excel。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「社媒矩阵Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
