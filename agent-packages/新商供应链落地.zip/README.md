# 新商供应链落地

外贸新商供应链搭建与落地，从工厂寻源到交期管控全流程指导。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
