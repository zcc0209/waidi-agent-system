# 新商供应链落地



**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
