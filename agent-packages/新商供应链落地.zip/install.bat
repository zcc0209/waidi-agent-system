@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「新商供应链落地」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\MID-NEWBIZ-S03-SUPPLY-CHAIN"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`n{`n  \"id\": \"MID-NEWBIZ-S03-SUPPLY-CHAIN\",`n  \"accountId\": \"!ACCT_ID!\",`n  \"name\": \"新商供应链落地\",`n  \"description\": \"外贸新商供应链搭建与落地，从工厂寻源到交期管控全流程指导。\",`n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},`n  \"runtime\": \"local\",`n  \"creator\": \"user\",`n  \"agentType\": \"general\",`n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\n}';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「新商供应链落地」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开
echo.
pause
