@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「市场洞察Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-50E9B31E-F047154C"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-50E9B31E-F047154C","name":"市场洞察Agent","description":"外贸市场洞察雷达（深度版）。6维市场报告：市场规模与CAGR+季节性曲线（Google Trends+海关数据）+关税合规雷达+需求驱动力&衰退信号+价格带演变+消费者偏好迁移；Top 5市场对比+GO/HOLD/KILL决策卡+3档进入方案+12 sheet Excel，让战略决策有数据支撑。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「市场洞察Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
