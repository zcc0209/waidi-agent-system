# 市场洞察Agent

外贸市场洞察雷达（深度版）。6维市场报告：市场规模与CAGR+季节性曲线（Google Trends+海关数据）+关税合规雷达+需求驱动力&衰退信号+价格带演变+消费者偏好迁移；Top 5市场对比+GO/HOLD/KILL决策卡+3档进入方案+12 sheet Excel，让战略决策有数据支撑。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
