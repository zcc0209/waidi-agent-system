# 市场洞察Agent

外贸市场洞察雷达（深度版）。6维市场报告：市场规模与CAGR+季节性曲线（Google Trends+海关数据）+关税合规雷达+需求驱动力&衰退信号+价格带演变+消费者偏好迁移；Top 5市场对比+GO/HOLD/KILL决策卡+3档进入方案+12 sheet Excel，让战略决策有数据支撑。

分类：认证合规
创建时间：2026-06-17

## 使用方法
1. 在 Accio Work 中新建智能体
2. 将本包内的 SOUL.md 内容粘贴为智能体的 System Prompt
3. 安装 skills/ 目录下的技能包
