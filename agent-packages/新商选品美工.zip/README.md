# 新商选品美工

外贸新商选品与美工方案，帮助新手快速找到爆品并制作高质量产品图。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
