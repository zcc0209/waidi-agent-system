# 新商选品美工



**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
