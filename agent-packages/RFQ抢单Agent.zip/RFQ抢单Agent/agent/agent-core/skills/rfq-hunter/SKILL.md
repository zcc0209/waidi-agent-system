---
name: rfq-hunter
description: 阿里国际站 RFQ 抢单智能体。当用户要求"RFQ/采购需求/抢 RFQ/报价 RFQ/RFQ 匹配/RFQ 模板/RFQ 回复/采购商需求/买家发布需求/RFQ 报价率/RFQ 中标"时触发，输出 RFQ 筛选评分 + 5 级优先级 + 黄金 30 分钟响应 SOP + 报价模板（含钩子设计）+ RFQ 数据复盘 + 12 sheet Excel + 诚实提醒。
version: 1.0.0
---

# 阿里国际站 RFQ 抢单智能体

> 一句话定位：不是每条 RFQ 都值得报——帮你 5 分钟判断"值不值得报"，10 分钟出一份"让买家回你"的报价——黄金 30 分钟内抢到先机。

---

## 触发场景

- "今天 RFQ 大厅有什么好的采购需求"
- "这条 RFQ 值不值得报"
- "帮我写个 RFQ 报价"
- "RFQ 报了很多但没人回"
- "怎么提高 RFQ 中标率"
- "RFQ 配额用不完/不够用"

---

## 输入要求

| 项目 | 必须 | 示例 |
|---|---|---|
| RFQ 内容 | ✅ | 粘贴 RFQ 标题+描述+买家需求 |
| 你的品类/产品 | ✅ | LED Panel Light |
| 你的优势 | ✅ | OEM/认证/价格/交期 |
| RFQ 配额 | - | 月剩余配额 20 条 |
| 历史 RFQ 数据 | - | 过去 3 个月报价率/回复率/成交率 |

---

## 工作流

### Phase 1：RFQ 筛选评分（5 分钟决策）

```
RFQ 快速评分表（满分 100 分，≥ 60 分才报）：

| 维度 | 权重 | 评分标准 |
|---|---|---|
| 品类匹配度 | 25% | 完全匹配 25 / 相关 15 / 擦边 5 / 不匹配 0 |
| 买家质量 | 20% | 已认证 20 / 多年会员 15 / 新买家 10 / 可疑 0 |
| 需求明确度 | 15% | 规格完整 15 / 有图片 12 / 简单描述 8 / 一句话 3 |
| 数量合理性 | 15% | MOQ 以上 15 / 接近 MOQ 10 / 远低于 MOQ 5 / 试样 1 个 2 |
| 交期可行性 | 10% | 充裕 10 / 紧但可做 7 / 非常紧 3 / 不可能 0 |
| 市场/国家 | 10% | 优质市场 10 / 一般 7 / 高风险 3 / 制裁国 0 |
| 竞争程度 | 5% | 报价人少 5 / 中等 3 / 已有 50+ 报价 1 |

5 级优先级：
├── S 级（90-100 分）：立即报价，10 分钟内完成，老板亲自跟
├── A 级（75-89 分）：30 分钟内报价，资深业务员跟
├── B 级（60-74 分）：当天报价，标准模板+差异化亮点
├── C 级（40-59 分）：配额充裕时报，简单模板
└── D 级（< 40 分）：不报（省配额给更好的）

D 级不报的典型情况：
├── 品类完全不匹配（你做照明他要服装）
├── 要求 1 个样品且不愿付费
├── 来自高风险/制裁国家
├── 需求模糊到无法报价（"I want something good and cheap"）
├── 已有 100+ 报价（你根本排不上号）
└── 交期 3 天（物理上不可能）
```

### Phase 2：黄金 30 分钟响应 SOP

```
为什么 30 分钟？
├── 阿里数据：前 3 个报价的供应商获得 70% 的买家回复
├── RFQ 发布后 30 分钟内报价 → 出现在买家报价列表最前面
├── 超过 4 小时报价 → 买家已经开始和前 3 家深聊了
└── 超过 24 小时 → 基本没戏

30 分钟 SOP：

00:00-05:00 快速评分
├── 用上面评分表判断是否值得报
├── ≥ 60 分 → 继续
├── < 60 分 → 跳过
└── 同时打开买家主页看历史采购

05:00-15:00 准备报价
├── 选择最匹配的 1-3 个产品
├── 查当前 FOB 价格（含利润空间）
├── 选择合适的报价模板
├── 写 3-5 句个性化钩子
└── 附上 1-2 张产品图+认证

15:00-25:00 提交报价
├── 填写报价表（价格/MOQ/交期/认证）
├── 附上个性化消息
├── 检查无错别字/数字错误
└── 提交

25:00-30:00 补充动作
├── 如果有买家邮箱 → 同时发一封邮件（双触达）
├── 记录报价到 CRM/Excel
├── 设置 24 小时提醒跟进
└── 标记配额使用情况
```

### Phase 3：报价模板库（让买家回你）

```
RFQ 报价消息模板（不是价格表，是"让买家愿意回你"的消息）：

核心原则：RFQ 报价不是发价格表，是"1 分钟说服买家选你深聊"。

模板 A：精准匹配型（评分 ≥ 80）
---
Hi [Name],

I noticed you're looking for [产品] with [关键需求]. 
We have exactly what you need:

✅ [产品名] — [1 句核心差异化]
✅ Price: FOB $XX.XX/pc (for [MOQ]+)
✅ Lead time: [X] days
✅ Certification: [UL/CE/etc.]

Quick highlight: [1 个让你区别于其他 50 家报价的亮点]
Example: "We just shipped 5 containers of similar spec to [国家] last month."

📎 Attached: product spec sheet + certificate copies

Would you like a sample or a video call to discuss further?

Best,
[Name] | [Company]
---

模板 B：需求模糊型（需要引导买家细化）
---
Hi [Name],

Thanks for your inquiry on [品类]. To give you the best quote, 
could you confirm:

1. Exact specification: [提供 2-3 个选项让买家选]
2. Quantity: [MOQ 起 or 你的灵活 MOQ]
3. Target market: [影响认证需求]

Meanwhile, here's our most popular model as reference:
[产品名] — FOB $XX.XX — [核心参数]

📎 Attached: our catalog (page 3-5 covers your category)

Happy to customize based on your exact needs.
---

模板 C：高竞争型（50+ 人已报价，需要差异化钩子）
---
Hi [Name],

You probably received many quotes already, so I'll keep it short:

3 reasons to consider us:
1. [唯一差异化] — e.g. "We're the only factory with UL + DLC + DesignLights"
2. [交期优势] — e.g. "Sample in 3 days, not 7"  
3. [风险降低] — e.g. "Money-back guarantee if sample doesn't match spec"

Price: FOB $XX.XX (we beat most quotes at this quality level)

One quick question: [提一个显示你专业的问题]
e.g. "Is this for a UL-required market? If so, I can include our UL file number."

This question alone will make you stand out from 90% of "here's my price" quotes.
---

钩子设计 5 种：
├── 社会证明钩："We just completed a 10,000pc order for a [同行业] client in [同国家]"
├── 专业问题钩："Is this for [specific application]? We have a [specific solution]"
├── 风险降低钩："Free sample + DHL shipping included"
├── 时效钩："We have [产品] in stock — can ship within 3 days"
└── 独家钩："We're the only supplier with [unique certification/patent]"
```

### Phase 4：RFQ 数据复盘

```
月度 RFQ 复盘 8 指标：

| 指标 | 计算方式 | 健康值 |
|---|---|---|
| 配额使用率 | 已用/总配额 | 80-95%（太低浪费，太高没余量）|
| 报价率 | 报价数/匹配 RFQ 数 | ≥ 70% |
| 买家回复率 | 回复数/报价数 | ≥ 15%（行业均值 8-12%）|
| 深聊率 | 深入沟通/回复数 | ≥ 40% |
| 样品率 | 寄样/深聊数 | ≥ 30% |
| 成交率 | 成交/报价数 | ≥ 3%（行业均值 1-2%）|
| 平均响应时间 | 从 RFQ 发布到你报价 | ≤ 2h（目标 30min）|
| 单条 RFQ 成本 | 配额成本/配额数 | 约 ¥30-50/条（金品会员）|

复盘 Action：
├── 回复率 < 10% → 报价消息太模板化 / 价格不合理 / 响应太慢
├── 深聊率 < 30% → 产品不匹配 / 信任不够 / 竞品更强
├── 成交率 < 1% → 跟进话术问题 → 转 inquiry-reply-scripts
└── 配额使用率 < 50% → 筛选标准太严 / 品类词设置不够
```

---

## 3 档方案

| 项目 | 🟢 基础抢单 | 🟡 精准狙击 | 🔴 RFQ 工厂 |
|---|---|---|---|
| 月配额 | 30 条（基础会员） | 60 条（金品） | 100+ 条（顶级会员） |
| 评分筛选 | ≥ 60 分就报 | ≥ 70 分精选 | 分级报（S/A/B 差异化） |
| 响应时间 | 当天 | 2 小时 | 30 分钟 |
| 模板 | 通用模板 1 套 | 3 套差异化模板 | 5 套+个性化钩子 |
| 跟进 | 报完不跟 | 24h 跟进 | 24h+72h+7d 三轮跟进 |
| 数据复盘 | 不复盘 | 月度复盘 | 周度复盘+A/B 测试 |
| 预期回复率 | 5-8% | 12-18% | 20-30% |

---

## Kill List

1. **Kill 海投策略** — 看到 RFQ 就报、不筛选 = 配额浪费 + 回复率 < 3%；30 条配额报 30 个不如精选 15 个
2. **Kill 纯价格报价** — 只发"$12.50/pc MOQ 500"一行字 = 和其他 50 家报价一模一样；买家不会回
3. **Kill 超过 24h 才报** — 24h 后报价基本已经被淹没；前 3 名报价获得 70% 回复
4. **Kill 不看买家背景** — 报价前花 2 分钟看买家主页：注册年限/历史采购/认证 → 判断是否真实买家
5. **Kill 报完不跟进** — 报价后 24h 没回复 → 发一条"Just checking if you received my quote" = 回复率 +50%
6. **Kill 不复盘数据** — 不知道哪种模板回复率高/哪类 RFQ 成交率好 = 永远原地踏步

---

## 诚实提醒

```
⚠️ 诚实提醒 — 请务必阅读

1. RFQ 不是免费午餐：配额有限 + 每条有成本（金品会员
   年费分摊），不要随便浪费在低质量需求上。

2. RFQ 回复率行业均值只有 8-12%：报了 10 条有 1 条回
   就已经不错了。不要因为回复少就觉得方法有问题。

3. RFQ 买家 ≠ 真买家：部分 RFQ 是竞品"钓鱼"探价格的，
   部分是采购平台的虚假需求。学会识别。

4. RFQ 成交周期很长：从报价到成交通常 30-90 天，
   不要期望今天报价明天下单。

5. RFQ 是"增量"不是"主力"：RFQ 获客成本通常高于
   自然询盘和 P4P。RFQ 适合补充客户池，不是替代。
```

---

## Excel 报告详设（12 sheet）

| Sheet | 内容 | 关键列 |
|---|---|---|
| 1-RFQ 评分表 | 今日 RFQ 评分 | RFQ ID/标题/7 维评分/总分/优先级/是否报 |
| 2-报价记录 | 已报价 RFQ | 日期/RFQ/买家/报价/模板/状态/回复 |
| 3-买家背景 | 报价买家画像 | 买家/国家/注册年/历史采购/评估 |
| 4-模板效果 | 各模板 A/B 测试 | 模板/使用次数/回复率/深聊率/成交率 |
| 5-配额管理 | 月度配额使用 | 日期/已用/剩余/当日报价质量 |
| 6-响应时效 | 报价速度追踪 | RFQ/发布时间/报价时间/间隔/排名 |
| 7-钩子效果 | 5 种钩子对比 | 钩子类型/使用次数/回复率/示例 |
| 8-跟进记录 | 报后跟进状态 | RFQ/报价日/跟进 1/跟进 2/当前状态 |
| 9-月度复盘 | 8 指标看板 | 指标/当月/上月/健康值/差距/行动 |
| 10-竞品报价 | 竞品在 RFQ 的表现 | 竞品/报价频率/价格区间/响应速度 |
| 11-品类热度 | 热门 RFQ 品类 | 品类/月 RFQ 数/趋势/匹配度 |
| 12-诚实提醒 | Kill List | 类型/具体项/为什么/替代方案 |

---

## 上下游接口

| 方向 | Agent | 数据流 |
|---|---|---|
| ← 输入 | keyword-matrix | 关键词 → RFQ 品类匹配 |
| ← 输入 | buyer-background-check | 买家背调 → 评分加权 |
| ← 输入 | quote-generator | 报价模板 → RFQ 报价 |
| ← 输入 | target-country-matrix | 国家评分 → 市场维度评分 |
| → 输出 | inquiry-triage | RFQ 回复 → 询盘分级 |
| → 输出 | inquiry-reply-scripts | 深聊后跟进话术 |
| → 输出 | buyer-icp-persona | RFQ 成交客户 → ICP 反哺 |
| → 输出 | monthly-review | RFQ 数据 → 月度复盘 |
