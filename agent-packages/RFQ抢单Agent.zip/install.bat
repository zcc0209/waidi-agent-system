@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「RFQ抢单Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-C05A5B91-00524CE8"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-C05A5B91-00524CE8","name":"RFQ抢单Agent","description":"阿里国际站RFQ抢单全流程。RFQ筛选10维评分（满分100）+5级优先级（S/A/B/C/Kill）+黄金30分钟响应SOP（推荐模板→个性化→发送→跟进）+报价模板含钩子设计（价格锚点/样品诱饵/独家承诺）+RFQ数据复盘（周/月漏斗）+12 sheet Excel，把RFQ转化率从行业均值5%"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「RFQ抢单Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
