@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「RFQ抢单Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-C05A5B91-00524CE8"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-C05A5B91-00524CE8`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"RFQ抢单Agent`",`r`n  `"description`": `"阿里国际站RFQ抢单全流程。RFQ筛选10维评分（满分100）+5级优先级（S/A/B/C/Kill）+黄金30分钟响应SOP（推荐模板→个性化→发送→跟进）+报价模板含钩子设计（价格锚点/样品诱饵/独家承诺）+RFQ数据复盘（周/月漏斗）+12 sheet Excel，把RFQ转化率从行业均值5%提到15%+。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「RFQ抢单Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
