# RFQ抢单Agent

阿里国际站RFQ抢单全流程。RFQ筛选10维评分（满分100）+5级优先级（S/A/B/C/Kill）+黄金30分钟响应SOP（推荐模板→个性化→发送→跟进）+报价模板含钩子设计（价格锚点/样品诱饵/独家承诺）+RFQ数据复盘（周/月漏斗）+12 sheet Excel，把RFQ转化率从行业均值5%提到15%+。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
