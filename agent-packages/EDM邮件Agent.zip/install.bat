@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「EDM邮件Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "REAL_ACCT_ID="
        for /d %%B in ("%%A\agents\MID-*") do (
            if exist "%%B\profile.jsonc" if not defined REAL_ACCT_ID (
                for /f "tokens=2 delims=: " %%V in ('findstr /i "accountId" "%%B\profile.jsonc"') do (
                    set "TMP=%%V"
                    set "TMP=!TMP:,=!"
                    set "TMP=!TMP:"=!"
                    set "TMP=!TMP: =!"
                    if not "!TMP!"=="" set "REAL_ACCT_ID=!TMP!"
                )
            )
        )
        if not defined REAL_ACCT_ID (
            for /f "tokens=1 delims=_" %%C in ("!DIR_NAME!") do set "REAL_ACCT_ID=%%C"
        )
        set "TARGET=%%A\agents\DID-608349B6-8BB6ABE5"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        set "PROF=!TARGET!\profile.jsonc"
        powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-608349B6-8BB6ABE5`",`r`n  `"accountId`": `"!REAL_ACCT_ID!`",`r`n  `"name`": `"EDM邮件Agent`",`r`n  `"description`": `"外贸EDM邮件营销（B2B询盘培育+B2C通用）。5客户群分层×5阶段邮件序列×ABC三版模板+主题行10公式库+国别化发送时间矩阵（美/欧/中东/亚太）+送达率优化（SPF/DKIM/DMARC配置）+反垃圾15项Checklist+合规差异（GDPR/CAN-SPAM/CASL）+工具选择矩阵+12 sheet Excel。`",`r`n  `"model`": {`"provider`": `"auto`",`"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"toolPreset`": `"full`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n'; Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME! (accountId=!REAL_ACCT_ID!)
        set "REAL_ACCT_ID="
    )
)
echo.
echo ================================================
echo   [完成] 「EDM邮件Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标→退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
