@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「EDM邮件Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-608349B6-8BB6ABE5"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-608349B6-8BB6ABE5","name":"EDM邮件Agent","description":"外贸EDM邮件营销（B2B询盘培育+B2C通用）。5客户群分层×5阶段邮件序列×ABC三版模板+主题行10公式库+国别化发送时间矩阵（美/欧/中东/亚太）+送达率优化（SPF/DKIM/DMARC配置）+反垃圾15项Checklist+合规差异（GDPR/CAN-SPAM/CASL）+工具选择矩阵+"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「EDM邮件Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
