@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo ================================================
echo   安装「EDM邮件Agent」到 Accio Work
echo ================================================
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先打开并登录 Accio Work & pause & exit /b 1)
set idx=0
echo 检测到以下账号：
echo.
for /d %%i in ("%BASE%\*") do (set /a idx+=1 & set "DIR_!idx!=%%i" & echo   [!idx!] %%~nxi)
echo.
if %idx%==1 (set "CHOSEN=%DIR_1%" & echo 自动选择：%DIR_1%) else (set /p "CHOICE=请输入编号 [企业版请选企业账号]：" & set "CHOSEN=!DIR_%CHOICE%!")
if not defined CHOSEN (echo 输入无效 & pause & exit /b 1)
set "TARGET=%CHOSEN%\agents\DID-608349B6-8BB6ABE5"
if not exist "%TARGET%" mkdir "%TARGET%"
xcopy /E /I /Y "%~dp0agent-core" "%TARGET%\agent-core\" >nul 2>&1
(echo { & echo   "id": "DID-608349B6-8BB6ABE5", & echo   "name": "EDM邮件Agent", & echo   "description": "" & echo }) > "%TARGET%\profile.jsonc"
echo.
echo [完成] 安装成功！请完全退出并重启 Accio Work，在左侧找到「EDM邮件Agent」
echo.
pause
