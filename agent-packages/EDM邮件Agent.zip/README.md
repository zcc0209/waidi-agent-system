# EDM邮件Agent

外贸EDM邮件营销（B2B询盘培育+B2C通用）。5客户群分层×5阶段邮件序列×ABC三版模板+主题行10公式库+国别化发送时间矩阵（美/欧/中东/亚太）+送达率优化（SPF/DKIM/DMARC配置）+反垃圾15项Checklist+合规差异（GDPR/CAN-SPAM/CASL）+工具选择矩阵+12 sheet Excel。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
