@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「包装标签Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo 请先登录 Accio Work & pause & exit /b 1)
set idx=0
echo 检测到账号：
echo.
for /d %%i in ("%BASE%\*") do (set /a idx+=1 & set "DIR_!idx!=%%i" & echo   [!idx!] %%~nxi)
echo.
if %idx%==1 (set "CHOSEN=%DIR_1%") else (set /p "CHOICE=请输入编号[企业版选企业账号]:" & set "CHOSEN=!DIR_%CHOICE%!")
set "TARGET=%CHOSEN%\agents\DID-AD435E2B-82A44ED4"
if not exist "%TARGET%" mkdir "%TARGET%"
xcopy /E /I /Y "%~dp0agent-core" "%TARGET%\agent-core\" >nul 2>&1
(echo {"id":"DID-AD435E2B-82A44ED4","name":"包装标签Agent","description":""}) > "%TARGET%\profile.jsonc"
echo.
echo [完成] 请退出并重启 Accio Work，找到「包装标签Agent」
echo.
pause