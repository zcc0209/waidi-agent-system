@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「包装标签Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "REAL_ACCT_ID="
        for /d %%B in ("%%A\agents\MID-*") do (
            if exist "%%B\profile.jsonc" if not defined REAL_ACCT_ID (
                for /f "tokens=2 delims=: " %%V in ('findstr /i "accountId" "%%B\profile.jsonc"') do (
                    set "TMP=%%V"
                    set "TMP=!TMP:,=!"
                    set "TMP=!TMP:"=!"
                    set "TMP=!TMP: =!"
                    if not "!TMP!"=="" set "REAL_ACCT_ID=!TMP!"
                )
            )
        )
        if not defined REAL_ACCT_ID (
            for /f "tokens=1 delims=_" %%C in ("!DIR_NAME!") do set "REAL_ACCT_ID=%%C"
        )
        set "TARGET=%%A\agents\DID-AD435E2B-82A44ED4"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        set "PROF=!TARGET!\profile.jsonc"
        powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-AD435E2B-82A44ED4`",`r`n  `"accountId`": `"!REAL_ACCT_ID!`",`r`n  `"name`": `"包装标签Agent`",`r`n  `"description`": `"外贸包装/标签/唛头合规生成。按目标国法规（EU/US/UK/JP/IN/中东/拉美等）自动生成包装文案+唛头9字段+条码（EAN-13/UPC/ITF-14/QR）+多语言警示语+合规清单（CE/UKCA/FDA/BIS等）+设计稿合规扫描+常见违规预警，印刷前必过的合规检查站。`",`r`n  `"model`": {`"provider`": `"auto`",`"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"toolPreset`": `"full`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n'; Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME! (accountId=!REAL_ACCT_ID!)
        set "REAL_ACCT_ID="
    )
)
echo.
echo ================================================
echo   [完成] 「包装标签Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标→退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
