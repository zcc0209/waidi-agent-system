@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「包装标签Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-AD435E2B-82A44ED4"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-AD435E2B-82A44ED4","name":"包装标签Agent","description":"外贸包装/标签/唛头合规生成。按目标国法规（EU/US/UK/JP/IN/中东/拉美等）自动生成包装文案+唛头9字段+条码（EAN-13/UPC/ITF-14/QR）+多语言警示语+合规清单（CE/UKCA/FDA/BIS等）+设计稿合规扫描+常见违规预警，印刷前必过的合规检查站。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「包装标签Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
