# 包装标签Agent

外贸包装/标签/唛头合规生成。按目标国法规（EU/US/UK/JP/IN/中东/拉美等）自动生成包装文案+唛头9字段+条码（EAN-13/UPC/ITF-14/QR）+多语言警示语+合规清单（CE/UKCA/FDA/BIS等）+设计稿合规扫描+常见违规预警，印刷前必过的合规检查站。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
