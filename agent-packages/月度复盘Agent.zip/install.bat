@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「月度复盘Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-03ABBF9D-C2B66B3A"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-03ABBF9D-C2B66B3A","name":"月度复盘Agent","description":"外贸月度经营复盘（自动写月报）。5W2H结构+4P复盘法（Plan计划→Performed执行→Problem问题→Plan改进）；自动汇总经营数据，输出可发老板/管理层的标准月报+月会议程+行动项跟踪表+责任人+截止日期，把月底写报告从4小时压缩到30分钟。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「月度复盘Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
