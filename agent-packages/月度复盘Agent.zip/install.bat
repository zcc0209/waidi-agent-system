@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「月度复盘Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo 请先登录 Accio Work & pause & exit /b 1)
set idx=0
echo 检测到账号：
echo.
for /d %%i in ("%BASE%\*") do (set /a idx+=1 & set "DIR_!idx!=%%i" & echo   [!idx!] %%~nxi)
echo.
if %idx%==1 (set "CHOSEN=%DIR_1%") else (set /p "CHOICE=请输入编号[企业版选企业账号]:" & set "CHOSEN=!DIR_%CHOICE%!")
set "TARGET=%CHOSEN%\agents\DID-03ABBF9D-C2B66B3A"
if not exist "%TARGET%" mkdir "%TARGET%"
xcopy /E /I /Y "%~dp0agent-core" "%TARGET%\agent-core\" >nul 2>&1
(echo {"id":"DID-03ABBF9D-C2B66B3A","name":"月度复盘Agent","description":""}) > "%TARGET%\profile.jsonc"
echo.
echo [完成] 请退出并重启 Accio Work，找到「月度复盘Agent」
echo.
pause