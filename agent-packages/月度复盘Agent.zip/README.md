# 月度复盘Agent

外贸月度经营复盘（自动写月报）。5W2H结构+4P复盘法（Plan计划→Performed执行→Problem问题→Plan改进）；自动汇总经营数据，输出可发老板/管理层的标准月报+月会议程+行动项跟踪表+责任人+截止日期，把月底写报告从4小时压缩到30分钟。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
