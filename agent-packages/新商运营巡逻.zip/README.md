# 新商运营巡逻

外贸新商每日运营巡逻，自动检查店铺健康度与广告表现。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
