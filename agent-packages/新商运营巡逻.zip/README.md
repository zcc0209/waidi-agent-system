# 新商运营巡逻



**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
