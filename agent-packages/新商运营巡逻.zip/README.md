# 新商运营巡逻



**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
