@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「VIP经营Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-0553E0AE-BBA4C2C4"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-0553E0AE-BBA4C2C4","name":"VIP经营Agent","description":"外贸VIP客户经营体系（KA大客户管理）。钻石客户12项专属特权+全年9项标准触点日历+季度QBR议程模板+客户成功度量（NPS/CSAT/钱包占有率）+健康度仪表盘（红黄绿）+5大危机预警信号，防止业务员离职带走大客户。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「VIP经营Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
