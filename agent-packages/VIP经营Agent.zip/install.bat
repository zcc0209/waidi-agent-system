@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「VIP经营Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-0553E0AE-BBA4C2C4"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-0553E0AE-BBA4C2C4`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"VIP经营Agent`",`r`n  `"description`": `"外贸VIP客户经营体系（KA大客户管理）。钻石客户12项专属特权+全年9项标准触点日历+季度QBR议程模板+客户成功度量（NPS/CSAT/钱包占有率）+健康度仪表盘（红黄绿）+5大危机预警信号，防止业务员离职带走大客户。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「VIP经营Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
