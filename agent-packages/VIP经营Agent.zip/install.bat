@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「VIP经营Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-0553E0AE-BBA4C2C4"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-0553E0AE-BBA4C2C4","name":"VIP经营Agent","description":"外贸VIP客户经营体系（KA大客户管理）。钻石客户12项专属特权+全年9项标准触点日历+季度QBR议程模板+客户成功度量（NPS/CSAT/钱包占有率）+健康度仪表盘（红黄绿）+5大危机预警信号，防止业务员离职带走大客户。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「VIP经营Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
