# VIP经营Agent

外贸VIP客户经营体系（KA大客户管理）。钻石客户12项专属特权+全年9项标准触点日历+季度QBR议程模板+客户成功度量（NPS/CSAT/钱包占有率）+健康度仪表盘（红黄绿）+5大危机预警信号，防止业务员离职带走大客户。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
