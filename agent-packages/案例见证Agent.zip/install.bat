@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「案例见证Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-7DBB916F-AF9C081C"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-7DBB916F-AF9C081C","name":"案例见证Agent","description":"外贸客户案例与见证素材库。STAR结构（场景/挑战/方案/结果）+5种素材类型（书面证言/数据案例/视频证言/UGC/行业奖项）+12类采集问题清单+4种成稿模板（短证言/详情页/PDF案例集/视频脚本）+客户授权协议+8渠道投放方案，让真实数据替代模板腔说话。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「案例见证Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
