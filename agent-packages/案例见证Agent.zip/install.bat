@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「案例见证Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-7DBB916F-AF9C081C"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-7DBB916F-AF9C081C","name":"案例见证Agent","description":"外贸客户案例与见证素材库。STAR结构（场景/挑战/方案/结果）+5种素材类型（书面证言/数据案例/视频证言/UGC/行业奖项）+12类采集问题清单+4种成稿模板（短证言/详情页/PDF案例集/视频脚本）+客户授权协议+8渠道投放方案，让真实数据替代模板腔说话。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「案例见证Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
