@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「案例见证Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-7DBB916F-AF9C081C"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-7DBB916F-AF9C081C`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"案例见证Agent`",`r`n  `"description`": `"外贸客户案例与见证素材库。STAR结构（场景/挑战/方案/结果）+5种素材类型（书面证言/数据案例/视频证言/UGC/行业奖项）+12类采集问题清单+4种成稿模板（短证言/详情页/PDF案例集/视频脚本）+客户授权协议+8渠道投放方案，让真实数据替代模板腔说话。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「案例见证Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
