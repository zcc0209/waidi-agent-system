---
name: case-study-builder
description: 外贸客户案例与见证素材库智能体。当用户要求"客户案例/客户见证/case study/客户证言/testimonial/成功故事/案例上首页/合作案例/客户LOGO墙/UGC素材/视频见证"时触发，按 STAR 结构（场景/任务/行动/结果）+ 5 种素材类型（书面证言/视频证言/数据案例/UGC/行业奖项）输出案例采集 SOP + 12 类问题清单 + 4 种成稿模板（短证言/详情页/PDF案例集/视频脚本）+ 客户授权协议 + 上首页/详情页/官网/独立站投放方案。
version: 1.0.0
---

# 案例见证 Agent

## 触发场景
- 阿里国际站详情页 S5 需要客户证言模块
- 独立站 / 官网要做 LOGO 墙 + 案例
- 老板要做品牌宣传册 / 投资人材料
- 业务员谈大客户，对方要看"你们做过谁"
- 钻石客户合作 1 年，该做案例了
- 行业展会要发宣传 PDF

## 输入

必需：
- 候选客户（来自 customer-tier-segmentation 钻石/黄金客户标记"内容可用"）
- 候选订单（成功项目 / 大客户首单达成 / 客户主动表扬过的）
- 投放渠道（详情页 / 官网 / PDF / 视频 / 社媒）

可选：
- 客户授权情况（已授权 / 待沟通）
- 客户行业（B2B / 终端品牌 / 零售 / 工厂）
- 已有素材（订单数据 / 客户邮件好评 / 现场照片 / 视频）
- 公司目标受众（用什么类型客户案例最打动）

## 5 种案例素材类型

### 类型 1: 书面证言 Testimonial（基础款）

| 维度 | 内容 |
|---|---|
| 长度 | 50-150 词 |
| 来源 | 客户邮件好评 / 主动征集 |
| 配图 | 客户头像 + 公司 LOGO + 职位 |
| 用途 | 详情页 / 官网 / 邮件签名 |
| 难度 | ⭐ 低 |

### 类型 2: 数据案例 Data Case Study（专业款）

| 维度 | 内容 |
|---|---|
| 长度 | 1-2 页 PDF |
| 内容 | 合作背景+客户痛点+我方方案+量化结果 |
| 关键 | 数据真实可信（如"销售增长 35%" "节省成本 18%"） |
| 用途 | 投标 / 投资人 / 大客户提案 |
| 难度 | ⭐⭐⭐ 中高 |

### 类型 3: 视频证言 Video Testimonial（高转化）

| 维度 | 内容 |
|---|---|
| 长度 | 60-180 秒 |
| 内容 | 客户出镜+实地拍摄+真实场景 |
| 配置 | 客户面对镜头说 5-7 句话 |
| 用途 | 详情页 / 官网首页 / 社媒 / 展会 |
| 难度 | ⭐⭐⭐⭐ 高（需出差或专业拍摄） |

### 类型 4: UGC 素材 User Generated Content（最真实）

| 维度 | 内容 |
|---|---|
| 长度 | 短视频/图片 |
| 来源 | 客户主动发的开箱 / 实拍 / 上架照 |
| 配图 | 原图水印 + 客户名字 |
| 用途 | 社媒 / 详情页"用户实拍" |
| 难度 | ⭐ 低（如已有） |

### 类型 5: 行业奖项 / 媒体报道（权威背书）

| 维度 | 内容 |
|---|---|
| 类型 | Alibaba 金品诚企 / 行业协会奖 / 媒体专访 |
| 用途 | 官网 / PDF 公司介绍 |
| 难度 | ⭐⭐⭐⭐ 高（需专门申报） |

## STAR 案例结构

每个完整案例必须包含 4 要素：

```
═══ STAR 案例结构 ═══
S Situation 场景
- 客户是谁？什么行业？规模如何？
- 例：Bauhaus Trade 是德国一家中型家居品牌，年营收 €50M

T Task 挑战
- 客户面临什么具体问题？
- 例：他们之前供应商交期常拖延 30+ 天，且包装损坏率高达 5%

A Action 我方方案
- 我们具体做了什么？哪些是别人做不到的？
- 例：定制 EPE 内衬 + 提前 15 天预交付 + QC 双重检验

R Result 结果
- 量化结果（数字最有力）
- 例：交付准时率 100% / 包装损坏率降至 0.3% / 客户复购率从 1 单/季→3 单/季 / 合作 2 年累计 €1.2M
═══════════════
```

## 工作流

### Step 1: 候选案例筛选

从客户分层数据中筛选"案例可用"客户：
- 钻石客户 ≥ 6 个月合作（结果可量化）
- 客户曾主动表达满意（邮件好评、推荐新客户）
- 客户层级稳定 / 无重大客诉
- 客户行业有代表性 / LOGO 可识别
- 客户业务模式与目标受众匹配

输出"候选案例清单"按价值排序：

```
═══ 候选案例（按价值排序）═══
S 级：可上首页的"招牌案例"
- TOP-Lighting LLC（美国 Top10 灯具品牌）：合作 2 年 / 年单 $200K / 主动推荐 3 客户
- Bauhaus Trade（德国中型家居）：合作 18 个月 / 包装方案突破 / 交期 100%

A 级：可做详情页 LOGO 墙
- White Label Co / Premium Trade / Mendoza SA / ...（10 家黄金客户）

B 级：UGC 素材可用
- 12 家有客户主动发实拍/开箱
═══════════════
```

### Step 2: 客户授权沟通

主动联系客户征求授权（不能擅自用客户 LOGO/名字）：

```
═══ 案例授权邀请邮件 ═══

Hi [Name],

We've been working together for [duration] now, and your business 
has grown into one of our reference accounts.

Would you be open to letting us share your story as a customer 
case study? Specifically:

✅ Use your company logo on our website's customer page
✅ Quote your feedback on our product detail pages (50-100 words)
✅ Optional: A 60-second video testimonial (we send a videographer)

In return:
- Custom case study PDF you can use in your own marketing
- Featured spotlight on our LinkedIn (1.2K followers)
- Exclusive 5% discount on next order as thank you
- First access to new product launches

Final approval is yours — you'll see all materials before publication 
and can edit/redact anything.

Worth a quick call to discuss?

[Sales / Marketing Lead]
═══════════════
```

**预期接受率**：钻石客户 60-70% / 黄金客户 30-40% / 白银 10-20%。

### Step 3: 12 类采集问题清单

如客户同意，业务员/营销组用以下 12 问做客户访谈（30 分钟）：

```
═══ 客户案例访谈 12 问 ═══

【背景】
1. 您公司主营业务是什么？市场覆盖多少国家？
2. 您在公司负责什么？做这行多少年？

【合作前】
3. 在合作我们之前，您从哪里采购？遇到什么问题？
4. 当时最让您头疼的是什么？影响多大？

【选择我们】
5. 第一次接触我们是什么场景？什么打动您选择我们？
6. 第一单印象如何？符合预期吗？

【合作中】
7. 跟我们合作过程中，最满意的是什么？（要求具体例子）
8. 有没有发生过让您觉得"还好选了你们"的事？
9. 我们和其他供应商最大的不同是什么？

【结果】
10. 合作至今您的业务有什么变化？（销量 / 利润 / 客户反馈）
11. 您会推荐给同行吗？为什么？

【未来】
12. 接下来希望我们在哪些方面继续提升？

⚠️ 关键技巧：
- 问"具体例子"，不接受"很好/不错"等空话
- 问"数字"，不接受"很多/不少"
- 问"故事"，让客户讲场景
═══════════════
```

### Step 4: 4 种成稿模板

#### 模板 1: 短证言（详情页用，50-150 词）

```
"Working with [Supplier] has been the smoothest supplier relationship 
we've had in 10 years. Their on-time delivery is at 100% across our 
last 24 shipments, and they caught a packaging issue we hadn't 
specified — saving us thousands in returns. They feel like an 
extension of our team, not a vendor."

— [Name], [Title], [Company Name]
[Country] | [Industry]
```

#### 模板 2: 详情页迷你案例（200-400 词，附图）

```
═══ 客户案例：Bauhaus Trade ═══
[客户 LOGO]                              [产品图 / 实地照]

行业：家居品牌 | 国家：德国 | 合作时长：2 年

挑战
- 供应商交期不稳，影响门店上新节奏
- 包装运输破损率 5%，每年损失 €40K

我们做了什么
- 量身定制 EPE 内衬包装方案
- 引入双重 QC 流程（出厂 + 装柜前）
- 排期提前 15 天预生产，确保不延期

结果
- 24 次出货 100% 准时
- 包装破损率降至 0.3%
- 节省运输损失 €38K/年
- 合作首年订单 €600K，第二年 €1.2M

[客户引言]
"They feel like an extension of our team, not a vendor."
— Klaus M., Procurement Director
═══════════════
```

#### 模板 3: PDF 案例集（1-2 页，投标/投资人用）

完整 STAR 结构 + 数据图表 + 客户引言 + 公司联系方式。

#### 模板 4: 视频脚本（60-180 秒）

```
═══ 视频脚本结构 ═══
0:00-0:10 客户出场 + 公司介绍
"I'm [Name] from [Company], we're a [type] in [country]."

0:10-0:30 合作前的痛点
"Before working with [Supplier], we struggled with..."

0:30-1:00 合作的关键时刻
"The moment I knew this was different was when..."

1:00-1:30 量化结果
"In the past year, we've seen [number]..."

1:30-1:50 推荐
"If you're looking for [type of supplier], I'd recommend..."

1:50-2:00 收尾 + 公司 LOGO + CTA
═══════════════
```

### Step 5: 投放方案

按渠道差异化使用：

| 渠道 | 适用案例类型 | 数量 |
|---|---|---|
| 阿里国际站详情页 S5 | 短证言 + LOGO 墙 | 6-12 个 |
| 官网首页 | 视频证言 1 + LOGO 墙 | 1+12 |
| 官网案例页 | 完整 STAR 案例 | 4-8 个 |
| 独立站 | 视频 + 数据图表 | 同官网 |
| 公司 PDF 介绍 | PDF 案例集 | 3-5 个核心 |
| LinkedIn / 社媒 | UGC + 短证言 | 月度 1-2 |
| 邮件签名 | 一句话证言 + LOGO | 1 |
| 展会海报 | LOGO 墙 + 数据 | 12-20 |

### Step 6: 内容生命周期管理

- 每季度更新 1-2 个新案例
- 每年淘汰过期案例（合作中断 / 客户业务变更）
- 关注客户业务进展（被收购 / 上市 → 案例升级）
- 行业类型分布（不要全堆在某 1 个行业）
- 国家分布（覆盖目标市场各国）

### Step 7: 输出 Excel + PDF 案例素材库

**Sheet 1: 候选案例清单**（按价值/状态排序）
**Sheet 2: 已授权案例**（含到期时间、可用渠道）
**Sheet 3: 客户访谈记录**（12 问答+引言摘录）
**Sheet 4: 4 种成稿模板**
**Sheet 5: 投放方案**（每个渠道用什么案例）
**Sheet 6: 客户授权协议模板**（中英双语，法务审过）
**Sheet 7: 拍摄预算**（视频证言出差成本测算）
**Sheet 8: 案例 LOGO 墙**（按行业/国家分组）
**Sheet 9: 内容更新日历**（季度更新计划）
**Sheet 10: 诚实提醒**（哪些"案例"实际是凑数 / 客户业务已变 / 数据需要更新）

输出 PDF：精选 5 个案例的图文 PDF 版（1-2 页/案例，可打印投标用）。

## 注意事项

- **必须客户授权**：未经书面授权用客户 LOGO/名字 = 法律风险，必须有授权邮件或协议
- **数字必须真实**：编造数据 = 一旦被同行戳穿信誉崩盘
- **避免假证言**：业内一眼识破"the best supplier ever"等模板腔
- **照片要真实**：客户实拍 > 摆拍 > 库存图（库存图最差）
- **匿名也可以**：客户不愿出名 → "Top 5 European home brand" 这样模糊化也有效
- **不写"24/7 service"**：不写"professional team"等空话，要写具体的事
- **去 AI 化**：报告不要"建议加强案例营销"，要"钻石客户 X 已合作 18 个月、客户 NPS 9，本月必须征得授权做视频证言"
- **多元化展示**：不要全是美国客户 / 全是大客户，结合国家+行业+规模分布
- **B 端不喜欢"软文"**：海外 B 端客户对夸张证言反感，事实+数据胜过形容词
- **视频是顶级武器**：60 秒视频证言转化率比文字证言高 3-5 倍
- **客户给予回报**：案例不是免费的，要给客户实际好处（折扣 / 媒体曝光 / 行业 LOGO 互推）

## 验证

- 是否有客户授权流程（不是擅自用客户名）
- 是否包含 5 种素材类型（不只是文字证言）
- STAR 结构是否完整（不只是"客户说我们好"）
- 12 问是否要求"具体例子+数字"（不接受空话）
- 投放方案是否覆盖 8+ 渠道（不是只放详情页）
- 是否有内容更新日历（不是一锤子买卖）
- 是否警告"假证言"风险（行业最敏感）
- 是否提供"客户拒绝授权"的备选方案（匿名化）
