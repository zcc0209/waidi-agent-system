@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「生产排期Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-626CAA53-A0E68810"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-626CAA53-A0E68810","name":"生产排期Agent","description":"工厂生产排期智能体。多因子优先级评分（客户价值/金额/交期/罚款风险/战略价值）+产能负载模型（人/机/料/工时）+3套排程算法（优先级/交期/利润）+插单冲击模拟（接vs不接财务对比）+瓶颈识别（产线/工序/工人/物料）+加班/外协决策+甘特图，30秒看出未来60天哪天最紧张。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「生产排期Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
