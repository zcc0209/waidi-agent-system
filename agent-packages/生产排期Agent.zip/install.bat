@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「生产排期Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-626CAA53-A0E68810"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-626CAA53-A0E68810`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"生产排期Agent`",`r`n  `"description`": `"工厂生产排期智能体。多因子优先级评分（客户价值/金额/交期/罚款风险/战略价值）+产能负载模型（人/机/料/工时）+3套排程算法（优先级/交期/利润）+插单冲击模拟（接vs不接财务对比）+瓶颈识别（产线/工序/工人/物料）+加班/外协决策+甘特图，30秒看出未来60天哪天最紧张。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「生产排期Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
