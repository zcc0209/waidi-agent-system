---
name: repurchase-activator
description: 外贸老客户复购周期管理与主动唤醒。当用户要求"复购/老客户激活/二次下单/复购周期/补单提醒/季节性促单/老客户营销/复购率提升/Q4 备货提醒"时触发，按"产品消耗周期×客户用量×行业季节性"自动算复购窗口期+生成主动触达节奏（提前30/15/0天三波触达）+ 8 类复购话术（补单/换季/新品/促销/独家/涨价预警/年终结算/续约）+ 复购率看板 + 漏斗诊断。
version: 1.0.0
---

# 复购唤醒 Agent

## 触发场景
- 客户上次下单 90 天前，按消耗周期该补货了
- 圣诞 / 春季新品发布前，要主动找老客户预订
- 原料涨价前要提醒老客户提前备货
- 老客户复购率低，要找原因
- 月度业绩下滑，要从老客户挖增量
- 新业务员接老客户清单，不知道什么时候联系谁

## 区别于 lost-customer-recovery

| 维度 | repurchase-activator（本 agent）| lost-customer-recovery |
|---|---|---|
| 客户状态 | 仍在合作期内（<90 天） | 已流失（>180 天） |
| 触达目的 | 制造下一单（顺势） | 唤醒回归（逆势） |
| 触达节奏 | 提前预测复购窗口期 | 流失后补救 |
| 话术语气 | 自然轻松，业务对接 | 调研 / 利益 / 关系 / 刺激 4 类 |
| 转化率 | 25-50%（活跃客户） | 5-15%（流失客户） |

## 输入

必需：
- 客户清单（含上次下单日 / 客户层级 / 主要采购产品）
- 产品消耗周期（每客户 / 每订单数量 / 月销量推算）

可选：
- 客户业务模式（终端品牌 / 零售 / 工厂用 / 转售）
- 行业季节性（如圣诞 / 暑假 / 开学 / 春节备货）
- 原料价格走势（涨价预警依据）
- 公司新品发布计划
- 客户层级数据（来自 customer-tier-segmentation）

## 复购周期模型

### 产品消耗周期算法

```
复购周期 = 上次订单数量 ÷ 客户月销量 × 安全库存系数
```

**例**：客户 A 上次买 5,000 pcs LED 灯，月销 1,000 pcs → 5 个月消耗 → 加 30% 安全库存 → 复购窗口 3.5 个月后开始

### 不同产品类型的典型复购周期

| 产品类别 | 典型复购周期 | 触达时机 |
|---|---|---|
| 快消品（玩具/小百货）| 30-60 天 | 提前 7-15 天 |
| 季节性商品（圣诞/夏季）| 年度 1-2 次 | 提前 90 天 |
| 工业耗材 | 30-90 天 | 提前 15-30 天 |
| 标准商品（家居/灯具）| 60-180 天 | 提前 30-45 天 |
| 大件耐用（机械）| 1-3 年 | 提前 6 个月 |
| 个性化定制（OEM）| 不固定，按客户备货周期 | 客户启动新一轮季度时 |

### 季节性复购日历（B2B 外贸标准）

```
═══ 全年外贸采购日历 ═══
1月  备春节后空档 / 春季 SS 系列
2月  情人节后清库存 / 夏装预订（FW 转 SS）
3月  广交会春季 / 母亲节备货
4月  夏季冲量 / 开学季 BTS 备货预订
5月  万圣节 / 圣诞 Q4 备货启动（关键！）
6月  圣诞订单冲量 / 黑五备货
7月  圣诞订单截止 / 秋季 FW
8月  圣诞订单生产高峰 / 万圣节最后窗口
9月  广交会秋季 / Q4 最后冲单
10月 圣诞订单完成 / 春节前冲量启动
11月 春节前冲量
12月 春节工厂关停前最后下单 / 次年 SS 预订
═══════════════
```

### 涨价/降价预警触发

- 主要原料涨价 5%+ → 触发"涨价预警邮件"，建议老客户提前 1 个月备货
- 海运费暴涨 → 提醒提前备货
- 汇率剧烈波动 → 锁汇期提醒

## 工作流

### Step 1: 数据扫描（每日跑）

扫描所有客户：
- 距上次下单天数
- 推算消耗周期是否已到 60-80% 节点
- 行业季节性日历是否到节点
- 是否有原料涨价/海运费/汇率触发条件
- 客户层级 → 优先级排序

### Step 2: 复购窗口预测

```
═══ 客户复购窗口预测（本月触达清单）═══

钻石客户：
- TOP-Lighting LLC | 上次 2026-04-15（57 天前）| 上次 5K pcs / 月销 1.2K | 预计 6/15 用尽 | 推荐 6/1 触达

黄金客户：
- Bauhaus Trade | 上次 2026-03-20（83 天前）| 季节性 SS 已结束 | 推荐 6/15 触达 FW 新品

白银客户：
- White Label Co | 上次 2026-02-10（121 天前）| 已超预期窗口 | 推荐 立即触达 + 调研滞后原因

待 Q4 备货预约（5月触达）：
- 美国客户 12 家：圣诞备货预订（生产周期 60 天 + 海运 30 天 = 9 月底前必须下单）
- 欧洲客户 8 家：圣诞 + 新年备货
═══════════════
```

### Step 3: 8 类复购话术库

#### 类型 1: 标准补单提醒（主力，60% 场景）

```
Hi [Name],

Hope you're well. Quick note — based on your last order in [date] 
of [product/qty], you should be running close to needing a refill 
around [estimated date].

Want me to lock in another batch on the same terms? Production slot 
for that month is filling up; if I confirm by [date] I can hold your 
spot.

Same price as last time. Same packaging.

Cheers,
[Sales]
```

#### 类型 2: 季节性提前预订

```
Hi [Name],

Christmas production season is starting on our side — most US/EU 
buyers lock in slots between June and August to avoid Q4 chaos.

Looking at last year's timing, you placed your Christmas order around 
[date]. Want me to pencil you in for the same window this year? 
That way we don't get squeezed when freight rates start climbing in 
September.

Let me know your rough volume and I'll send a draft PI.

[Sales]
```

#### 类型 3: 新品发布

```
Hi [Name],

Just rolled out [new product line] — thinking of you because [specific 
reason this fits their business / market].

Sample pack on me if you want to see it before deciding. Also have 
3 customers in [your region] who already ordered, happy to share 
their feedback if useful.

Ships from us in 5 days. Let me know.

[Sales]
```

#### 类型 4: 促销/折扣（慎用）

```
Hi [Name],

Heads up — running a one-time clearance on [product] for old customers 
only this month. 8% off MSRP, MOQ 500 pcs, ends [date].

Not a regular thing — it's stock from a cancelled order I want to 
move quickly.

Interested? Reply by [date] or it's gone.

[Sales]
```

⚠️ 钻石/黄金客户慎用降价话术，会让他们怀疑日常价格合理性。

#### 类型 5: 独家 SKU / 限量

```
Hi [Name],

We just finished a small custom run of [product] — only 200 units, 
not available on our website or to other distributors.

Thinking of you because you've always asked for [feature]. Want first 
right of refusal before I list it?

Sending photos shortly.

[Sales]
```

#### 类型 6: 涨价预警（最有说服力）

```
Hi [Name],

Quick heads up — [aluminum / copper / etc.] has gone up 12% in the 
last 30 days, and we're holding old pricing through [date] only.

If you were planning a refill in Q3, locking it in this month saves 
you about [estimated $] vs ordering after [date].

PI ready in 10 mins if you want to move now.

[Sales]
```

#### 类型 7: 年终结算 / 预算花完

```
Hi [Name],

End of fiscal year coming up — many of my US customers are using up 
budget allocations in November/December.

If you have remaining purchase budget for 2026, locking in stock now 
also gives you 2027 SS-ready inventory by January.

Want me to draft an option PI you can decide on after your CFO meeting?

[Sales]
```

#### 类型 8: 续约 / 年框

```
Hi [Name],

Your annual framework agreement ends [date]. Quick proposal for 2027:

- Same price (despite material costs +8% — we're absorbing it for you)
- Add [new product] to the list
- Extend payment terms to 45 days (up from 30)

Worth a 15-min call to walk through? I'll send draft Wednesday.

[Sales]
```

### Step 4: 触达节奏（提前 30/15/0 天三波）

```
═══ 三波触达节奏 ═══

T-30: 第一波（软提醒）
- 类型：标准补单提醒 / 新品 / 涨价预警
- 渠道：邮件
- 期望转化率：25-30%

T-15: 第二波（如未回复）
- 类型：增加紧迫感（生产排期 / 库存仅剩 / 价格窗口）
- 渠道：邮件 + WhatsApp
- 期望转化率：15-20%（叠加第一波累计 40-50%）

T-0: 第三波（最后通知）
- 类型：明确"如不下单将进入 24 小时报价无效"
- 渠道：电话 + 邮件 + WhatsApp
- 期望转化率：8-12%（累计 48-62%）

如三波都无回应 → 14 天后视为"潜在流失" → 交给 lost-customer-recovery
═══════════════
```

### Step 5: 复购率看板

```
═══ 复购率仪表盘 ═══
3 个月内复购率：35%（行业平均 25%）
6 个月内复购率：58%
12 个月内复购率：72%

按客户层级：
- 钻石 D: 95%（年均 12 单）
- 黄金 G: 82%（年均 6 单）
- 白银 S: 60%（年均 3 单）
- 青铜 B: 35%（年均 1.5 单）

按产品：
- LED 系列 80%（爆款）
- 配件类 45%（散单多）
- 定制类 25%（一锤子买卖多）

复购漏斗：
- 第一单 → 第二单：65% 转化
- 第二单 → 第三单：80% 转化
- 第三单 → 终身合作：90% 转化

→ 关键瓶颈在"第一单 → 第二单"，这一关是 VIP 培育期
═══════════════
```

### Step 6: 漏斗诊断（不复购原因）

收集触达失败原因（业务员调研 + 客户回访）：
- 价格不竞争（28%）→ 给客户层级化报价 / 量大优惠
- 库存还有（22%）→ 触达时机太早，调整模型
- 转单他厂（18%）→ 关系问题，VIP 客户走 case-study + VIP 待遇
- 业务调整（12%）→ 接受现实
- 季节问题（10%）→ 调整触达月份
- 我方质量/服务问题（8%）→ 内部整改
- 客户内部决策慢（2%）

按原因分布给"年度复购率提升路线图"。

### Step 7: Q4 备货大促 SOP

每年 5-7 月跑一次"圣诞大促预订"：
- 扫描所有 D/G/S 美国/欧洲客户
- 按上年圣诞订单自动生成预测清单
- 批量发"Christmas slot booking"邮件
- 业务员逐个跟进
- 7 月底前锁定生产排期

### Step 8: 输出 Excel 复购管理报告

**Sheet 1: 复购窗口预测**（按客户层级 × 紧迫程度排序）
**Sheet 2: 本月待触达清单**（D/G/S 优先）
**Sheet 3: 季节性日历**（全年备货节点）
**Sheet 4: 8 类话术库**
**Sheet 5: 三波触达节奏 SOP**
**Sheet 6: 复购率看板**（总+分层+分品+漏斗）
**Sheet 7: 不复购原因诊断**
**Sheet 8: Q4 备货预订名单**（5-7 月主跑）
**Sheet 9: 涨价/降价预警触发清单**
**Sheet 10: 与 lost-customer-recovery 衔接清单**（3 波未响应交接）
**Sheet 11: 诚实提醒**（哪些客户该断 / 哪些被忽视 / 哪些复购周期算错）

## 注意事项

- **触达时机比话术重要**：早 1 个月白发，晚 1 个月客户已转单
- **不要每月骚扰**：钻石客户每月 1 次轻接触可，青铜客户季度 1 次足
- **降价话术伤价值**：钻石/黄金客户用涨价/独家/新品，慎用打折
- **三波节奏不是死板**：钻石客户可只用 1 波，青铜客户连 1 波都不必
- **季节性日历要本地化**：美国 vs 欧洲 vs 中东 vs 日本，节日时间不同
- **去 AI 化**：报告不要"建议加强老客户维护"，要"客户 X 上次 4/15 买 5K，月销 1.2K，6/15 用尽，5/15 必须发'生产排期'邮件锁定"
- **复购率<25% 必有问题**：行业平均 25-35%，低于说明客户体验/产品/价格出了问题
- **第一单到第二单是命门**：60% 流失发生在这一步，加强首单后 30/60 天主动跟进
- **客户层级决定话术**：钻石用"独家"，青铜用"促销"
- **三波未响应交接**：自动转给 lost-customer-recovery，不浪费业务员精力

## 验证

- 复购窗口预测是否基于具体消耗模型（不只是"上次订单+90 天"）
- 是否给 8 类话术（不只是补单提醒）
- 三波节奏是否给具体期望转化率（25%/15%/8%）
- 复购率看板是否分层级 + 分产品 + 含漏斗
- 季节性日历是否覆盖全年 12 个月
- 是否有 Q4 备货 SOP（5-7 月主跑）
- 是否定义了与 lost-customer-recovery 的衔接（3 波无响应自动交接）
- 不复购原因是否有具体百分比（不只是泛泛"价格不竞争"）
