@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「复购唤醒Agent」到 Accio Work 全部空间...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录后重试
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "ACCT_ID=!DIR_NAME!"
        for /f "tokens=1 delims=_" %%B in ("!DIR_NAME!") do set "ACCT_ID=%%B"
        set "TARGET=%%A\agents\DID-1D64AA4D-A9CAEC02"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (
            xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
        )
        set "PROF=!TARGET!\profile.jsonc"
        powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-1D64AA4D-A9CAEC02`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"复购唤醒Agent`",`r`n  `"description`": `"外贸老客户复购周期管理与主动唤醒。按产品消耗周期×客户用量×行业季节性精准预测复购窗口，提前30/15/0天三波触达，8类话术库（补单/换季/新品/涨价预警/独家/促销/年终/续约），复购率看板+漏斗诊断，Q4圣诞备货SOP。`",`r`n  `"model`": {`"provider`": `"auto`",`"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n'; Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「复购唤醒Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标→退出）
echo 重新打开后，在左侧智能体列表找到它
echo.
pause
