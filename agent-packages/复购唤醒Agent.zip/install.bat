@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「复购唤醒Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-1D64AA4D-A9CAEC02"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-1D64AA4D-A9CAEC02","name":"复购唤醒Agent","description":"外贸老客户复购周期管理与主动唤醒。按产品消耗周期×客户用量×行业季节性精准预测复购窗口，提前30/15/0天三波触达，8类话术库（补单/换季/新品/涨价预警/独家/促销/年终/续约），复购率看板+漏斗诊断，Q4圣诞备货SOP。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「复购唤醒Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
