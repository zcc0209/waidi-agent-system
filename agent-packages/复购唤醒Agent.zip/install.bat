@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「复购唤醒Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-1D64AA4D-A9CAEC02"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-1D64AA4D-A9CAEC02","name":"复购唤醒Agent","description":"外贸老客户复购周期管理与主动唤醒。按产品消耗周期×客户用量×行业季节性精准预测复购窗口，提前30/15/0天三波触达，8类话术库（补单/换季/新品/涨价预警/独家/促销/年终/续约），复购率看板+漏斗诊断，Q4圣诞备货SOP。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「复购唤醒Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
