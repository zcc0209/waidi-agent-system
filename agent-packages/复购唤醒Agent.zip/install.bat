@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「复购唤醒Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\repurchase-activator"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"repurchase-activator\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"复购唤醒Agent\",\r\n  \"description\": \"外贸老客户复购周期管理与主动唤醒。按产品消耗周期×客户用量×行业季节性精准预测复购窗口，提前30/15/0天三波触达，8类话术库（补单/换季/新品/涨价预警/独家/促销/年终/续约），复购率看板+漏斗诊断，Q4圣诞备货SOP。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「复购唤醒Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
