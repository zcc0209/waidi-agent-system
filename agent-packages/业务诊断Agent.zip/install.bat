@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「业务诊断Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-84607868-453B02DF"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-84607868-453B02DF","name":"业务诊断Agent","description":"外贸生意全面诊断（战略层医生）。8大维度（市场定位/产品/流量/转化/客户/利润/团队/风险）+行业基准对照+卡点4象限定位（高影响/低影响×易改/难改）+优先级整改清单+90天行动路径+12 sheet Excel，找出真正卡住增长的根因，而不是头痛医头。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「业务诊断Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
