@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「业务诊断Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-84607868-453B02DF"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-84607868-453B02DF","name":"业务诊断Agent","description":"外贸生意全面诊断（战略层医生）。8大维度（市场定位/产品/流量/转化/客户/利润/团队/风险）+行业基准对照+卡点4象限定位（高影响/低影响×易改/难改）+优先级整改清单+90天行动路径+12 sheet Excel，找出真正卡住增长的根因，而不是头痛医头。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「业务诊断Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
