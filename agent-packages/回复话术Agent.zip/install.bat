@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「回复话术Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-46E4D8A6-DC4E632B"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-46E4D8A6-DC4E632B","name":"回复话术Agent","description":"外贸询盘四阶段话术生成器。告诉我客户类型和当前阶段（首封/跟进/催单/挽回），生成3个版本的去AI化、去模板腔邮件话术，让买家感受到你是真人在认真对待他们。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「回复话术Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
