# 回复话术Agent

外贸询盘四阶段话术生成器。告诉我客户类型和当前阶段（首封/跟进/催单/挽回），生成3个版本的去AI化、去模板腔邮件话术，让买家感受到你是真人在认真对待他们。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
