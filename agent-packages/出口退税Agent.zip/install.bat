@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「出口退税Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-C79D75F1-C45FF0AF"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-C79D75F1-C45FF0AF","name":"出口退税Agent","description":"出口退税材料清单与进度跟踪。按HS Code自动查退税率+生成材料清单（增值税专票/报关单/出口收汇核销单/外汇收汇凭证）+申报流程SOP（备案→申报→审核→退税→到账）+退税进度跟踪+退税资金回笼预测+常见拒退原因（单证不符/归类错误/关联交易）+优化建议。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「出口退税Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
