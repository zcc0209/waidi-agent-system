@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「出口退税Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\export-tax-rebate"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"export-tax-rebate\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"出口退税Agent\",\r\n  \"description\": \"出口退税材料清单与进度跟踪。按HS Code自动查退税率+生成材料清单（增值税专票/报关单/出口收汇核销单/外汇收汇凭证）+申报流程SOP（备案→申报→审核→退税→到账）+退税进度跟踪+退税资金回笼预测+常见拒退原因（单证不符/归类错误/关联交易）+优化建议。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「出口退税Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
