@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「询盘分级Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-BB1D1622-9E09C025"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-BB1D1622-9E09C025","name":"询盘分级Agent","description":"阿里国际站询盘5级智能分级。粘贴询盘内容或截图，自动输出垃圾/小卖/批发/品牌/采购集团5级标签+置信度+优先级+建议动作，帮你在询盘海里快速排优先级。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「询盘分级Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
