# Accio

General-purpose daily assistant

分类：其他
创建时间：2026-06-17

## 使用方法
1. 在 Accio Work 中新建智能体
2. 将本包内的 SOUL.md 内容粘贴为智能体的 System Prompt
3. 安装 skills/ 目录下的技能包
