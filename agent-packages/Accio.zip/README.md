# Accio

**Windows：** 双击 install.bat（自动安装到所有空间）

**Mac：** 终端执行 bash deploy.sh

安装后完全退出 Accio Work 重新打开即可。
