# Accio

General-purpose daily assistant

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
