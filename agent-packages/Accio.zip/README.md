# Accio

General-purpose daily assistant

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
