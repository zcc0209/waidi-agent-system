@echo off
REM Bootstrap docx skill on Windows (cmd.exe).
REM
REM Mirrors bootstrap.sh: verify the pre-bundled node_modules.
REM No npm install, no network access.
REM
REM Note: in the Phoenix runtime, agent commands prefer Git Bash, which can
REM call bootstrap.sh directly. This .cmd is a fallback for native cmd.exe
REM and PowerShell environments.

setlocal enabledelayedexpansion
cd /d "%~dp0"

REM --- Preflight ----------------------------------------------------
where node >nul 2>&1
if errorlevel 1 (
  echo [bootstrap] ERROR: node not found in PATH 1>&2
  exit /b 1
)

for /f %%v in ('node -p "process.versions.node.split(\".\")[0]"') do set NODE_MAJOR=%%v
if %NODE_MAJOR% LSS 18 (
  echo [bootstrap] ERROR: Node ^>= 18.17 required 1>&2
  exit /b 1
)

REM --- Verify pre-bundled node_modules ------------------------------
if not exist node_modules (
  echo [bootstrap] ERROR: node_modules\ is missing. 1>&2
  echo [bootstrap] This skill ships node_modules\ pre-bundled in git. 1>&2
  echo [bootstrap] Your checkout is incomplete -- re-clone the repo, 1>&2
  echo [bootstrap] or if you are a maintainer, run scripts\bundle-deps.sh. 1>&2
  exit /b 1
)

REM --- Smoke test ---------------------------------------------------
call node -e "require('docx');console.log('[bootstrap] docx require() OK');"
if errorlevel 1 exit /b 1

echo [bootstrap] done
exit /b 0
