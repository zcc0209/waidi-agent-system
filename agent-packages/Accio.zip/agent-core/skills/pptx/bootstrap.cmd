@echo off
REM Bootstrap pptx skill on Windows (cmd.exe).
REM
REM Verify pre-bundled node_modules + ensure a Chromium-based browser.
REM No browser is bundled in the skill (size limit). Strategy:
REM   1. Reuse a browser found by scripts\chromium-finder.js
REM      (PHOENIX_BROWSER_PATH, %USERPROFILE%\.accio\browser\builtin, or a
REM       system Chrome/Edge/Brave/Chromium).
REM   2. If none, download Chrome-for-Testing ONCE via playwright into
REM      %USERPROFILE%\.accio\browser\builtin; cdp-browser.js then drives it.
REM   3. If the download fails, print a clear manual instruction.
REM
REM Note: in the Phoenix runtime, agent commands prefer Git Bash, which can call
REM bootstrap.sh directly (it has a download timeout watchdog this .cmd lacks).
REM This .cmd is a fallback for native cmd.exe / PowerShell.
REM
REM Tunables (env vars):
REM   PHOENIX_BROWSER_PATH         explicit browser binary; highest priority
REM   PPTX_SKIP_BROWSER_DOWNLOAD=1 never auto-download; only reuse / instruct
REM   PLAYWRIGHT_DOWNLOAD_HOST     mirror host for the browser binary

setlocal enabledelayedexpansion
cd /d "%~dp0"

set "ACCIO_BUILTIN_DIR=%USERPROFILE%\.accio\browser\builtin"

REM --- Preflight ----------------------------------------------------
where node >nul 2>&1
if errorlevel 1 (
  echo [bootstrap] ERROR: node not found in PATH 1>&2
  exit /b 1
)

for /f %%v in ('node -p "process.versions.node.split(\".\")[0]"') do set NODE_MAJOR=%%v
if %NODE_MAJOR% LSS 18 (
  echo [bootstrap] ERROR: Node ^>= 18.17 required 1>&2
  exit /b 1
)

REM --- 1. Verify pre-bundled node_modules ---------------------------
if not exist node_modules (
  echo [bootstrap] ERROR: node_modules\ is missing. 1>&2
  echo [bootstrap] This skill ships node_modules\ pre-bundled. 1>&2
  echo [bootstrap] Re-install the skill, or run scripts\bundle-deps.sh. 1>&2
  exit /b 1
)

REM --- 2. Ensure a browser -----------------------------------------
call :find_browser
if defined EXEC_PATH goto :browser_ready

if "%PPTX_SKIP_BROWSER_DOWNLOAD%"=="1" goto :browser_warn

echo [bootstrap] no browser found - downloading Chromium (~170MB, one-time)... 1>&2
if defined PLAYWRIGHT_DOWNLOAD_HOST echo [bootstrap] using mirror PLAYWRIGHT_DOWNLOAD_HOST=%PLAYWRIGHT_DOWNLOAD_HOST% 1>&2
call :download_browser
call :find_browser
if defined EXEC_PATH goto :browser_ready
goto :browser_warn

:browser_ready
echo [bootstrap] browser ready: %EXEC_PATH%
goto :smoke

:browser_warn
echo [bootstrap] WARNING: no Chromium-based browser available. 1>&2
echo [bootstrap] html2pptx / thumbnail_html need Chrome, Edge, Brave, or Chromium. 1>&2
echo [bootstrap] Resolve with ONE of: 1>&2
echo [bootstrap]   - Install Google Chrome, Microsoft Edge, or Brave, then re-run. 1>&2
echo [bootstrap]   - Point PHOENIX_BROWSER_PATH at an existing Chromium binary. 1>&2
echo [bootstrap]   - Re-run with network access to auto-download Chromium 1>&2
echo [bootstrap]     (set PLAYWRIGHT_DOWNLOAD_HOST to a mirror if the CDN is slow). 1>&2
goto :smoke

REM --- 3. Smoke test ------------------------------------------------
:smoke
call node -e "require('pptxgenjs');console.log('[bootstrap] pptxgenjs require() OK');"
if errorlevel 1 exit /b 1

echo [bootstrap] done
exit /b 0

REM ================= subroutines =================

:find_browser
set "EXEC_PATH="
if not exist node_modules\.cache mkdir node_modules\.cache
set "FINDER_TMP=node_modules\.cache\finder-out.json"
node scripts\chromium-finder.js > "%FINDER_TMP%" 2>nul
if "%errorlevel%"=="0" (
  for /f "delims=" %%n in ('node -e "process.stdout.write(JSON.parse(require('fs').readFileSync(process.argv[1],'utf8')).executablePath||'')" "%FINDER_TMP%"') do set "EXEC_PATH=%%n"
)
del /q "%FINDER_TMP%" 2>nul
exit /b 0

:download_browser
where npm >nul 2>&1
if errorlevel 1 (
  echo [bootstrap] npm not found - cannot auto-download a browser. 1>&2
  exit /b 1
)
if not exist "%ACCIO_BUILTIN_DIR%" mkdir "%ACCIO_BUILTIN_DIR%"
set "TMP_PW=%TEMP%\pptx-pw-%RANDOM%%RANDOM%"
mkdir "%TMP_PW%" 2>nul
pushd "%TMP_PW%"
call npm init -y >nul 2>&1
call npm install --no-save --no-audit --no-fund playwright-core >nul 2>&1
if errorlevel 1 (
  echo [bootstrap] failed to fetch playwright-core (downloader). 1>&2
  popd & rd /s /q "%TMP_PW%" 2>nul & exit /b 1
)
if not exist node_modules\playwright-core\cli.js (
  echo [bootstrap] playwright-core CLI missing after install. 1>&2
  popd & rd /s /q "%TMP_PW%" 2>nul & exit /b 1
)
set "PLAYWRIGHT_BROWSERS_PATH=%ACCIO_BUILTIN_DIR%"
call node node_modules\playwright-core\cli.js install chromium
if errorlevel 1 (
  echo [bootstrap] browser download failed. 1>&2
  popd & rd /s /q "%TMP_PW%" 2>nul & exit /b 1
)
popd
rd /s /q "%TMP_PW%" 2>nul
exit /b 0
