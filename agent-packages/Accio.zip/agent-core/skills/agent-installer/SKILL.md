---
name: agent-installer
description: |
  当用户想要根据一个本地Skills包、文件夹或技能说明，自动或指导一键在 Accio 客户端中批量或单个地创建智能体、配置其专属局部技能并完美上线时使用。
  请在用户提到以下场景时立刻触发本技能：
  - “帮我根据这个技能包创建智能体”
  - “一键部署智能体和配套技能”
  - “后续有类似的需求，帮助我一键安装智能体和配套技能”
  - “怎么批量安装智能体”
  - “把这套技能包打包部署上线”
---

# 🚀 智能体一键部署与技能安装器 (Agent & Skill Installer)

本技能旨在为 Accio 客户端批量/单个地快速、安全、无报错地上线全新的自定义智能体（电商底座版），并自动绑定其场景专属技能。它能完美绕过客户端针对内置官方前缀的兜底硬编码重合限制，实现个性化显示。

## 📥 核心工作流程（五步法）

### 第一步：元数据解析与场景规划
1. **扫描本地技能包**：列出用户提供的 Skills 文件夹（或压缩包解压后）中的所有子文件夹。
2. **提取技能元数据**：读取每个子文件夹内的 `.md` 或 `SKILL.md` 文件头部，提取 `name`、`description` 等元数据。
3. **规划智能体架构**：
   - 确定智能体中文名称（去掉前置的"场景1："等字符，保持简练）。
   - 为每个智能体生成一个唯一的自定义 ID（**必须以 `MID-` 开头**，格式推荐如：`MID-NEWBIZ-S01-xxx`）。
   - 确定绑定的局部的、专属的英文技能 ID（技能文件夹名）。

### 第二步：编写专业电商底座 `profile.jsonc` 配置
为每一个规划好的智能体生成 `profile.jsonc` 配置文件。
* **CRITICAL 黄金配置约束（避免重名为 Accio 助手）**：
  * **必须**将 `"agentType"` 字段和 `"templateId"` 字段统一配置为 **`"ecommerce"`**。
  * **必须**将 `"id"` 配置为以 **`"MID-"`** 开头（如 `MID-NEWBIZ-S01-PRODUCT-SELECT`）。
  * **⚠️ 人设注入（解决角色设定空白问题）**：智能体的人设由 **两个地方共同决定**，**缺一不可**：
    1. **`profile.jsonc` 中的 `config.systemPrompt`** — 定义智能体的**行为准则、专业边界与输出风格**（后台 Prompt 层）。
    2. **`agent-core/SOUL.md`** — **客户端 UI 人设区域直接渲染的文件**，如果缺失则人设区域显示为空白。
    * 两者内容需保持一致，建议以 `SOUL.md` 为首要编写目标，然后将核心身份宣言浓缩到 `config.systemPrompt` 中。
  * 包含以下标准结构：
      ```json
      "config": {
        "configVersion": 1,
        "systemPrompt": "你是一名[专业角色/身份]，...[200-500字人设与工作规范]..."
      }
      ```
  * 包含以下标准结构：
    ```json
    {
      "id": "MID-NEWBIZ-SXX-XXX",
      "accountId": "[当前账户ID]",
      "name": "新商xx",
      "description": "智能体场景描述...",
      "vibe": "professional",
      "templateId": "ecommerce",
      "templateVersion": "1.0.0",
      "model": {
        "provider": "auto",
        "name": "auto"
      },
      "defaultProject": {
        "dir": "/Users/[用户名]/.accio/accounts/[账户ID]/agents/MID-NEWBIZ-SXX-XXX/project"
      },
      "runtime": "local",
      "toolPreset": "full",
      "creator": "user",
      "agentType": "ecommerce",
      "config": {
        "configVersion": 1,
        "systemPrompt": "你是一名[专业角色/身份]，...[200-500字人设与工作规范]..."
      },
      "createdAt": "[当前时间]",
      "updatedAt": "[当前时间]",
      "localMemoryIndex": true
    }
    ```

### 第三步：在本地工作空间内进行安全打包（规避沙箱拦截）
由于安全沙箱拦截，外部 Agent 直接向 `~/.accio/accounts/` 写入极易触发审批超时。
1. 在当前 Agent 项目的工作空间内，创建一个安全的本地暂存目录：`agents_deployment/`。
2. 在该目录下，为每个智能体建立完整的物理结构（**这些文件必须全部配齐，缺一不可**）：
   - `agents_deployment/MID-NEWBIZ-xxx/profile.jsonc`
   - `agents_deployment/MID-NEWBIZ-xxx/project/`
   - `agents_deployment/MID-NEWBIZ-xxx/agent-core/skills/[英文技能ID]/`
   - `agents_deployment/MID-NEWBIZ-xxx/agent-core/diary/`
   - `agents_deployment/MID-NEWBIZ-xxx/agent-core/SOUL.md` ⚠️ **必选！客户端 UI 人设区域的渲染来源**
   - `agents_deployment/MID-NEWBIZ-xxx/agent-core/IDENTITY.md` ⚠️ **必选！智能体身份标识（Name、Role、Communication Style）**
   - `agents_deployment/MID-NEWBIZ-xxx/agent-core/AGENTS.md` ⚠️ **必选！任务定义与工作准则**
   - `agents_deployment/MID-NEWBIZ-xxx/agent-core/MEMORY.md` ⚠️ **必选！长期记忆（初始为空记忆模板）**
   - `agents_deployment/MID-NEWBIZ-xxx/agent-core/USER.md` ⚠️ **必选！用户画像**
   - `agents_deployment/MID-NEWBIZ-xxx/agent-core/BOOTSTRAP.md` ⚠️ **必选！首次启动引导**
   - `agents_deployment/MID-NEWBIZ-xxx/agent-core/TOOLS.md` ⚠️ **必选！工具列表（标准模板）**
   - `agents_deployment/MID-NEWBIZ-xxx/agent-core/HEARTBEAT.md` ⚠️ **必选！心跳文件（可空）**
3. **⚠️ 灵魂文件 SOUL.md 生成规范**：在 `agent-core/SOUL.md` 中编写智能体的身份宣言。
   - 客户端的人设 UI 区域**直接渲染 `SOUL.md` 的原始内容**，此文件是解决人设区域为空的唯一入口。
   - **内容结构**（参考下面模板）：
     - `# Soul：xxx` — 标题（智能体身份角色名）
     - 第一段：我是谁 — 第一人称身份宣示
     - 第二段：我的核心能力与工作准则
     - 第三段：我的价值观与专业约束
   - **SOUL.md 内容示例**：
     ```markdown
     # Soul：新商选品经理

     我是一名资深国际站选品经理，专精于阿里国际站产品物料包的端到端交付。我擅长从类目、关键词、商品链接或 SKU 清单出发，自动完成找货选品、候选打分、挑款报告、抓取素材、AI 制作主图与详情页、撰写标题属性和文案，并进行最终质检。

     我的交付标准是「一个产品一个文件夹」，交付可直接发品的完整物料包。我始终站在新商家的角度思考，优先选择性价比高、竞争度适中的蓝海产品。

     我不做半成品交付，不输出模糊的推荐意见，每一份选品报告都必须附带明确的下一步操作指引。
     ```
4. 将源 Skills 文件分发复制到对应的专属局部技能目录下。
   - **重命名规范**：若源文件非标准名，必须一律重命名为标准的 **`SKILL.md`** 作为技能入口。
   - **多文件对齐**：必须配齐该技能目录下的所有配套配置文件（如主图优化下的 `config.md` 等）。

### 第四步：自动编写 simobix_map.json 注册机制
1. 为每个新的智能体生成一个随机唯一的 UUID（如通过 Python 或系统工具生成）。
2. 在部署脚本中，写入针对系统核心注册表 `~/.accio/accounts/[账户ID]/simobix_map.json` 的**安全追加逻辑**：
   * **必须**优先采用 macOS 100% 默认原生自带、零编程环境依赖的 **`plutil`** 命令行工具进行安全、极速且幂等的无损键值对注入。
   * 以 Node.js / Python 3 脚本作为备用 Fallback 兼容非 Mac 的其他操作系统。

### 第五步：生成一键部署脚本并引导用户执行
1. 在项目根目录下，输出一个一键部署脚本 `deploy.sh`。
   - 该脚本包含：物理清理可能冲突的同名旧 `DID` 残留、传输全新的 `MID-` 物理文件夹、以及自动追加 `simobix_map.json` 注册映射表。
2. **⚠️ 关键 1：绝对路径定位，避免裸相对路径 (Naked Relative Path)**
   - **问题原因**：如果脚本中直接写 `agents_deployment/MID-xxx`，当用户在 `~` 目录下运行 `bash /path/to/deploy.sh` 时，bash 会在 `~/agents_deployment` 中寻找源文件，导致报错 `No such file or directory`。
   - **黄金法则**：在脚本开头获取脚本所在的绝对路径：
     ```bash
     DEPLOY_SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
     ```
   - 在后续所有引用脚本同级目录下的源文件时，**必须 100% 前缀化** 绝对路径变量，例如：
     ```bash
     # 正确 🟩：
     cp -r "$DEPLOY_SOURCE/agents_deployment/MID-NEWBIZ-xxx" "$ACCI0_ROOT/agents/"
     # 错误 🟥（绝对禁止）：
     cp -r "agents_deployment/MID-NEWBIZ-xxx" "$ACCI0_ROOT/agents/"
     ```
3. **⚠️ 关键 2：必须使用兼容 Mac 旧版 bash (3.2.x) 的语法**
   - **禁止使用** `declare -A`（关联数组，需要 bash 4.0+）
   - **禁止使用** `$(...)` 命令替换中嵌套 `declare -A`
   - **推荐使用**：为每个智能体分配独立的变量，如：
     ```bash
     AGENT_1_ID="MID-NEWBIZ-S01-PRODUCT"
     AGENT_1_UUID="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
     
     AGENT_2_ID="MID-NEWBIZ-S02-SUPPLIER"
     AGENT_2_UUID="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
     # ... 以此类推
     ```
   - 使用 `for` 循环配合独立变量名遍历，或直接展开写 6 个独立代码块
4. 为用户呈现一整套可视化的智能体上线交付清单。
5. 指导用户复制并在终端执行：
   ```bash
   bash [当前项目路径]/deploy.sh
   ```
6. 提示用户在执行成功后，**彻底重启 Accio 客户端**（或刷新列表），完成完美上线。
