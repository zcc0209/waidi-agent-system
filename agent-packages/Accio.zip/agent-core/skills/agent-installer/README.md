# 🚀 Accio 智能体一键部署与技能安装终极使用指南 (Mac & Windows 双系统全兼容)

本技能与部署包专为 **Accio 客户端** 深度定制，通过底层电商底座升级（`"agentType": "ecommerce"`）与 macOS 原生 `plutil`、Windows 原生 `PowerShell` 注入技术，实现了 **“电脑 100% 零编程环境依赖（无需 Node/Python）一秒部署、多场景智能体个性显示、精美上线”** 的极致体验！

---

## 📦 准备工作

请将接收到的 `agent-installer.zip` 压缩包在电脑上解压，您会得到：
1. 一个名为 **`agent-installer`** 的技能文件夹。
2. 本说明文档 `README.md`。

---

## 🛠️ 第一步：导入一键安装技能 (agent-installer)

您可以根据您的电脑操作系统，将解压出的整个 `agent-installer` 文件夹，移动到 Accio 系统对应目录中（推荐全局级安装）：

### 🍏 macOS 用户安装位置：
请直接将整个 `agent-installer` 文件夹，拷贝或移动到您电脑的以下路径中：
📂 **位置**：`~/.accio/accounts/<您的10位数字账号ID>/skills/`
*(快捷进入：在 Mac 终端中运行 `open ~/.accio/accounts/`，即可快速在访达中进入并放入 `skills/` 下)*

### 💻 Windows 用户安装位置：
请直接将整个 `agent-installer` 文件夹，拷贝或移动到您电脑的以下路径中：
📂 **位置**：`C:\Users\<您的电脑用户名>\.accio\accounts\<您的10位数字账号ID>\skills\`
*(快捷进入：按下键盘 `Win + R` 键，在运行窗口中输入 `%USERPROFILE%\.accio` 回车，即可直达并放入 `accounts/.../skills/` 内)*

> **🔔 激活提示**：移动完毕后，请**彻底重启**您的 Accio 客户端（或在对话框中输入 `"刷新技能"`），该技能便会立刻全自动激活上线！

---

## 🚀 第二步：在对话框中使用该技能一键部署

当您从同事那里接收到了打包好的本地 Skills 文件夹（例如 `XX Skills包`），您只需切换到安装了本技能的任意智能体窗口中，直接对它说一句话：

> **💬 “帮我根据本地路径 `[本地文件夹绝对路径]`，一键部署并安装新智能体和配套技能！”**

智能体会自动在后台为您做好全套多场景智能体的物理文件分发，配置专业的电商底座，并为您生成对应的自动化部署脚本。

---

## ⚡ 第三步：一秒运行，全自动上线！

### 🍏 macOS 用户运行步骤：
请您复制智能体为您提供的部署命令，粘贴到您的终端（Terminal）中并回车：
```bash
bash [生成的deploy.sh文件绝对路径]
```
*(系统会调用 Mac 100% 自带的 plutil 原生工具，在 0.01 秒内无损将新智能体实名登记注入您的 `simobix_map.json` 系统注册表中，无需任何 Node/Python。)*

### 💻 Windows 用户运行步骤：
1. 按下键盘 `Win + X` 键，选择 **“Windows PowerShell”** (或终端) 窗口并打开。
2. 粘贴以下两行命令并回车，解除临时执行限制并执行：
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   & "[生成的deploy.ps1文件绝对路径]"
   ```
*(PowerShell 会调用 Win10/11 原生的 JSON 编译器，在 0.01 秒内无损将新智能体实名登记注入您的 `simobix_map.json` 系统注册表中，无需任何编程环境。)*

---

## 💡 提示：重启大功告成！
运行成功后，**请彻底退出并重新打开您的 Accio 客户端**。

您会立刻看见，您左侧的智能体列表中已经多出了这批全新、名字和副标题完全独立、定位极其专业、且各自绑定了专属局部的 Skills 文件的多场景专业智能体，即可开始完美体验！
