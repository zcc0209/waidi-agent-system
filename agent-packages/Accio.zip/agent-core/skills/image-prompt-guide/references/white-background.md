# 白底图 (White Background)

## 场景说明

将商品图片的背景替换为纯白色背景，同时保持商品主体不变。适用于电商平台商品主图制作。

## 应用方式：直接应用

完整使用以下 prompt，无需拼接用户输入。

## Prompt 模板

```
Replace the background of the main product in the image with a pure white background. Keep the main product unchanged in the image.
```

## 工具调用

- 工具：`image_edit`
- task_type：`white_background`

## 注意事项

- 商品主体的颜色、结构、纹理等细节必须完整保留
- 本场景仅处理背景替换为纯白，不涉及水印处理；如需去水印请使用 Watermark Removal 场景
- **仅支持 1:1 比例**：若用户指定了非 1:1 的 `aspect_ratio`，自动切换为 `simple_generation` 执行（详见 SKILL.md aspect_ratio 判断规则第 3 条）。Prompt 仍按本场景的白底文案构建。
- **单一功能限制**：当用户请求包含 ≥2 个意图（如"换白底 + 去水印"、"白底 + 去元素"），自动降级为 `simple_generation` 执行（详见 SKILL.md Single-Purpose task_type Fallback Rule）
