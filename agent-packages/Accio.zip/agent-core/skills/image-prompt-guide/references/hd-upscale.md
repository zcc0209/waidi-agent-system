# 高清增强 (HD Upscale)

## 场景说明

对用户已有的图片进行**分辨率提升与锐化增强**，输出更清晰、细节更丰富的版本。属于单一功能场景，仅做画质增强，不修改图片内容、构图、颜色或元素。

> **场景边界（硬约束）**：本场景只做**清晰度增强**，严禁改变图片内容；不处理水印、不替换背景、不调整元素。
> - 用户希望"图片变清晰 / 提高清晰度 / upscale / enhance resolution" → 走本场景；
> - 用户希望"生成 1K/2K 的图"等**指定输出分辨率**的需求 → 见下方「分辨率请求路由规则」，可能走本场景，也可能走 `simple_generation`；
> - 用户希望"生成 4K 的图" → 当前不支持直接 4K，需先 `simple_generation` 生成 2K + 本场景增强（两步）；
> - 用户希望"清晰度增强 + 其他编辑意图（如换背景、去水印等）" → 触发 Single-Purpose Fallback，切换为 `simple_generation` 执行。

## 应用方式：Tool-Only（无需 prompt）

本场景**不需要构造 prompt**，工具会自动执行画质增强逻辑。直接将原图传入工具即可。

## 工具调用

- 工具：`image_edit`
- task_type：`hd_upscale`
- prompt：**不需要**

## 分辨率请求路由规则

当用户明确指定输出分辨率时（如 1K、2K、4K），需先判断当前 `image_edit` 工具是否支持 `resolution` 参数，再决定路由：

```
IF image_edit 工具存在 resolution 参数:
    → 使用 simple_generation，通过 resolution 参数指定目标分辨率
ELSE:
    → 路由到 hd_upscale 执行（利用超分能力提升分辨率）
```

| 用户请求 | image_edit 有 resolution 参数 | image_edit 无 resolution 参数 |
|---------|------------------------------|-------------------------------|
| "生成 1K/2K 的图" | `simple_generation`（传入 resolution 参数） | `hd_upscale`（利用超分提升） |
| "生成 4K 的图" | `simple_generation`（resolution=2K）+ `hd_upscale` | `simple_generation` 生成后 + `hd_upscale`（两步） |
| "图片变清晰" / "提高清晰度" | `hd_upscale` | `hd_upscale` |

> **关键区分**：
> - "变清晰 / 提高清晰度 / upscale" = 对**已有图片**做锐化增强 → 始终走 `hd_upscale`
> - "生成 xK 的图" = 指定**输出分辨率** → 先检查工具是否有 `resolution` 参数再决定路由
> - "生成 4K 的图" = 当前不支持直接 4K 输出 → 无论是否有 resolution 参数，都需两步执行（先生成 2K，再 `hd_upscale` 增强）

## 注意事项

- **仅支持 1:1 比例**：若用户指定了非 1:1 的 `aspect_ratio`，自动切换为 `simple_generation` 执行（详见 SKILL.md aspect_ratio 判断规则第 3 条）
- **单一功能限制**：当用户请求包含 ≥2 个意图（如"变清晰 + 换白底"、"变清晰 + 去水印"），自动降级为 `simple_generation` 执行（详见 SKILL.md Single-Purpose task_type Fallback Rule）
- **不支持直接 4K 输出**：用户要求 4K 时，必须分两步——先 `simple_generation` 生成 2K，再 `hd_upscale` 增强
- **图片内容不可改变**：本场景不会修改原图的构图、颜色、元素、背景；仅提升分辨率与清晰度
