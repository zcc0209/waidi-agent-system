@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「Accio」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-F456DA-31F456DAU1781698-9610-E4372C"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-F456DA-31F456DAU1781698-9610-E4372C","name":"Accio","description":"General-purpose daily assistant"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「Accio」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
