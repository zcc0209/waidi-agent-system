# 站外引流Agent

外贸站外广告投放策略（Google/Meta/LinkedIn/TikTok）。4大平台差异化投放：Google搜索/展示/购物+Meta B2C再营销漏斗+LinkedIn B2B职位定向+TikTok TopView/信息流；国别化投放矩阵+3档预算方案（$500/$2000/$10000+/月）+ROI/ROAS监控看板+再营销分层策略+着陆页转化优化清单+UTM追踪体系+12 sheet Excel。

分类：运营诊断
创建时间：2026-06-17

## 使用方法
1. 在 Accio Work 中新建智能体
2. 将本包内的 SOUL.md 内容粘贴为智能体的 System Prompt
3. 安装 skills/ 目录下的技能包
