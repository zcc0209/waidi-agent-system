@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「站外引流Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\ads-investment"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"ads-investment\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"站外引流Agent\",\r\n  \"description\": \"外贸站外广告投放策略（Google/Meta/LinkedIn/TikTok）。4大平台差异化投放：Google搜索/展示/购物+Meta B2C再营销漏斗+LinkedIn B2B职位定向+TikTok TopView/信息流；国别化投放矩阵+3档预算方案（$500/$2000/$10000+/月）+ROI/ROAS监控看板+再营销分层策略+着陆页转化优化清单+UTM追踪体系+12 sheet Excel。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「站外引流Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
