@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「站外引流Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-6E8C4DE8-4E60DAD2"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-6E8C4DE8-4E60DAD2","name":"站外引流Agent","description":"外贸站外广告投放策略（Google/Meta/LinkedIn/TikTok）。4大平台差异化投放：Google搜索/展示/购物+Meta B2C再营销漏斗+LinkedIn B2B职位定向+TikTok TopView/信息流；国别化投放矩阵+3档预算方案（$500/$2000/$10000+/月）+ROI/ROAS监控看板+再营销分层策略+着陆页转化优化清单+UTM追踪体系+12 sheet "}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「站外引流Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
