@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「站外引流Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "REAL_ACCT_ID="
        for /d %%B in ("%%A\agents\*") do (
            if exist "%%B\profile.jsonc" if not defined REAL_ACCT_ID (
                for /f "tokens=* usebackq" %%L in ("%%B\profile.jsonc") do (
                    echo %%L | findstr /i "accountId" >nul 2>&1 && (
                        for /f "tokens=2 delims=:, " %%V in ("%%L") do (
                            set "TMP=%%V"
                            set "TMP=!TMP: =!"
                            set "TMP=!TMP:"=!"
                            if not "!TMP!"=="" set "REAL_ACCT_ID=!TMP!"
                        )
                    )
                )
            )
        )
        if not defined REAL_ACCT_ID (
            for /f "tokens=1 delims=_" %%C in ("!DIR_NAME!") do set "REAL_ACCT_ID=%%C"
        )
        set "TARGET=%%A\agents\DID-6E8C4DE8-4E60DAD2"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        set "PROF=!TARGET!\profile.jsonc"
        powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-6E8C4DE8-4E60DAD2`",`r`n  `"accountId`": `"!REAL_ACCT_ID!`",`r`n  `"name`": `"站外引流Agent`",`r`n  `"description`": `"外贸站外广告投放策略（Google/Meta/LinkedIn/TikTok）。4大平台差异化投放：Google搜索/展示/购物+Meta B2C再营销漏斗+LinkedIn B2B职位定向+TikTok TopView/信息流；国别化投放矩阵+3档预算方案（$500/$2000/$10000+/月）+ROI/ROAS监控看板+再营销分层策略+着陆页转化优化清单+UTM追踪体系+12 sheet `",`r`n  `"model`": {`"provider`": `"auto`",`"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"toolPreset`": `"full`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n'; Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME! (accountId=!REAL_ACCT_ID!)
        set "REAL_ACCT_ID="
    )
)
echo.
echo ================================================
echo   [完成] 「站外引流Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标→退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
