@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「站外引流Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-6E8C4DE8-4E60DAD2"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-6E8C4DE8-4E60DAD2","name":"站外引流Agent","description":"外贸站外广告投放策略（Google/Meta/LinkedIn/TikTok）。4大平台差异化投放：Google搜索/展示/购物+Meta B2C再营销漏斗+LinkedIn B2B职位定向+TikTok TopView/信息流；国别化投放矩阵+3档预算方案（$500/$2000/$10000+/月"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「站外引流Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
