<!-- ACCIO_WORK:BEGIN_CONNECTED_ACCOUNTS -->
## Connected Accounts

The user has connected the following third-party services. You can use the corresponding tools to access these services on behalf of the user.

- **Gmail**: xxu219999@gmail.com
  For Gmail operations, run `accio-mcp-cli toolkit gmail` with `bash` tool to list available tools, and read the `gmail-assistant` skill for usage patterns and examples.
- **OKKI**: passport:442304:56873874
- **OKKI**: passport:18617:55259805
- **OKKI**: passport:18137:55257804
- **OKKI**: passport:364481:57196176
- **LinkedIn**: queeniehsu11240@gmail.com
- **github**: 1141424377@qq.com
  For ANY GitHub operation (list/filter repos/stars/issues/PRs; create/fork repos; create or modify issues/PRs; submit reviews; merge PRs), read the `github-tools` skill first. The skill covers scope-aware `filter` defaults, action-dispatched write tools, full-replacement `set_*` semantics, capability gaps, and organization access management. If org-scoped operations fail with 403 (e.g. after joining a new org), use `manage_github_org_access` — re-running `start_github_auth` will NOT show the org selection screen. Do NOT invent tool names — discover the real surface via `accio-mcp-cli toolkit github`.
- **Alibaba.com**: ineed123 (user_email: jam***@163.com, connector_id: 586dd5303dcd, ali_id: 2201273220358, service_type: cgs, company_name: Chengdu Ailide Technology Co., Ltd.)
- **Alibaba.com**: aliqatest01 (user_email: tes***@proton.me, connector_id: 0d260295f87c, ali_id: 17379911544, service_type: cgs, company_name: testcompany)
- **Twitter/X**: haomaison (x_user_id: 2070024052685848576)
  For posting / scheduling / analytics on Twitter/X, read the `social-media-publisher` skill for the supported workflow.
<!-- ACCIO_WORK:END_CONNECTED_ACCOUNTS -->