@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo 安装「入职培养Agent」...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-8E6EB61F-1BDBE268"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-8E6EB61F-1BDBE268","name":"入职培养Agent","description":"外贸新人入职30/60/90天培养计划。按4类岗位（业务员/跟单/运营/设计）输出90天逐周路线图+入职文档大礼包+师徒制配对方案（含奖金机制）+30/60/90三节点考核标准+5大流失预警信号+转正答辩SOP，新人入职第一周决定50%留存率。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「入职培养Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开
echo.
pause
