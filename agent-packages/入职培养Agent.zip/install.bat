@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「入职培养Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-8E6EB61F-1BDBE268"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-8E6EB61F-1BDBE268`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"入职培养Agent`",`r`n  `"description`": `"外贸新人入职30/60/90天培养计划。按4类岗位（业务员/跟单/运营/设计）输出90天逐周路线图+入职文档大礼包+师徒制配对方案（含奖金机制）+30/60/90三节点考核标准+5大流失预警信号+转正答辩SOP，新人入职第一周决定50%留存率。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「入职培养Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
