# 报价单Agent

外贸阶梯报价单生成。按客户类型（小卖/批发/品牌/集团）输出差异化报价策略：阶梯价表（MOQ×数量×价格）+INCOTERMS选择+付款方式+汇率锁定+运费测算+砍价预案（底价/让步空间/捆绑条件）+PDF可打印PI模板，让每份报价都是一套谈判剧本。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
