@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「报价单Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-0A2C17F1-A9FCC213"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-0A2C17F1-A9FCC213","name":"报价单Agent","description":"外贸阶梯报价单生成。按客户类型（小卖/批发/品牌/集团）输出差异化报价策略：阶梯价表（MOQ×数量×价格）+INCOTERMS选择+付款方式+汇率锁定+运费测算+砍价预案（底价/让步空间/捆绑条件）+PDF可打印PI模板，让每份报价都是一套谈判剧本。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「报价单Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
