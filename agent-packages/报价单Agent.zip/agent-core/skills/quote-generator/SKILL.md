---
name: quote-generator
description: 外贸阶梯报价单生成。当用户要求"出报价/报个价/做PI/阶梯价/proforma invoice/quotation/quote"且涉及外贸/阿里国际站场景时触发，按客户类型（小卖/批发/品牌/集团）输出差异化报价策略，含阶梯价表+INCOTERMS+付款方式+汇率锁定+运费测算+砍价预案+PDF可打印PI模板。
version: 1.0.0
---

# 报价单 Agent（阶梯报价 + 谈判预案）

## 触发场景
- 客户询盘后要求报价
- 业务员每天出 5-10 份报价没标准模板
- 大客户要 PI 锁单
- 同一款产品对不同国家/不同客户要差异化报价
- 老板想看下属报价是否合理（防低价跑单）

## 输入

必需：
- 产品名 + 规格 + 出厂价（USD/件）
- 客户类型（小卖/批发/品牌/集团；可调用 inquiry-triage 判断）
- 目标国家
- 客户询的数量

可选：
- 客户公司名（调 buyer-background-check 判定砍价空间）
- 当前汇率 / 原材料价格波动情况
- 是否首单 / 老客户重复订单
- 包装规格（影响海运体积）
- 是否含认证（CE/FCC/UL 等加价依据）

## 工作流

### Step 1: 报价策略选择（按客户类型）

| 客户类型 | 报价策略 | 让利空间 | 付款建议 |
|---|---|---|---|
| L1 小卖 | 一口价 + 高溢价 | 5% 以内 | T/T 100% 前付 |
| L2 批发 | 阶梯价 + 标准毛利 | 8-10% | T/T 30/70 或 L/C at sight |
| L3 品牌 | 阶梯价 + 长期合作价 | 10-15% | L/C 30 天 或 OA 30 天（信保） |
| L4 集团 | 锚定高价 + 多层阶梯 + 年框 | 15-20% | OA 60-90 天 + 信保 |

### Step 2: 阶梯价梯度设计

标准 4 档梯度（按询盘数量动态调整）：
- T1: MOQ 起（如 100 件）→ 报价 = 出厂价 × (1 + 毛利率)
- T2: T1 × 5（如 500 件）→ 单价降 3-5%
- T3: T1 × 20（如 2000 件）→ 单价降 8-10%
- T4: T1 × 100（如 10000 件）→ 单价降 12-15%

**反套路提醒**：T1 价格要锚定够高，给后面让步留空间；不要 T1 就报底价。

### Step 3: INCOTERMS 与付款方式匹配

|国家组|推荐 INCOTERMS|付款方式|风险预警|
|---|---|---|---|
|欧美主流（DE/FR/UK/US/CA）|FOB / CIF|T/T 30/70 或 L/C / OA+信保|相对安全|
|拉美（BR/AR/MX）|CIF|100% L/C at sight|外汇管制，慎接 D/A|
|中东（AE/SA/EG）|CIF / DDP|T/T 50/50 或 L/C|D/A 高风险|
|非洲|CIF|100% T/T 前付|D/A、O/A 不接|
|印度|FOB|100% T/T 前付 或 L/C|BIS 认证别忘|
|俄罗斯|FCA / CPT|100% T/T 卢布或欧元|SWIFT 制裁风险|
|东南亚|FOB / CIF|T/T 30/70|相对宽松|

### Step 4: 汇率与成本锁定建议

- 报价标 "Valid until: [日期]"，欧美客户 15 天，新兴市场 7 天
- 汇率波动 >2% 时建议加 "Subject to exchange rate adjustment if RMB/USD fluctuates >2%"
- 原材料价格波动大的品类（金属/化工/电子）加 "Price subject to raw material market"
- 海运费报价单独列，不打包进 CIF（CIF 含海运但波动大）

### Step 5: 砍价预案（每份报价附带）

输出 **3 档让步方案**（业务员谈判时心里有数）：

```
报价：$10.50 / 件 @ MOQ 1000
让步方案：
├─ 友好让步：$10.20（-3%）→ 用于客户首次砍价/老客户/有诚意签单
├─ 中性让步：$9.80（-7%）→ 用于客户对比报价/坚持砍价
└─ 底线让步：$9.50（-10%）→ 用于大单/年框/品牌客户/锁定老客户
红线：$9.20（-12%）以下不接，宁可流单
```

### Step 6: 输出格式

**生成两份文件**：

**A. 阶梯报价表（Excel）**

| 数量阶梯 | 单价 USD | 总价 USD | 节省 % | INCOTERMS | Lead Time | 付款方式 | 有效期 |

**B. PI（Proforma Invoice）PDF**

完整 PI 字段：
- Seller / Buyer 信息（公司名、地址、联系人、邮箱、电话）
- PI No. + Date + Validity
- 产品明细（HS Code / Description / Specs / Qty / Unit Price / Amount）
- Total Amount in figures + in words
- INCOTERMS（注明具体港口，如 FOB Shanghai）
- Payment Terms（具体到 % 和天数）
- Lead Time（订金到账后 X 工作日）
- Shipment（预计装运港 + 目的港 + 海运/空运）
- Packing（外箱尺寸 + 毛重/净重 + 20'/40' 装柜量）
- Bank Information（受益人 / Bank Name / SWIFT / Account / Address）
- 备注（认证、检验、原产地证、保险等）
- 卖方签字盖章位

字体：英文 Arial，中文 Microsoft YaHei
颜色：表头深蓝 #0A2540，金额行浅黄 FFF2CC

### Step 7: 谈判筹码备忘录（业务员内部用，不发客户）

```
═══ 内部备忘 ═══
客户：[公司名]
背调结果：[业务模式+采购量+合作风险]
报价毛利率：[X%]
让步空间：[详见 3 档方案]
推荐 INCOTERMS：[XXX]，原因：[XXX]
推荐付款方式：[XXX]，原因：[XXX]
若客户砍价 → 优先让什么：[运费/付款方式/MOQ/账期]
若客户消失 → 第 3 天用 [话术 A]，第 7 天用 [话术 B]
═══════════════
```

## 注意事项

- **不要见客户就让步**：T1 价格要高、阶梯要陡，给谈判留空间
- **付款方式比单价重要**：L4 集团客户经常用 OA 90 天压你的现金流，要测算资金成本是否吃得消
- **INCOTERMS 别只会 FOB**：DDP 现在很多欧美电商客户在要求，要会算关税
- **汇率锁定要写进 PI**：2024 起人民币波动剧烈，不锁汇率分分钟变亏单
- **去 AI 化**：备注栏不要写"We are professional manufacturer..."，写"3 sets of CE test reports attached; sample available within 5 days"
- **PI 不是越花哨越好**：表格清晰 + 字段齐全 > 彩色 banner，B 端买家最讨厌花哨
- **小客户也要给阶梯**：哪怕 L1，给 T1/T2 两档，刺激他多订一点

## 验证

- PI 是否包含 15 个必备字段（Seller/Buyer/Date/Validity/HS Code/Specs/Qty/Price/Amount/INCOTERMS/Payment/Lead Time/Shipment/Packing/Bank）
- 阶梯价是否陡度合理（T4 比 T1 降 12-15%）
- 让步方案是否 3 档清晰，红线是否守得住
- 付款方式与国家风险是否匹配（D/A 不报给中东/非洲新客户）
- 谈判筹码备忘录是否帮业务员形成"出招前心里有底"
