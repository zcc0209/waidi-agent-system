@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo 安装「新商询盘诊断」...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\MID-NEWBIZ-S05-INQUIRY-DIAG"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"MID-NEWBIZ-S05-INQUIRY-DIAG","name":"新商询盘诊断","description":""}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「新商询盘诊断」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，找到左侧智能体
echo.
pause
