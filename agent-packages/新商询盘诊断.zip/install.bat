@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「新商询盘诊断」到 Accio Work 全部空间...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录后重试
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "ACCT_ID=!DIR_NAME!"
        for /f "tokens=1 delims=_" %%B in ("!DIR_NAME!") do set "ACCT_ID=%%B"
        set "TARGET=%%A\agents\MID-NEWBIZ-S05-INQUIRY-DIAG"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (
            xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
        )
        set "PROF=!TARGET!\profile.jsonc"
        powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"MID-NEWBIZ-S05-INQUIRY-DIAG`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"新商询盘诊断`",`r`n  `"description`": `"`",`r`n  `"model`": {`"provider`": `"auto`",`"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n'; Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「新商询盘诊断」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标→退出）
echo 重新打开后，在左侧智能体列表找到它
echo.
pause
