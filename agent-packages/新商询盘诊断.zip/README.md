# 新商询盘诊断



**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
