# 新商询盘诊断

外贸新商询盘质量诊断，识别高意向买家，提升询盘转化率。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
