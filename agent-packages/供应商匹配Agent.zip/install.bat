@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「供应商匹配Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-9F1F1466-898B47FC"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-9F1F1466-898B47FC","name":"供应商匹配Agent","description":"外贸供应商匹配与比价。4渠道搜索（1688/阿里国际站工厂版/Made-in-China/行业展会）；5维打分矩阵（价格/质量/交期/服务/稳定性）；漏斗筛选30家初筛→10家短名单→3家终选；价格比对表+MOQ协商话术+验厂前自检清单（12项）+Kill List（黑名单工厂特征）+12 sheet Excel。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「供应商匹配Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
