@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「供应商匹配Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\supplier-matcher"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"supplier-matcher\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"供应商匹配Agent\",\r\n  \"description\": \"外贸供应商匹配与比价。4渠道搜索（1688/阿里国际站工厂版/Made-in-China/行业展会）；5维打分矩阵（价格/质量/交期/服务/稳定性）；漏斗筛选30家初筛→10家短名单→3家终选；价格比对表+MOQ协商话术+验厂前自检清单（12项）+Kill List（黑名单工厂特征）+12 sheet Excel。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「供应商匹配Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
