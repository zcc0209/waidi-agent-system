# 供应商匹配Agent

外贸供应商匹配与比价。4渠道搜索（1688/阿里国际站工厂版/Made-in-China/行业展会）；5维打分矩阵（价格/质量/交期/服务/稳定性）；漏斗筛选30家初筛→10家短名单→3家终选；价格比对表+MOQ协商话术+验厂前自检清单（12项）+Kill List（黑名单工厂特征）+12 sheet Excel。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
