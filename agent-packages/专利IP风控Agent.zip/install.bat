@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「专利IP风控Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\patent-ip-risk"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"patent-ip-risk\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"专利IP风控Agent\",\r\n  \"description\": \"外贸专利与知识产权风控（侵权规避）。覆盖3大专利类型（发明/外观/实用新型）×5大市场（US/EU/UK/DE/JP）检索+FTO（Freedom to Operate）分析+规避设计建议+337调查应对SOP+侵权成本量化（ITC禁令→全线停售损失）+Kill List（高侵权风险产品）+3档方案+12 sheet Excel，先查专利再打样，不要做完才发现侵权。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「专利IP风控Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
