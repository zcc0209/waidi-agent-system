@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「专利IP风控Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-37A2CBCB-9A9F39D5"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-37A2CBCB-9A9F39D5","name":"专利IP风控Agent","description":"外贸专利与知识产权风控（侵权规避）。覆盖3大专利类型（发明/外观/实用新型）×5大市场（US/EU/UK/DE/JP）检索+FTO（Freedom to Operate）分析+规避设计建议+337调查应对SOP+侵权成本量化（ITC禁令→全线停售损失）+Kill List（高侵权风险产品）+3档方案+12 sheet Excel，先查专利再打样，不要做完才发现侵权。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「专利IP风控Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
