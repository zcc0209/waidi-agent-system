@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「专利IP风控Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-37A2CBCB-9A9F39D5"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-37A2CBCB-9A9F39D5","name":"专利IP风控Agent","description":"外贸专利与知识产权风控（侵权规避）。覆盖3大专利类型（发明/外观/实用新型）×5大市场（US/EU/UK/DE/JP）检索+FTO（Freedom to Operate）分析+规避设计建议+337调查应对SOP+侵权成本量化（ITC禁令→全线停售损失）+Kill List（高侵权风险产品）+3档方案"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「专利IP风控Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
