#!/bin/bash
AGENT_NAME="专利IP风控Agent"
AGENT_ID="DID-37A2CBCB-9A9F39D5"
ACCIO_BASE="$HOME/.accio/accounts"
ACCOUNT_DIR=$(ls "$ACCIO_BASE" | head -1)
TARGET="$ACCIO_BASE/$ACCOUNT_DIR/agents/$AGENT_ID"
mkdir -p "$TARGET"
SCRIPT_DIR="$( cd "$( dirname "$0" )" && pwd )"
cp -r "$SCRIPT_DIR/agent-core" "$TARGET/"
printf '{"id":"%s","name":"%s","description":""}' "$AGENT_ID" "$AGENT_NAME" > "$TARGET/profile.jsonc"
echo "✅ 安装完成！请重启 Accio Work"
