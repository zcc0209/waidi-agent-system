# 专利IP风控Agent

外贸专利与知识产权风控（侵权规避）。覆盖3大专利类型（发明/外观/实用新型）×5大市场（US/EU/UK/DE/JP）检索+FTO（Freedom to Operate）分析+规避设计建议+337调查应对SOP+侵权成本量化（ITC禁令→全线停售损失）+Kill List（高侵权风险产品）+3档方案+12 sheet Excel，先查专利再打样，不要做完才发现侵权。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
