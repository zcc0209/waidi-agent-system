---
name: store-decoration
description: 外贸店铺装修智能体（阿里 / Amazon / 独立站通用）。当用户要求"店铺装修/店铺首页/Brand Store/品牌旗舰店/Storefront/店铺设计/店铺 banner/店铺导航/旺铺装修/About Us/Company Profile/Showcase/店铺视觉/移动端适配"时触发，输出 3 平台（阿里旺铺/Amazon Brand Store/Shopify 独立站）× 6 大模块（Hero Banner/品类导航/主推爆款/公司故事/客户证言/FAQ-CTA）+ 行业视觉风格库 + 移动端适配 + 国别化视觉差异 + 12 sheet Excel + 诚实提醒。
version: 2.0.0
---

# 外贸店铺装修智能体（深度版）

> 一句话定位：把你的店铺从"产品货架"变成"品牌展厅"——3 平台通用、6 模块标准化、行业风格可选、移动端优先。

---

## 触发场景

- "帮我装修一下阿里店铺首页"
- "Amazon Brand Store 怎么搭？"
- "独立站首页应该放什么？"
- "店铺 Banner 帮我写文案"
- "我的 About Us 页面不行，帮我重写"
- "店铺移动端打开很丑，怎么优化"
- "品牌旗舰店要怎么设计"

---

## 输入要求

用户须提供（缺一追问）：

| 项目 | 说明 | 示例 |
|---|---|---|
| 平台 | 阿里国际站 / Amazon / Shopify / 多平台 | 阿里国际站 |
| 品类 | 主营产品大类 | LED 照明 |
| 目标市场 | Top 3 国家/地区 | 美国/德国/澳洲 |
| 公司背景 | 工厂/贸易/品牌 + 年限 + 规模 | 工厂 12 年、200 人 |
| 核心卖点 | 3-5 个差异化点 | ODM 能力、UL 认证、48h 打样 |
| 现有素材 | 有无 LOGO/产品图/工厂图/视频 | 有 LOGO + 产品图 |
| 痛点 | 目前最不满意什么 | 首页跳出率 70% |

---

## 工作流

### Phase 1：平台诊断（10 分钟）

**Step 1：现状扫描**

如用户提供店铺链接，执行：

```
诊断维度：
1. 首屏 3 秒印象 — 能否一句话说清"你是谁、卖什么、为什么选你"
2. 导航逻辑 — 品类分组是否符合买家采购习惯（按用途 > 按型号）
3. 信任要素 — 认证/工厂/客户 LOGO 是否在首屏可见
4. 移动端体验 — 手机端是否图片变形、文字过小、CTA 不可点
5. 加载速度 — 图片是否过大（>500KB）导致慢
6. CTA 路径 — 从首页到询盘最少几步（>3 步就有问题）
```

**Step 2：竞品参考**

```
在同品类 Top 10 店铺中提取：
- 首页结构（模块顺序 + 数量）
- 视觉风格（色调/排版/图片风格）
- 信任元素呈现方式
- 独特模块（如 R&D Center Tour、Customization Flow Chart）
```

---

### Phase 2：6 大模块结构化输出

#### 模块 1：Hero Banner（首屏 = 3 秒生死线）

```
必须元素（缺一不可）：
├── 品牌 LOGO（左上角，高度 ≤ 60px）
├── 核心口号（1 行 ≤ 10 个英文词，字号最大）
│   公式：[动词] + [核心价值] + [信任背书]
│   示例："Illuminate Smarter — 12 Years OEM/ODM LED Factory"
├── 信任徽章行（2-4 个）
│   [UL Listed] [ISO 9001] [12 Years] [500+ Clients]
├── 主视觉产品图（1-2 个拳头产品，白底 or 场景图）
└── CTA 按钮（1 个，明确行动）
    "Get Free Quote" / "View Catalog" / "Chat Now"
```

**国别化差异**：

| 目标市场 | 视觉偏好 | 口号风格 | 注意事项 |
|---|---|---|---|
| 北美 | 简洁大气、留白多 | 直接、数据驱动 | 避免过度承诺 |
| 欧洲 | 精致克制、环保色调 | 强调合规+可持续 | 需 CE/UKCA 标志 |
| 中东 | 金色奢华、对比强烈 | 强调品质+价格优势 | RTL 布局考虑 |
| 日韩 | 信息密集、细节丰富 | 参数+认证优先 | JIS/PSE 标志 |
| 拉美 | 鲜艳活力、情感化 | 热情、合作导向 | 西语优先 |
| 东南亚 | 性价比突出、促销风格 | 强调 MOQ 灵活 | 价格敏感 |

**行业视觉风格库**：

| 行业 | 主色调 | 图片风格 | 排版 |
|---|---|---|---|
| 机械/工业品 | 深蓝+银灰 | 工厂实拍+设备特写 | 参数表格多 |
| 消费电子 | 黑白+科技蓝 | 白底产品+生活场景 | 极简排版 |
| 家居/家纺 | 大地色系+暖色 | 家居场景图为主 | 大图留白 |
| 服装/鞋帽 | 品牌色+中性灰 | 模特穿搭+平铺 | 瀑布流 |
| 美妆/个护 | 柔粉+金色 | 产品氛围图+质地特写 | 高级感 |
| 食品/农产品 | 绿色+原木 | 产地实拍+加工过程 | 信任优先 |
| 汽配/摩配 | 黑红+碳纤维纹理 | 安装实拍+兼容性表 | 技术参数多 |

#### 模块 2：品类导航（让买家 3 秒找到想要的）

```
导航设计原则：
├── 按买家用途分类（不是按你的型号分）
│   ❌ "XD-100 / XD-200 / XD-300"
│   ✅ "Indoor Lighting / Outdoor Lighting / Smart Lighting"
├── 分类数量：5-8 个（超过 8 用二级）
├── 每个分类配 1 张代表图 + 产品数量
├── 热销标签："🔥 Best Seller" / "⭐ New Arrival"
└── 视觉统一：所有分类图同尺寸、同背景、同角度
```

**分类逻辑 4 种方式（按品类选）**：

| 分类方式 | 适合品类 | 示例 |
|---|---|---|
| 按用途/场景 | 照明/家具/家纺 | Bedroom / Living Room / Commercial |
| 按材质/工艺 | 金属/塑料/纺织 | Stainless Steel / Aluminum / Carbon Steel |
| 按终端用户 | 工业品/安防 | Residential / Commercial / Industrial |
| 按产品线 | 消费电子/美妆 | Headphones / Speakers / Accessories |

#### 模块 3：主推爆款区（流量承接核心）

```
主推品选择标准：
├── 询盘量 Top 5 产品
├── 利润率 > 行业均值的产品
├── 有差异化卖点的产品（不是价格最低的）
├── 有认证/专利的产品
└── 每个主推品展示：
    ├── 1 张精修主图（白底 or 场景）
    ├── 1 行卖点（≤ 15 词）
    ├── 价格区间（FOB $X.XX - $X.XX）
    ├── MOQ 标注
    ├── 信任标签（CE/UL/Patent 等）
    └── CTA："Get Quote" / "View Detail"
```

**爆款排列策略**：

```
位置 1（最大展示位）：利润最高的差异化品（不是最便宜的）
位置 2-3：询盘量 Top 2
位置 4-6：新品 / 季节品 / 定制品
```

#### 模块 4：公司故事 / About Us（建立信任的核心）

```
About Us 7 段结构（从买家视角写，不是自我吹嘘）：

1. 开场钩子（1 句话说清你是谁）
   "Since 2012, we've helped 500+ brands bring their lighting ideas to life."
   
2. 核心能力（3 个图标 + 1 句话）
   [🏭 Own Factory] [📐 ODM/OEM] [🚀 48h Sample]
   
3. 规模证明（用数字说话）
   "200 workers | 15,000 m² | 50+ monthly containers | 30+ countries"
   
4. 认证墙（所有认证 LOGO 排列）
   UL | CE | RoHS | ISO 9001 | BSCI | Sedex
   
5. 工厂巡览（4-6 张实拍 or 视频）
   原料仓 → 产线 → QC 实验室 → 包装 → 出货
   
6. 客户 LOGO 墙（6-12 个知名客户 LOGO）
   获客户授权再放；没有可写 "Trusted by 500+ clients in 30+ countries"
   
7. CTA（明确下一步）
   "Tell Us Your Project — Get a Quote in 24h"
```

**写作铁律**：
- 不说 "We are a professional manufacturer"（每家都这么写）
- 用 "We help [客户类型] solve [具体问题]" 开头
- 数字 > 形容词（"12 years" > "many years of experience"）
- 客户视角 > 自我视角（"You get" > "We provide"）

#### 模块 5：客户证言 / Social Proof

```
证言呈现 3 种方式：

方式 1：文字证言卡（最容易做）
├── 客户头像/公司 LOGO
├── 客户名 + 公司 + 国家
├── 1-2 句真实评价
└── 星级评分

方式 2：数据证言（最有说服力）
"98.5% on-time delivery rate in 2024"
"Average 4.8/5.0 from 200+ reviews"

方式 3：视频证言（转化率最高）
30s 客户出镜说："Why I chose [品牌]"
→ 放在 About Us 页面 or 首页滚动
```

**获取证言 SOP**：

```
时机：验货通过 or 客户收货后 7 天
话术：
"Hi [Name], glad the shipment arrived well! 
Would you mind sharing a quick feedback? 
Just 1-2 sentences about your experience — 
it really helps other buyers trust us. 
We can keep it anonymous if you prefer."

激励（可选）：下次订单 2% 折扣 or 免费样品
```

#### 模块 6：FAQ + CTA 底部

```
FAQ 设计（5-8 个高频问题）：

必选问题：
1. "What's your MOQ?" → 按品类回答
2. "Can I get a sample first?" → 免费/收费+时间
3. "How long is the lead time?" → 标准 + 旺季提醒
4. "Do you support OEM/ODM?" → 能力描述 + 案例
5. "What certifications do you have?" → 列表 + 可提供副本

按行业追加：
- 机械："What's the warranty?" / "Do you provide installation support?"
- 食品："Do you have FDA/HACCP?" / "What's the shelf life?"
- 服装："Can I customize labels/packaging?" / "What sizes do you cover?"
- 电子："What's the defect rate?" / "Can you do private labeling?"
```

**底部 CTA 设计**：

```
3 种 CTA 按钮（提供不同行动路径）：
[🟢 Get Free Quote]  — 最重要，颜色最突出
[📋 Download Catalog] — 中间选项
[💬 Chat with Us]    — 即时沟通

CTA 上方加一句话：
"Ready to start? Tell us your idea — response within 24h."
```

---

### Phase 3：3 平台差异化适配

#### 阿里国际站旺铺

```
特殊模块：
├── 旺铺 2.0 模板选择（官方提供 6 套）
├── Showcase 橱窗（最多 5 个产品分组 × 20 个产品）
│   命名规则：按买家搜索词命名，不是内部型号
│   ✅ "Commercial LED Panel Light" 
│   ❌ "XD Series"
├── 公司档案完整度（影响搜索排名）
│   企业类型 + 注册资本 + 出口比例 + 认证 + 工厂图 + 视频
├── RFQ 关联 — 确保首页有"Post Buying Request"入口
└── 多语言站点（如有星级店铺权限）
```

**阿里旺铺诊断 10 项**：

| 检查项 | 达标标准 | 常见问题 |
|---|---|---|
| 公司档案完整度 | ≥ 90% | 缺工厂视频/认证扫描件 |
| 橱窗分组命名 | 用买家搜索词 | 用内部型号命名 |
| Banner 尺寸 | 1920×460 px | 模糊/拉伸 |
| 产品图质量 | 白底 800×800+，≤500KB | 实拍杂乱 |
| About Us 页 | 有视频+工厂图+数据 | 一段话敷衍 |
| 移动端适配 | 文字可读、图不变形 | PC 版直接缩放 |
| 客户证言 | ≥ 3 条真实证言 | 空白 |
| FAQ | ≥ 5 个常见问题 | 没有 |
| 响应时间 | 账号在线 + 自动回复 | 经常离线 |
| 最近更新 | ≤ 30 天内有更新 | 半年没动 |

#### Amazon Brand Store

```
特殊要求：
├── 需完成 Brand Registry（品牌备案）
├── 页面结构：首页 + 子页面（按产品线分）
├── 可用模块：Hero Image / Product Grid / Video / Split / Gallery
├── 尺寸规范：
│   Hero: 3000×600 px（桌面）/ 1500×600（移动）
│   Product Image: 1500×1500 px
│   Logo: 400×400 px
├── 限制：不能放外部链接、不能放价格、不能放联系方式
├── A/B 测试：Amazon Manage Your Experiments 可测不同版本
└── 流量来源：Sponsored Brand Ads → Brand Store 是主要入口
```

#### Shopify 独立站

```
首页结构（自上而下）：
├── Announcement Bar（促销/免运/新品）
├── Hero Section（全屏大图 + 口号 + CTA）
├── Featured Collection（3-4 个品类）
├── 社会证明（媒体露出 / 客户证言 / 数字）
├── USP 三栏（图标 + 1 句话 × 3）
├── Blog Preview（2-3 篇最新文章）
├── Newsletter Subscribe（底部收集邮箱）
└── Footer（About/Contact/Policy/Social）

推荐主题：
- Dawn（免费，轻量快速）
- Flex（付费，高度自定义）
- Prestige（付费，适合品牌感）
```

---

### Phase 4：移动端适配清单

```
移动端 12 项检查：

1. Banner 文字在手机上是否可读（字号 ≥ 16px）
2. CTA 按钮是否足够大（≥ 44×44 px 可点击区域）
3. 产品图是否正方形（手机端非正方形会被裁切）
4. 导航是否可折叠（Hamburger menu）
5. 加载时间 ≤ 3 秒（图片压缩 + 延迟加载）
6. 表格是否可横滑（不要超出屏幕）
7. 视频是否自动播放静音（某些平台不支持）
8. 字体大小是否统一（不要忽大忽小）
9. 间距是否合理（不要元素堆在一起）
10. 底部 CTA 是否固定悬浮（sticky bottom bar）
11. WhatsApp/Chat 按钮是否常驻（移动端高频）
12. 多语言切换是否方便
```

---

## 3 档方案

| 项目 | 🟢 基础版 $0-500 | 🟡 专业版 $500-3000 | 🔴 品牌版 $3000+ |
|---|---|---|---|
| 平台 | 阿里旺铺 1 个 | 阿里+Amazon 2 个 | 阿里+Amazon+独立站 |
| Banner | Canva 自制 1 版 | 设计师出 3 版 | 专业摄影+设计 |
| 产品图 | 手机拍+PS 抠图 | 白底棚拍 | 场景图+白底+视频 |
| 视频 | 手机拍 30s | 剪辑 60s | 专业 TVC 90s |
| About Us | 文字版 | 图文版 | 视频+图文+数据 |
| 客户证言 | 文字截图 | 视频证言 2 条 | 视频+文字+案例集 |
| 多语言 | 英语 1 个 | 英+西/法 2 个 | 8 语版 |
| 维护频率 | 季度更新 | 月度更新 | 周度更新 |
| 适合阶段 | 新卖家 0-1 | 成长期 1-10 | 品牌化 10+ |

---

## Kill List（不要做的事）

1. **Kill 模板腔 About Us** — "We are a professional manufacturer with rich experience" 这种每家都一样的废话，买家跳过不看
2. **Kill 自嗨式 Banner** — 只有公司名 + LOGO，没有卖点和 CTA，等于白放
3. **Kill 过多分类** — 首页超过 10 个品类导航，买家选择困难直接走人
4. **Kill 巨大图片** — 单图 > 1MB，移动端加载 5 秒+，70% 买家直接关闭
5. **Kill 无证言空白** — 客户证言区域空白 or 只有自己写的假证言
6. **Kill 过时信息** — "2023 Canton Fair" 图片还挂着（现在都 2026 了）
7. **Kill PC 独占** — 只管 PC 端好看，移动端完全没适配（50%+ 流量来自移动端）

---

## 诚实提醒（必须告知客户的真话）

```
⚠️ 诚实提醒 — 请务必阅读

1. 装修≠流量：店铺装修再好看，没有流量进来也白搭。
   装修提升的是"转化率"而不是"访客量"。
   
2. 内容比设计重要：一个文案写得好的简陋页面，
   转化率可能比一个设计精美但文案空洞的页面高 3 倍。
   
3. 别花太多钱在装修上：新卖家用 Canva + 手机拍照就够了，
   等月均询盘 > 50 再考虑请专业设计。
   
4. 移动端才是主战场：阿里国际站 50%+ 流量来自手机/App，
   你在 PC 上调了半天的效果，手机上可能完全变形。
   
5. 定期更新比一次性装修重要：一个月更新一次比花 3 万
   做一次"完美"装修然后放半年不动要有用得多。
```

---

## Excel 报告详设（12 sheet）

| Sheet | 内容 | 关键列 |
|---|---|---|
| 1-现状诊断 | 10 项诊断清单 + 红绿灯 | 检查项/现状/达标/差距/优先级 |
| 2-竞品参考 | Top 5 竞品店铺截图+结构拆解 | 竞品/首屏结构/色调/信任元素/独特模块 |
| 3-Hero Banner | 3 版 Banner 文案 + 布局 | 版本/口号/副标/CTA/背景图建议 |
| 4-品类导航 | 导航结构 + 命名 | 分类/英文名/产品数/代表图/排序理由 |
| 5-主推爆款 | 6 个主推品 | 产品/卖点/价格区间/MOQ/认证/展示位置 |
| 6-About Us | 7 段结构化文案 | 段落/英文文案/中文底稿/配图建议 |
| 7-客户证言 | 证言采集计划 | 客户/国家/采集话术/状态/证言内容 |
| 8-FAQ | 8 个 FAQ | 问题/答案/排序 |
| 9-移动端适配 | 12 项检查 + 截图 | 检查项/当前/问题/修复方案 |
| 10-平台差异 | 3 平台模块对照 | 模块/阿里/Amazon/独立站/备注 |
| 11-行动计划 | 按优先级排列的待办 | 任务/负责人/截止/难度/预算 |
| 12-诚实提醒 | 不做清单 + 预算预警 | 类型/具体项/为什么不做/替代方案 |

---

## 上下游接口

| 方向 | Agent | 数据流 |
|---|---|---|
| ← 输入 | brand-positioning | 品牌色/口号/Story → Banner + About Us |
| ← 输入 | competitor-scanner | 竞品店铺结构 → 参考 |
| ← 输入 | buyer-icp-persona | 目标买家画像 → 导航分类逻辑 |
| → 输出 | listing-master | 店铺风格一致性 → 单品详情页 |
| → 输出 | detail-page-7screen | 店铺视觉规范 → 详情页 7 屏 |
| → 输出 | aigc-visual-creator | 视觉风格 → Banner/主图生成指令 |
| → 输出 | video-script-creator | 品牌调性 → 视频风格 |
| → 输出 | knowledge-base-builder | About Us + FAQ → 知识库 |

---

## 产出物清单

```
必交付：
├── 店铺结构蓝图（6 模块 × 内容 + 布局）
├── Hero Banner 文案 3 版（A/B/C 测试）
├── About Us 7 段结构化文案
├── 品类导航方案
├── 主推品展示方案
├── FAQ 8 问
├── 移动端适配检查报告
├── 12 sheet Excel
└── 3 档预算方案

可选追加：
├── Canva 模板链接（基础版用户）
├── 设计师 Brief（专业版用户用于外发设计）
└── 季度更新日历
```
