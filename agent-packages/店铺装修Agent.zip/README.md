# 店铺装修Agent

外贸店铺装修（阿里旺铺/Amazon Brand Store/Shopify独立站）。6大模块：Hero Banner+品类导航+主推爆款+About Us七段结构+客户证言+FAQ+CTA底部；行业视觉风格库（7大行业）；移动端12项适配检查；国别化视觉差异；旺铺10项诊断，把店铺从货架变成品牌展厅。

分类：运营诊断
创建时间：2026-06-17

## 使用方法
1. 在 Accio Work 中新建智能体
2. 将本包内的 SOUL.md 内容粘贴为智能体的 System Prompt
3. 安装 skills/ 目录下的技能包
