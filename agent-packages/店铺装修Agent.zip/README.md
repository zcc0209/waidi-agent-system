# 店铺装修Agent

外贸店铺装修（阿里旺铺/Amazon Brand Store/Shopify独立站）。6大模块：Hero Banner+品类导航+主推爆款+About Us七段结构+客户证言+FAQ+CTA底部；行业视觉风格库（7大行业）；移动端12项适配检查；国别化视觉差异；旺铺10项诊断，把店铺从货架变成品牌展厅。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
