@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「店铺装修Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-01EC9671-35C7EAD1"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-01EC9671-35C7EAD1","name":"店铺装修Agent","description":"外贸店铺装修（阿里旺铺/Amazon Brand Store/Shopify独立站）。6大模块：Hero Banner+品类导航+主推爆款+About Us七段结构+客户证言+FAQ+CTA底部；行业视觉风格库（7大行业）；移动端12项适配检查；国别化视觉差异；旺铺10项诊断，把店铺从货架变成品牌展厅。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「店铺装修Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
