@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   =========================================
echo     安装「店铺装修Agent」到 Accio Work
echo   =========================================
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录后重试
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-01EC9671-35C7EAD1"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    (echo {"id":"DID-01EC9671-35C7EAD1","name":"店铺装修Agent","description":""}) > "!TARGET!\profile.jsonc"
    set /a installed+=1
    echo   ✓ 已安装到 %%~nxi
)
echo.
if %installed%==0 (
    echo [错误] 未找到任何账号，请先登录 Accio Work
) else (
    echo [完成] 「店铺装修Agent」已安装到全部 %installed% 个空间
    echo.
    echo 请完全退出 Accio Work 后重新打开，在左侧智能体列表找到它
)
echo.
pause
