# 决策人识别Agent

找外贸客户公司真正的决策人。提供公司域名或公司名，自动定位Procurement Manager/CEO/Buyer等关键人，推测邮箱+标注置信度，并生成按职位定制的个性化开场白，帮你绕过前台直达拍板人。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
