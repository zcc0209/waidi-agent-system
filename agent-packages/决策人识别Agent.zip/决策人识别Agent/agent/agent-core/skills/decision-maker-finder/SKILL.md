---
name: decision-maker-finder
description: 找外贸客户公司决策人邮箱+开场白。当用户提供公司域名/网站/LinkedIn并要求"找采购/找CEO/找决策人/找邮箱/绕开前台/接触老板"时触发，输出决策人清单（含推测邮箱+置信度）+按身份定制的个性化开场白。
version: 1.0.0
---

# 决策人识别 Agent

## 触发场景
- 询盘业务员是助理/前台，需要绕到真决策人
- 主动开发客户找不到联系人
- 展会回来名片只有公司没有人
- 大单需要接触到最终拍板人

## 输入

最少：公司域名 或 公司名 + 国家。

## 工作流

### Step 1: LinkedIn 公司页定位
通过 browser MCP 访问 linkedin.com/company/{name}（前提：用户已登录 LinkedIn 的标签）：
- 获取员工数、HQ、行业、近期动态
- 进 People 页面看团队结构

### Step 2: 关键职位搜索
按业务模式确定决策人画像：
- **品牌商/批发商**：Procurement Manager / Sourcing Director / Buyer / Category Manager / Head of Purchasing
- **小公司（<20 人）**：CEO / Founder / Owner（创始人即决策人）
- **采购集团**：Sourcing Office Director / Country Manager / Vendor Manager
- **电商/Amazon 卖家**：Head of Supply Chain / Operations Director / Inventory Manager
- **零售连锁**：Buying Director / Category Buyer / Private Label Manager

### Step 3: 邮箱推测
基于域名 + 常见格式推测：
- {first}.{last}@domain.com（最常见，欧美）
- {first}@domain.com（小公司常见）
- {f}{last}@domain.com（北美企业常用）
- {first}_{last}@domain.com（少数日韩公司）
- 验证：用 mailtester.com / hunter.io 类公开服务（如可访问）

### Step 4: 个性化开场生成

不同身份不同开场逻辑：
- **对 CEO/Founder**：直接讲商业价值和增长机会，不讲产品参数。例："看到您们 Q3 在德国新开 3 家门店，[品类] 进口稳定性可能成为瓶颈，我们工厂在 [产能优势]..."
- **对 Procurement**：讲成本、稳定供货、付款灵活。例："注意到您负责 [品类] 采购，我们刚帮 [类似客户] 把单价降了 8% 同时把交期从 45 天压到 28 天..."
- **对 Category Manager**：讲品类趋势、SKU 扩充、新品上市。例："看到您线上 [品类] SKU 数量是 [X]，最近 TikTok 上 [新趋势] 类爆品我们已经量产，要不要看下样品？"
- **对 Buyer / Junior**：讲省事、专业、避免犯错。例："给您发一份 [品类] 选品避坑清单（PDF 7 页），上次帮 [客户] 避免了 [问题]..."

### Step 5: 输出决策人卡

```
═══ 决策人卡 ═══
决策人 1: [Name]
职位：[Title]
LinkedIn：[URL]
邮箱（推测）：[email]，置信度 [高/中/低]
任职年限：[X 年]
推测决策权：[最终决策/筛选推荐/执行]
近期动态：[LinkedIn 最近 post 摘要]

个性化开场白（首封 100 字内）：
"[姓名]，看到您领导 [公司] 的 [品类] 采购，注意到您们最近 [新品/新店/新国家]，..."

═══ 决策人 2: ... ═══
```

## 工具

- browser MCP（LinkedIn 必须登录态；先 tabs_context_mcp）
- WebSearch（"公司名 + 职位"搜行业新闻里的人物）
- WebFetch（官网团队页 / About Us / Leadership 页面）

## 注意事项

- **LinkedIn 反爬**：未登录拿不到 People 列表，需要 tabs_context_mcp + 已登录的 LinkedIn 标签；登录态丢失要先提示用户重新登录
- **邮箱置信度标注**：推测的邮箱必须标"推测+置信度"，发送前建议用工具验证；不验证就群发可能进黑名单
- **隐私合规**：不抓个人手机号、家庭住址、家庭照片；只用公开职业信息
- **小公司绕过前台**：CEO 邮箱常用 ceo@ / founder@ / 创始人名首字母@
- **避免冷感开场**："Dear Sir" = 拉黑信号；用 "Hi [First Name]" + 具体观察
- **去AI化**：开场白不要 "I hope this email finds you well"，直接切入观察到的具体事实
- **最多发 2-3 个决策人**：找 10 个反而稀释精力，业务员根本跟不过来

## 验证

- 决策人邮箱送达率 ≥80%（推测邮箱要先验证再发）
- 个性化开场首封回复率 ≥10%（行业冷邮件均值 2-5%）
- 抽检：每个决策人的开场白能让人 10 秒内说出"这是写给 [职位] 的"
