@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「决策人识别Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-DFD34AC2-5108F56A"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-DFD34AC2-5108F56A","name":"决策人识别Agent","description":"找外贸客户公司真正的决策人。提供公司域名或公司名，自动定位Procurement Manager/CEO/Buyer等关键人，推测邮箱+标注置信度，并生成按职位定制的个性化开场白，帮你绕过前台直达拍板人。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「决策人识别Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
