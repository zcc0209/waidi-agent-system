#!/bin/bash
AGENT_NAME="决策人识别Agent"
AGENT_ID="DID-DFD34AC2-5108F56A"
ACCIO_BASE="$HOME/.accio/accounts"
SCRIPT_DIR="$( cd "$( dirname "$0" )" && pwd )"
echo ""
echo "================================================"
echo " 安装「$AGENT_NAME」"
echo "================================================"
echo ""
if [ ! -d "$ACCIO_BASE" ]; then echo "❌ 请先登录 Accio Work"; exit 1; fi
accs=($(ls "$ACCIO_BASE"))
cnt=${#accs[@]}
if [ $cnt -eq 0 ]; then echo "❌ 无账号"; exit 1
elif [ $cnt -eq 1 ]; then CHOSEN="$ACCIO_BASE/${accs[0]}"; echo "账号：${accs[0]}"
else
  echo "检测到以下账号："
  for i in "${!accs[@]}"; do echo "  [$((i+1))] ${accs[$i]}"; done
  read -p "请输入编号（企业版选企业账号）：" ch; CHOSEN="$ACCIO_BASE/${accs[$((ch-1))]}" 
fi
TARGET="$CHOSEN/agents/$AGENT_ID"
mkdir -p "$TARGET"
cp -r "$SCRIPT_DIR/agent-core" "$TARGET/"
printf '{"id":"%s","name":"%s","description":""}' "$AGENT_ID" "$AGENT_NAME" > "$TARGET/profile.jsonc"
echo ""
echo "✅ 安装完成！请退出并重启 Accio Work，找到「$AGENT_NAME」"
