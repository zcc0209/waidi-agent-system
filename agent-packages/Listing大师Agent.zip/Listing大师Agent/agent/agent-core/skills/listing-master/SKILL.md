---
name: listing-master
description: 外贸单品 Listing 全套生成智能体（阿里 / Amazon / 独立站通用）。当用户要求"做 Listing/上产品/上架/写标题/写 bullet points/写五点描述/产品描述/Amazon Listing/阿里产品页/SEO 标题/主图脚本/Backend Keywords/A+ Content/EBC/产品上架"时触发，输出 3 平台标准 Listing（SEO 标题 + 6 主图脚本 + 5 Bullet Points + Description + Backend Keywords）+ 国别化关键词 + A+ Content 结构 + 详情页 7 屏联动 + 12 sheet Excel + 诚实提醒。
version: 2.0.0
---

# 外贸 Listing 大师智能体（深度版）

> 一句话定位：一个产品、一套完整上架物料——标题、主图、五点、描述、关键词、详情页，3 平台通吃、买家搜得到、点进来想买。

---

## 触发场景

- "帮我写一个蓝牙耳机的 Listing"
- "这个产品怎么上阿里国际站"
- "Amazon Listing 帮我优化一下标题"
- "帮我写 5 点描述"
- "我这个产品的主图应该拍什么"
- "Backend Keywords 怎么填"
- "帮我做个 A+ 页面"

---

## 输入要求

| 项目 | 必须 | 示例 |
|---|---|---|
| 产品名/型号 | ✅ | XD-500 LED Panel Light |
| 核心参数 | ✅ | 600×600mm, 40W, 4000K, Ra>90, IP44 |
| 目标平台 | ✅ | 阿里国际站 / Amazon US / 独立站 |
| 目标市场 | ✅ | 美国+欧洲 |
| 目标买家类型 | ✅ | B2B 批发商 / B2C 终端用户 |
| 竞品链接（可选） | - | 3 个同品竞品 Listing 链接 |
| 认证 | - | UL, CE, RoHS, DLC |
| 价格区间 | - | FOB $12-18 |
| MOQ | - | 100 pcs |
| 差异化卖点 | ✅ | 无频闪、5 年质保、48h 打样 |
| 现有图片 | - | 有白底图/场景图/工厂图 |

---

## 工作流

### Phase 1：竞品 Listing 拆解（5 分钟）

```
在目标平台搜索同品类 Top 10 竞品：

提取维度：
├── 标题结构（词序+字符数+关键词密度）
├── 主图数量和内容（白底/场景/尺寸图/安装图/包装图）
├── 五点描述长度和结构（功能 vs 场景 vs 参数）
├── 价格区间 + MOQ 分布
├── 评价数量 + 差评关键词
├── 认证展示方式
├── A+ / EBC 有无
└── 回复速度 / 商家活跃度
```

### Phase 2：SEO 标题生成

#### 阿里国际站标题（128 字符上限）

```
标题公式：
[核心关键词] + [修饰词1] + [修饰词2] + [场景/用途] + [认证/规格] + [差异化]

示例：
"Commercial LED Panel Light 600x600 40W Flicker Free Office Ceiling Light UL DLC Listed 5 Year Warranty OEM ODM"

规则：
├── 核心关键词放最前面（搜索权重最高）
├── 不重复用词（"LED Light LED Panel" = 浪费字符）
├── 不堆砌无关词（"hot sale/high quality/best price" = 低质信号）
├── 数字用阿拉伯数字（"5 Year" > "Five Year"）
├── 认证缩写大写（"UL" > "ul"）
└── 不用感叹号/特殊符号
```

#### Amazon 标题（200 字符上限，但前 80 字符最重要）

```
Amazon 标题公式：
[Brand] + [核心词] + [关键规格] + [用途/场景] + [差异化] + [数量/尺寸]

示例：
"LUMEX LED Panel Light 2x2 FT 40W 4000K, Flicker-Free Commercial Ceiling Light for Office Hospital, UL DLC Listed, 5-Year Warranty"

规则：
├── Brand 必须放第一位（品牌备案要求）
├── 前 80 字符必须包含最核心搜索词
├── 用逗号分隔不同信息段
├── 不全大写（ALL CAPS 违规）
├── 不放价格、促销、主观词（"Best/Amazing"）
└── 移动端只显示前 80 字符
```

#### 独立站标题（SEO Title ≤ 60 字符）

```
格式：[核心词] + [差异化] + [品牌] — 适合 Google 搜索
Meta Description ≤ 160 字符
URL Slug：用短横线分隔、全小写
```

**国别化关键词差异**：

| 市场 | 关键词偏好 | 示例 |
|---|---|---|
| 美国 | 直接、功能导向 | "LED panel light for office" |
| 英国 | 同美但用 UK 拼写 | "LED panel light colour temperature"（colour 不是 color）|
| 德国 | 参数严谨、认证敏感 | "LED Panel 62x62 cm TÜV GS geprüft" |
| 日本 | 型号+JIS 标准 | "LEDパネルライト 600×600 PSE" |
| 中东 | 价格敏感 | "LED panel light cheap factory price" |
| 拉美 | 西语为主 | "Panel LED 60x60 luz oficina" |

---

### Phase 3：6 主图脚本

```
主图 1（白底主图 — 必须，搜索结果展示用）：
├── 纯白底（#FFFFFF）
├── 产品占画面 85%
├── 主角度：3/4 俯视（最能展现产品形态）
├── 不加文字/水印/LOGO（Amazon 规则 + 阿里也建议）
└── 尺寸：1000×1000 px 以上（支持放大）

主图 2（场景图 — 使用场景）：
├── 产品在真实使用场景中
├── 示例：办公室天花板安装效果
├── 要有人/环境参照（体现尺寸感）
└── 暖色调灯光氛围

主图 3（卖点图 — 核心差异化）：
├── 图上标注 3-5 个核心卖点
├── 用箭头/图标指向产品局部
├── 示例：无频闪图示 + 显色指数对比
└── 文字简短（≤ 5 词/标注）

主图 4（参数图 — 规格尺寸）：
├── 标注产品尺寸（mm/inch 双标注）
├── 安装方式示意图
├── 接线图（如适用）
└── 可用白底+线稿风格

主图 5（对比图 — 我 vs 竞品 / 传统方案）：
├── 左右对比或 Before/After
├── 示例：传统荧光灯 vs 本产品（能耗/寿命/光效）
├── 用数据说话不用形容词
└── 颜色用绿（我方）vs 灰（对方）

主图 6（包装/认证/信任图）：
├── 产品包装全家福（开箱所有配件）
├── 认证 LOGO 排列（UL/CE/RoHS/DLC）
├── 可加 "5 Year Warranty" 标签
└── 增加买家下单信心
```

**主图拍摄 Checklist**：

| 类型 | 设备 | 布光 | 后期 |
|---|---|---|---|
| 白底图 | 单反/手机+三脚架 | 柔光箱 2 盏 | PS 抠图+白底 |
| 场景图 | 单反+广角 | 自然光/补光灯 | 色温校正 |
| 参数图 | 平铺拍摄 | 均匀散射光 | AI 标注/Canva |
| 对比图 | - | - | 后期合成 |

---

### Phase 4：5 Bullet Points（五点描述）

```
Bullet Points 写作公式：
[BENEFIT 标题（全大写）] — [具体说明+数据+场景]

模板：

1. 【安全/认证】CERTIFIED SAFE — UL & DLC listed, 
   meets US energy code requirements. Eligible for utility rebates up to $15/unit.

2. 【核心功能】FLICKER-FREE TECHNOLOGY — CRI>90 for true color rendering. 
   Reduces eye fatigue during 8h+ office use. Backed by photobiological safety test.

3. 【节能/经济】SAVE 60% ON ENERGY — 40W replaces 80W fluorescent. 
   50,000h lifespan = 11 years at 12h/day. ROI in 14 months.

4. 【易安装】3 MOUNTING OPTIONS — Recessed/Surface/Suspended. 
   Plug-and-play with standard J-box. Install in 10 min, no electrician needed.

5. 【服务/保障】5-YEAR WARRANTY + 48H SAMPLE — 
   Free replacement for any defect. ODM/OEM welcome, MOQ 100 pcs.
```

**写作铁律**：

```
✅ DO：
- 每点以大写标题开头（扫描性阅读友好）
- 数据 > 形容词（"50,000 hours" > "long lasting"）
- 场景化（"8h+ office use" > "wide application"）
- 每点 150-250 字符

❌ DON'T：
- 不堆砌关键词（会降权）
- 不用 "high quality / best / amazing"（空话）
- 不在 Bullet 里放价格/促销信息
- 不抄竞品（被投诉 = 下架）
```

**按买家类型调整**：

| 买家类型 | 侧重 | 示例 |
|---|---|---|
| B2B 批发商 | MOQ + 定制能力 + 认证 | "OEM/ODM, MOQ 100 pcs, UL certified" |
| B2C 终端用户 | 使用体验 + 安装便利 | "Install in 10 min, no tools needed" |
| 工程采购 | 参数 + 合规 + 批量价 | "Meets ASHRAE 90.1, project pricing available" |
| 经销商/分销 | 利润空间 + 区域保护 | "Exclusive pricing for distributors" |

---

### Phase 5：Product Description

#### 阿里国际站描述

```
结构（不要写成大段文字，用模块化）：

Section 1：产品概述（50 词）
Section 2：核心参数表格（Specs Table）
Section 3：产品特点 × 5（图+文）
Section 4：应用场景（3-5 张场景图）
Section 5：公司介绍（3 句话+工厂图）
Section 6：认证展示（LOGO 行）
Section 7：包装 & 物流信息
Section 8：FAQ × 5
Section 9：CTA（Contact Now / Send Inquiry）
```

#### Amazon A+ Content（EBC）

```
A+ 模块选择（Amazon 提供 17 种）：

推荐组合：
├── 模块 1：Standard Company Logo（品牌 LOGO）
├── 模块 2：Standard Image & Light Text Overlay（Hero 图+口号）
├── 模块 3：Standard Three Images & Text（3 个核心卖点）
├── 模块 4：Standard Comparison Chart（我 vs 竞品 or 我的 3 个型号）
├── 模块 5：Standard Technical Specifications（参数表格）
├── 模块 6：Standard Four Images & Text（场景图）
└── 模块 7：Standard Single Image & Specs Detail（尺寸/安装）

A+ 注意事项：
- 图片尺寸统一（970×300 or 970×600 px）
- 不放价格/促销/外部链接/联系方式
- 文字嵌入图片（Amazon 图片 ALT text 会影响 SEO）
- Premium A+ 需满足条件才能申请
```

---

### Phase 6：Backend Keywords / 关键词

```
关键词三梯队策略（与 keyword-matrix agent 联动）：

🔥 问鼎词（核心大词，3-5 个）：
├── 搜索量最高、竞争最激烈
├── 必须出现在标题前 80 字符
├── 示例："LED panel light" / "office ceiling light"
└── 用于 Sponsored Ads 主推

⭐ 明星词（中尾词，10-15 个）：
├── 搜索量中等、转化率高
├── 分布在标题 + Bullet Points + Description
├── 示例："recessed LED panel 2x2" / "flicker free panel light"
└── 用于 Exact Match 广告

🟢 长尾词（精准词，20-30 个）：
├── 搜索量低但转化率最高
├── 放在 Backend Keywords（不占标题字符）
├── 示例："40w LED panel light for hospital operating room"
└── 自然流量收割
```

**Backend Keywords 填写规则（Amazon）**：

```
250 字节上限（不是字符），规则：
├── 不重复标题已有的词（浪费）
├── 不用逗号/句号分隔（空格即可）
├── 不用品牌词（自己的和别人的都不行）
├── 不用 "best/amazing/cheap"（无效+违规）
├── 可用西语/法语关键词（拓展流量）
├── 包含常见拼写错误变体（如 "led pannel"）
└── 每 6 个月刷新一次（搜索趋势变化）
```

---

## 3 平台差异对照

| 维度 | 阿里国际站 | Amazon | 独立站 |
|---|---|---|---|
| 标题长度 | 128 字符 | 200 字符（前 80 关键） | 60 字符（SEO Title） |
| 图片数量 | 6-8 张 | 7 张（+A+ 无限） | 无限 |
| 图片尺寸 | 800×800+ | 1000×1000+ 白底 | 自定义 |
| Bullet Points | 无标准格式 | 5 点×500 字符 | 自定义 |
| 描述 | HTML 图文混排 | 纯文本 2000 字符 | 富文本 |
| 关键词 | 标题+属性填写 | 标题+Backend 250 字节 | Meta Tags+On-page |
| A+ Content | 无 | 有（品牌备案后） | 无限制 |
| 视频 | 首图可放视频 | 主图区+A+ | 自由嵌入 |

---

## 3 档方案

| 项目 | 🟢 快速上架 | 🟡 SEO 优化版 | 🔴 全套品牌版 |
|---|---|---|---|
| 时间 | 2 小时/SKU | 4 小时/SKU | 8 小时/SKU |
| 标题 | 1 版 | 3 版 A/B 测试 | 3 版+多语言 |
| 主图 | 3 张（白底+场景+参数） | 6 张完整 | 6 张+视频脚本 |
| Bullet Points | 5 点基础版 | 5 点+买家类型差异化 | 5 点×多市场 |
| Description | 纯文本 | 图文混排 | A+ Content 完整 |
| 关键词 | 核心 5 个 | 三梯队 50 个 | 三梯队+多语言 |
| 适合 | 新品快速测试 | 有一定数据想优化 | 品牌化运营 |
| 预算 | ¥0（自己做） | ¥500-1500/SKU | ¥3000+/SKU |

---

## Kill List

1. **Kill 关键词堆砌标题** — "LED Light LED Panel LED Lamp LED Fixture" 重复同义词 = 平台降权 + 买家觉得不专业
2. **Kill "High Quality" 开头** — 每个卖家都说 high quality，等于什么都没说；用认证/参数/对比数据替代
3. **Kill 抄竞品 Listing** — 被投诉抄袭 = 直接下架 + 可能关店；参考结构可以，文案必须原创
4. **Kill 白底图以外全是 PS 效果图** — 买家要看真实产品，过度美化 = 高退货率 + 差评
5. **Kill 忽略移动端** — Amazon 70% 流量来自手机，标题前 80 字符、前 2 张图决定点击率
6. **Kill 不填 Backend Keywords** — 白白浪费 250 字节免费流量入口
7. **Kill 半年不优化** — 关键词趋势季度变化，竞品不断优化，你不动就是退步

---

## 诚实提醒

```
⚠️ 诚实提醒 — 请务必阅读

1. Listing 好 ≠ 一定能卖：Listing 是转化率的基础，
   但没有流量（广告/SEO/社媒）进来，Listing 再好也是 0。
   
2. AI 生成的文案必须人工校对：AI 可能出现不符合产品的参数描述，
   错误参数 = 客诉 = 退货 = 差评。发布前务必对照产品 Spec Sheet。
   
3. 不要一次上 100 个 SKU：先用 10 个 SKU 测试，看数据反馈再扩。
   每个 Listing 做到 80 分 > 100 个 Listing 做到 30 分。
   
4. 主图拍摄比文案更重要：80% 的买家是被图片吸引点进来的，
   文案是"留住人"，图片是"拉进门"。
   
5. 每个市场的关键词不同：美国买家搜 "LED panel light"，
   英国买家搜 "LED flat panel"，德国买家搜 "LED Panelleuchte"。
   不做本地化关键词 = 丢掉 50% 搜索流量。
```

---

## Excel 报告详设（12 sheet）

| Sheet | 内容 | 关键列 |
|---|---|---|
| 1-竞品 Listing 拆解 | Top 10 竞品标题+图+五点 | 竞品/标题结构/图片数/差评关键词/亮点 |
| 2-关键词三梯队 | 50 个关键词分级 | 关键词/搜索量/竞争度/梯队/落地位置 |
| 3-SEO 标题 | 3 版标题 A/B/C | 版本/完整标题/字符数/核心词位置 |
| 4-主图脚本 | 6 张主图拍摄指令 | 图序/图片类型/拍摄角度/布光/道具/后期 |
| 5-五点描述 | B2B+B2C 两版 | 点序/大写标题/正文/字符数 |
| 6-产品描述 | 图文混排结构 | Section/内容/配图/备注 |
| 7-A+ Content | A+ 模块选择+内容 | 模块类型/图片尺寸/文案/ALT Text |
| 8-Backend Keywords | 250 字节关键词池 | 关键词/字节数/来源 |
| 9-国别化适配 | 多市场差异 | 市场/标题/关键词/Bullet/合规标签 |
| 10-上架 Checklist | 发布前 20 项检查 | 检查项/状态/备注 |
| 11-优化日历 | 月度优化计划 | 月份/优化项/优先级/预期效果 |
| 12-诚实提醒 | Kill List + 预算 | 类型/具体项/为什么/替代方案 |

---

## 上下游接口

| 方向 | Agent | 数据流 |
|---|---|---|
| ← 输入 | keyword-matrix | 三梯队关键词 → 标题+Backend |
| ← 输入 | brand-positioning | 品牌口号+USP → Bullet Points |
| ← 输入 | competitor-scanner | 竞品价格+卖点 → 差异化定位 |
| ← 输入 | store-decoration | 店铺视觉规范 → 图片风格一致 |
| ← 输入 | certification-compliance | 认证清单 → 标题+图片标注 |
| → 输出 | detail-page-7screen | Listing 核心卖点 → 详情页 7 屏 |
| → 输出 | multilingual-localizer | 英文 Listing → 多语言版本 |
| → 输出 | aigc-visual-creator | 主图脚本 → AIGC 生成 |
| → 输出 | video-script-creator | 产品卖点 → 视频脚本 |
| → 输出 | ads-investment | 关键词+Listing → 广告投放 |
