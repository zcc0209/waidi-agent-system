# Listing大师Agent

外贸单品Listing全套生成（阿里/Amazon/独立站通用）。3平台标准Listing：SEO标题+6主图脚本+5 Bullet Points+Description+Backend Keywords+国别化关键词+A+ Content结构+详情页7屏联动+12 sheet Excel，一个产品、一套完整上架物料，3平台通吃。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
