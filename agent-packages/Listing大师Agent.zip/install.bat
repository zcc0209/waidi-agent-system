@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「Listing大师Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-2D9DA406-20EA3D95"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-2D9DA406-20EA3D95","name":"Listing大师Agent","description":"外贸单品Listing全套生成（阿里/Amazon/独立站通用）。3平台标准Listing：SEO标题+6主图脚本+5 Bullet Points+Description+Backend Keywords+国别化关键词+A+ Content结构+详情页7屏联动+12 sheet Excel，一个产品、一套完整上架物料，3平台通吃。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「Listing大师Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
