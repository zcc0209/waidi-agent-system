@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「样品转单Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-DDF62985-238D1F13"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-DDF62985-238D1F13","name":"样品转单Agent","description":"外贸样品订单转化跟踪与催单。5阶段跟进（样品到达→开箱→试用→反馈→决策→下单）：跟进时间表+各阶段话术+紧急清单（超期未转化名单）+转化漏斗+流失原因诊断（价格/质量/竞品/内部预算）+样品ROI分析（寄样成本vs转化收益），把样品管理从'发了等回音'变成主动推进。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「样品转单Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
