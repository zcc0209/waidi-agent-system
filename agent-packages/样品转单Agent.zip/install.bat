@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「样品转单Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\sample-conversion-tracker"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"sample-conversion-tracker\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"样品转单Agent\",\r\n  \"description\": \"外贸样品订单转化跟踪与催单。5阶段跟进（样品到达→开箱→试用→反馈→决策→下单）：跟进时间表+各阶段话术+紧急清单（超期未转化名单）+转化漏斗+流失原因诊断（价格/质量/竞品/内部预算）+样品ROI分析（寄样成本vs转化收益），把样品管理从`'发了等回音`'变成主动推进。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「样品转单Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
