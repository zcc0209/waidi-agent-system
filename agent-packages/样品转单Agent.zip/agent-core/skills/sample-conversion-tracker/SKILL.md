---
name: sample-conversion-tracker
description: 外贸样品订单转化跟踪与催单。当用户要求"跟样品/样品转单/寄样后没回复/样品跟进/样品转化率/sample follow up"时触发，按"样品到达-开箱-试用-反馈-决策-下单"5阶段输出跟进时间表+紧急清单+各阶段话术+转化漏斗+流失原因诊断+样品 ROI 分析。
version: 1.0.0
---

# 样品转单 Agent

## 触发场景
- 业务员寄了 20 个样品，谁回了谁没回完全没追踪
- 寄样 1 个月后没回复要不要催
- 老板想知道样品转化率有多差
- 样品费花了几万但订单寥寥，要找问题
- 不同客户类型的样品转化节奏不一样，需要分级跟进

## 输入

必需：
- 样品订单清单（含：日期/客户/产品/数量/物流单号/物流方式）

可选：
- 客户类型（L1-L4，关联 inquiry-triage）
- 客户国家（影响时差和文化跟进节奏）
- 样品成本+物流成本（用于 ROI 计算）
- 历史转化数据（用于对比基准）

## 6 阶段标准跟进时间表

| 阶段 | 时间点 | 客户状态 | 业务员动作 | 话术目标 |
|---|---|---|---|---|
| 1. 在途 | 寄出 1-3 天 | 物流跟踪中 | 发物流单号+预计到达时间+开箱说明视频 | 让客户期待 |
| 2. 到达确认 | 物流签收当天 | 已签收未拆 | "Tracking shows delivered, please confirm receipt" | 触发开箱 |
| 3. 开箱反馈 | 到达后 2-3 天 | 已开箱待试用 | 问开箱印象+包装是否完好 | 收集第一印象 |
| 4. 试用反馈 | 到达后 7-10 天 | 试用中 | 问试用感受+技术问题答疑 | 解决疑虑 |
| 5. 决策跟进 | 到达后 15 天 | 决策中 | 给案例+老客户证言+限时优惠 | 推动决策 |
| 6. 催单/挽回 | 到达后 30 天 | 沉默/流失 | 直接问 "What's holding you back?" 或转挽回 | 转化或归档 |

### 国家时差调整

| 国家组 | 整体节奏 | 备注 |
|---|---|---|
| 欧美主流 | 标准节奏 | 周末别催，圣诞/感恩节避开 |
| 中东 | 节奏放慢 1.5x | 周五是周末，斋月低响应 |
| 印度 | 节奏放慢 2x | 决策慢但一旦决定就快 |
| 日本 | 节奏放慢 1.5x | 决策最慢但最稳，别催 |
| 拉美 | 节奏放慢 2x | 圣诞+狂欢节几乎停摆 |

### 客户类型调整

- L1 小卖：3 阶段足够（到达+试用+催单），不投精力做案例佐证
- L2 批发：6 阶段全走，重点在阶段 4-5
- L3 品牌：6 阶段全走 + 增加视频会议邀约（阶段 4）
- L4 集团：6 阶段全走 + 老板对接（阶段 5）+ 工厂参观邀请

## 客户反馈分类（每次跟进后打标）

10 种反馈状态：
1. **未签收** → 升级物流问题排查
2. **未拆封** → 触发开箱话术
3. **试用中无反馈** → 主动技术答疑
4. **反馈良好** → 推订单
5. **反馈技术问题** → 工程师介入 + 改良样品
6. **反馈价格问题** → 调 negotiation-coach
7. **反馈认证不符** → 评估是否补认证
8. **反馈对比竞品** → 拉价值维度，调 negotiation-coach
9. **反馈项目暂停** → 60 天后挽回
10. **明确拒绝** → 归 Kill List + 调研原因

## 工作流

### Step 1: 样品订单数据梳理
- 接收清单 → 按物流状态打标（在途/已达/超时未达）
- 计算每个样品的"已到达天数"

### Step 2: 阶段定位与紧急度判定
- 每个样品定位到 6 阶段中的具体阶段
- 标记紧急程度：🔴 严重逾期 / 🟡 临近节点 / 🟢 正常 / ⚪ 待启动

### Step 3: 跟进清单生成

```
═══ 今日样品跟进清单 ═══
🔴 紧急（5 件）：
- [客户A] 样品到达 35 天无任何反馈 → 用挽回话术 + 提议视频会议
- [客户B] 反馈技术问题 7 天未答复 → 工程师介入
...

🟡 临近节点（8 件）：
- [客户C] 到达 6 天未问试用 → 今天发阶段 4 话术
...

🟢 正常推进（12 件）：
...

⚪ 在途（4 件）：
- [客户D] 预计 2 天到达 → 发开箱视频
...
═══════════════
```

### Step 4: 各阶段话术（6 套模板）

**阶段 1: 在途话术**
```
Hi [Name],
Your sample is on the way! Tracking: [No.] (expected: [date]).
Attached is a 90-sec unboxing video showing how to test the [feature].
Any questions? Reply here or WhatsApp [No.].
```

**阶段 2: 到达确认**
```
Hi [Name],
Tracking shows your sample arrived today. Could you confirm it's reached
the right person? Let me know if anything's damaged in transit.
```

**阶段 3: 开箱反馈**
```
Hi [Name],
Hope the sample arrived in good shape. A few quick questions:
1. Packaging — any damage?
2. First impression on [key feature]?
3. Anything missing that should be in the box?
Your honest feedback helps us improve.
```

**阶段 4: 试用反馈**（最关键，决定转化）
```
Hi [Name],
It's been a week since the sample arrived. Curious:
- Did your team get a chance to test [key use case]?
- Any technical questions I can help with?
- How does it compare with what you're using now?
If easier, happy to set up a 20-min video call this week.
```

**阶段 5: 决策推动**
```
Hi [Name],
2 weeks in — wanted to share that [similar client] just placed a 5K-unit
follow-up order after their sample evaluation, citing [reason].

If you're getting close to a decision, I can extend the sample price into
the first order (saving you $X). Valid until [date].
```

**阶段 6: 催单/挽回**
```
Hi [Name],
It's been a month since you received the sample. I'd rather know honestly:
1. Is the project still active?
2. If not us, who did you go with? (Helps me improve)
3. Or — what's the one thing holding you back from moving forward?
No sales pitch, just want to learn.
```

### Step 5: 转化漏斗 + 流失原因分析

**漏斗看板**：
寄样 100 → 到达 95 → 开箱反馈 70 → 试用反馈 50 → 决策跟进 30 → 下单 10

每个环节的流失原因聚类（基于历史数据）：
- 到达→开箱流失（25%）：物流损坏 / 收件人不对 / 优先级低
- 开箱→试用流失（20%）：包装差感观不好 / 规格不符预期
- 试用→决策流失（20%）：技术问题未解决 / 比价 / 项目暂停
- 决策→下单流失（20%）：账期谈不拢 / MOQ 谈不拢 / 内部审批失败

### Step 6: 样品 ROI 分析

```
═══ 样品 ROI 看板（近 90 天）═══
寄样总数：100 件
样品+物流总成本：$5,000
转化订单数：10
转化订单总额：$50,000
转化率：10%（行业基准 15-25%）
样品 ROI：10x（每 $1 样品投入产生 $10 订单）

诊断：
- 转化率低于行业基准 → 重点查阶段 4 流失（试用环节）
- 物流损坏导致 5% 流失 → 升级包装
- 寄样客户中 30% 是 L1 小卖 → 收紧样品政策
═══════════════
```

## 注意事项

- **样品不是越多越好**：L1 小卖请样品费可退（首单抵），L4 集团免费但要 NDA
- **物流必须可追踪**：DHL/FedEx 不要用 EMS，欧美客户 DHL 更专业
- **开箱视频很重要**：寄样时附 60-90s 视频，转化率提升 30%+
- **阶段 4 是分水岭**：试用反馈拿不到，后面全白搭；要敢于视频会议+电话
- **去 AI 化**：话术不要 "Thank you for considering our products"，直接 "Quick check — did the sample arrive in good shape?"
- **节假日避坑**：欧美圣诞节前后 2 周、中东斋月、日本黄金周、印度排灯节别催
- **诚实问"为什么不买"**：被拒后调研价值远大于推销，80% 客户会告诉你真原因
- **L1 客户控制样品成本**：高频小卖请样 → 必须收样品费 + 运费到付

## 验证

- 跟进清单是否每件样品都有"明确的下一步动作和话术"
- 阶段定位是否准确（不会把"在途"误判为"试用中"）
- ROI 看板是否能让老板一眼看出"样品投入哪里浪费了"
- 阶段 6 挽回话术是否敢于"直接问为什么不买"（不是绕弯子）
- 漏斗分析是否定位到具体卡点（不是模糊地说"转化率低"）
