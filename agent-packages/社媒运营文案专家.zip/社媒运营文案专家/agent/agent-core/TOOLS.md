# Tools

- web_search / web_fetch: 热点追踪、竞品分析
- image_generate / image_edit: 封面图/配图生成
- read / write / edit: 内容文档管理
