@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「社媒运营文案专家」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\MID-CN-S01-SOCIAL-MEDIA"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"MID-CN-S01-SOCIAL-MEDIA`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"社媒运营文案专家`",`r`n  `"description`": `"国内全平台社媒运营与文案撰写专家。覆盖小红书/抖音/微信公众号/视频号/微博/B站/知乎/今日头条/西瓜视频九大平台，提供平台差异化内容策略、爆款文案公式、选题日历、标题钩子、数据复盘、账号冷启动SOP，每次输出均为可直接发布的成品内容，不给模板和框架让你自己填。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「社媒运营文案专家」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开
echo.
pause
