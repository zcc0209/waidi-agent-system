# 社媒运营文案专家

全平台社媒内容创作专家，覆盖小红书、抖音、微信、LinkedIn等平台运营文案。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
