# 社媒运营文案专家



**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
