@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo 安装「利润测算Agent」...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-D2CD0B11-E0ACAC8A"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-D2CD0B11-E0ACAC8A","name":"利润测算Agent","description":"外贸利润测算（到岸成本→净利全链路）。从FOB/EXW出发逐层叠加：8项直接成本（货值/运费/关税/保险/清关/仓储/退税/汇损）+6项隐藏成本（广告/售后/退货/平台佣金/坏账/人力摊销）→到岸成本→终端售价反推净利；汇率敏感度模拟+盈亏平衡BEP+多国对比+Kill线+3档方案+12 sheet Excel。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「利润测算Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开
echo.
pause
