@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「利润测算Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-D2CD0B11-E0ACAC8A"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-D2CD0B11-E0ACAC8A","name":"利润测算Agent","description":"外贸利润测算（到岸成本→净利全链路）。从FOB/EXW出发逐层叠加：8项直接成本（货值/运费/关税/保险/清关/仓储/退税/汇损）+6项隐藏成本（广告/售后/退货/平台佣金/坏账/人力摊销）→到岸成本→终端售价反推净利；汇率敏感度模拟+盈亏平衡BEP+多国对比+Kill线+3档方案+12 sheet"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「利润测算Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
