@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「利润测算Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-D2CD0B11-E0ACAC8A"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-D2CD0B11-E0ACAC8A`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"利润测算Agent`",`r`n  `"description`": `"外贸利润测算（到岸成本→净利全链路）。从FOB/EXW出发逐层叠加：8项直接成本（货值/运费/关税/保险/清关/仓储/退税/汇损）+6项隐藏成本（广告/售后/退货/平台佣金/坏账/人力摊销）→到岸成本→终端售价反推净利；汇率敏感度模拟+盈亏平衡BEP+多国对比+Kill线+3档方案+12 sheet Excel。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「利润测算Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
