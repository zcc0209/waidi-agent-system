@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「合规雷达Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-B5C3B8E7-963F8927"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-B5C3B8E7-963F8927","name":"合规雷达Agent","description":"外贸全维合规红线监控（⚠️高危）。8大合规维度：GDPR数据隐私、SDN制裁名单三色筛查、反倾销/337调查应对、UFLPA强迫劳动审查、FCPA反贿赂——每客户开单必查，罚款量化到OFAC$100万/GDPR€2000万。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「合规雷达Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
