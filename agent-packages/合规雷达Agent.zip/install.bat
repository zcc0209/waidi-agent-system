@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「合规雷达Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-B5C3B8E7-963F8927"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-B5C3B8E7-963F8927","name":"合规雷达Agent","description":"外贸全维合规红线监控（⚠️高危）。8大合规维度：GDPR数据隐私、SDN制裁名单三色筛查、反倾销/337调查应对、UFLPA强迫劳动审查、FCPA反贿赂——每客户开单必查，罚款量化到OFAC$100万/GDPR€2000万。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「合规雷达Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
