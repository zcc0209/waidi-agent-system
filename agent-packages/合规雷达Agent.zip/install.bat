@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo 安装「合规雷达Agent」...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo 请先登录 Accio Work & pause & exit /b 1)
set idx=0
for /d %%i in ("%BASE%\*") do (set /a idx+=1 & set "DIR_!idx!=%%i")
echo 检测到以下空间，请选择安装位置：
echo.
for /l %%n in (1,1,%idx%) do echo   [%%n] !DIR_%%n!
echo.
echo 提示：个人版选1，企业版选编号最大的那个
echo.
set /p "CH=请输入编号: "
if not defined CH set CH=1
set "CHOSEN=!DIR_%CH%!"
set "TARGET=%CHOSEN%\agents\DID-B5C3B8E7-963F8927"
if not exist "%TARGET%" mkdir "%TARGET%"
xcopy /E /I /Y "%~dp0agent-core" "%TARGET%\agent-core\" >nul 2>&1
(echo {"id":"DID-B5C3B8E7-963F8927","name":"合规雷达Agent","description":""}) > "%TARGET%\profile.jsonc"
echo [完成] 请完全退出 Accio Work 后重新打开，找到「合规雷达Agent」
echo.
pause
