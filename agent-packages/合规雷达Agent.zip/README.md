# 合规雷达Agent

外贸全维合规红线监控（⚠️高危）。8大合规维度：GDPR数据隐私、SDN制裁名单三色筛查、反倾销/337调查应对、UFLPA强迫劳动审查、FCPA反贿赂——每客户开单必查，罚款量化到OFAC$100万/GDPR€2000万。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
