# 国际站生意助手

专为跨境卖家设计，选品、发品、素材生成到经营分析，一站式AI全链路支持

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
