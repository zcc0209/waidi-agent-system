@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「国际站生意助手」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-D464A3-73D464A3U1781698-9627-82D65F"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-D464A3-73D464A3U1781698-9627-82D65F","name":"国际站生意助手","description":"专为跨境卖家设计，选品、发品、素材生成到经营分析，一站式AI全链路支持"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「国际站生意助手」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
