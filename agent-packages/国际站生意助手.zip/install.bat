@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「国际站生意助手」...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先打开并登录 Accio Work & pause & exit /b 1)
set idx=0
set "LAST="
for /d %%i in ("%BASE%\*") do (
    set /a idx+=1
    set "DIR_!idx!=%%i"
    set "LAST=%%i"
)
if %idx%==0 (echo [错误] 未找到账号，请先登录 & pause & exit /b 1)
echo 检测到以下 Accio Work 空间：
echo.
for /d %%i in ("%BASE%\*") do echo   %%~nxi
echo.
if %idx%==1 (
    set "CHOSEN=%DIR_1%"
) else (
    echo 您有个人空间和企业空间。
    echo 请选择要安装到哪个空间：
    for /l %%n in (1,1,%idx%) do echo   [%%n] !DIR_%%n!
    echo.
    echo 提示：企业版用户请选编号较大的那个
    echo.
    set /p "CH=请输入编号: "
    set "CHOSEN=!DIR_%CH%!"
)
set "TARGET=%CHOSEN%\agents\DID-D464A3-73D464A3U1781698-9627-82D65F"
echo.
echo 正在安装到：%CHOSEN%
if not exist "%TARGET%" mkdir "%TARGET%"
xcopy /E /I /Y "%~dp0agent-core" "%TARGET%\agent-core\" >nul 2>&1
(echo {) > "%TARGET%\profile.jsonc"
(echo   "id": "DID-D464A3-73D464A3U1781698-9627-82D65F",) >> "%TARGET%\profile.jsonc"
(echo   "name": "国际站生意助手",) >> "%TARGET%\profile.jsonc"
(echo   "description": "") >> "%TARGET%\profile.jsonc"
(echo }) >> "%TARGET%\profile.jsonc"
echo.
echo [完成] 「国际站生意助手」安装成功！
echo.
echo 下一步：完全退出 Accio Work → 重新打开 → 左侧找到智能体
echo.
pause
