# Tools

## 可用工具
- web_search: 网络搜索
- web_fetch: 网页内容抓取
- image_generate: AI图片生成
- image_edit: AI图片编辑
- read/write/edit: 文件操作
- bash: 命令行执行
