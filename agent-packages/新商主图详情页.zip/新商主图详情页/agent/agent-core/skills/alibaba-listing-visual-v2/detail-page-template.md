# 详情页文案模板 — 阿里国际站 B端导向

格式规则：
- 英文文案为正式发布内容
- `（中文说明：...）` 为仅供用户参考的理解辅助，不发布到平台
- 每个模块包含：图片设计指导 + 图片下方纯文字描述（供AI MODE / 多语言翻译使用）

> **配置驱动**：本模板中的 `[公司名]` `[年份]` `[工厂面积]` `[认证]` `[MOQ]` `[交期]` `[市场]` 等占位符，
> 统一从 `config.md` 读取替换。已配置内容不要重复询问用户；config.md 中为空的字段才临时询问。

---

## 模块1 — 公司实力 Banner（详情页首图）

### 图片设计指导
- 尺寸：1200×500px（横幅）
- 左侧：工厂/公司实景图（40%宽度）
- 右侧：公司核心数据卡片（60%宽度）
- 配色：深蓝色系 或 深灰色系，白色文字，专业感强

### 文案框架

**主标题（H1）：**
```
[公司名] — Your Trusted [行业关键词] Manufacturer
```
（中文说明：公司定位标题，强调"可信赖的制造商"身份，建立第一印象）

**数据卡片（6个）：**
```
✦ [XX] Years in Business       — 品牌历史
✦ [XX,000] ㎡ Factory Area     — 工厂规模
✦ [XX] Countries Exported      — 出口覆盖
✦ [XX,000] Units/Month Output  — 月产能
✦ [XX]+ Employees              — 团队规模
✦ [XX]+ Certifications         — 认证数量
```
（中文说明：用具体数字展示公司规模，B端买家非常重视供应商的稳定性和规模，数字越具体越有说服力）

**图片下方纯文字描述（SEO + AI MODE）：**
```
[公司名] is a professional [产品类别] manufacturer established in [年份], located in [城市], [省份], China.
With over [XX] years of manufacturing experience, we operate a [XX,000] square meter modern production facility
equipped with [设备描述]. We export to [XX]+ countries worldwide and maintain [认证列表] certifications.
Our monthly production capacity reaches [XX,000] units, supported by a team of [XX]+ skilled professionals.
We specialize in OEM/ODM services for global brands and wholesale buyers.
```
（中文说明：这段文字放在图片下方，不显示在图片里。用于平台AI检索、多语言翻译和SEO优化，描述要准确详实）

---

## 模块2 — 产品参数表

### 图片设计指导
- 尺寸：1200×适当高度
- 左侧：产品三视图或主要角度图
- 右侧：规格表格（交替行背景色）
- 表头加粗，品牌色背景

### 文案框架

**模块标题：**
```
Product Specifications
```
（中文说明：参数模块标题，简洁直接，采购商最关注参数）

**规格表格：**
```
| Specification        | Details                        |
|---------------------|--------------------------------|
| Product Name        | [产品名称]                      |
| Model Number        | [型号]                          |
| Material            | [材质]                          |
| Dimensions          | [长 × 宽 × 高] mm/cm/inch      |
| Weight              | [净重] g/kg                     |
| Color Options       | [颜色列表]                      |
| Power/Voltage       | [功率/电压]（如适用）            |
| Certification       | [CE / RoHS / FDA / ISO...]     |
| MOQ                 | [最小起订量] pcs/sets           |
| Lead Time           | [X] days for sample / [X] days for bulk order |
| Packaging           | [包装方式], [X] pcs/CTN        |
| Carton Size         | [外箱尺寸] cm                   |
| Gross Weight        | [毛重] kg/CTN                   |
| HS Code             | [海关编码]（如已知）             |
```
（中文说明：参数表务必完整填写，尤其是MOQ、交期和认证，这三项是B端买家询盘前最关注的信息）

**自定义选项（如有）：**
```
Customization Available:
✓ Custom Logo / Branding
✓ Custom Color / Finish
✓ Custom Packaging
✓ Custom Size / Specification
✓ OEM / ODM Welcome

Contact us with your requirements for a tailored quote.
```
（中文说明：定制化服务是国际站B端买家的核心需求之一，明确列出可定制项目能显著提升询盘率）

**图片下方纯文字描述：**
```
[产品名称] Specifications: Material: [材质]. Dimensions: [尺寸]. Weight: [重量].
Available colors: [颜色]. Certifications: [认证]. MOQ: [起订量] pieces.
Lead time: [样品交期] days for samples, [大货交期] days for bulk orders.
Customization available including custom logo, color, packaging, and OEM/ODM services.
```

---

## 模块3 — 细节展示

### 图片设计指导
- 尺寸：1200×900px（2×2网格）或 1200×500px（横排3图）
- 每格：产品局部特写 + 标注文字
- 背景：白色或极浅灰

### 文案框架

**模块标题：**
```
Product Details — Quality You Can See
```
（中文说明：细节展示模块，标题强调"看得见的品质"，对应B端买家对品控的关注）

**细节卡片（每个细节一组）：**
```
Detail 1: [细节名称]
[1-2句描述该细节的工艺或优势]
Example: Premium Stitching — Double-reinforced seams using high-tenacity thread,
ensuring [X]% stronger durability than standard construction.

Detail 2: [细节名称]
[描述]

Detail 3: [细节名称]
[描述]

Detail 4: [细节名称]
[描述]
```
（中文说明：每个细节要说明"是什么" + "为什么好"，不要只写名称，要帮买家理解价值）

**图片下方纯文字描述：**
```
[产品名称] features [细节1]: [说明]. [细节2]: [说明]. [细节3]: [说明].
Every unit undergoes strict quality inspection before shipment to ensure consistent quality standards.
Our manufacturing process follows [ISO/相关标准] quality management system.
```

---

## 模块4 — 核心卖点

### 图片设计指导
- 尺寸：1200×400px（横排卡片）
- 3-4个卡片，每卡：图标 + 标题 + 说明
- 配色：白色卡片 + 顶部品牌色条

### 文案框架

**模块标题：**
```
Why Buyers Choose [公司名/产品名]
```
（中文说明：卖点模块标题用"为什么买家选择我们"，从买家视角出发更有代入感）

**卖点卡片（选4个最强卖点）：**

模板A — 品质类：
```
🏆 Superior Quality Control
100% inspection before shipment. Each unit tested against [X] quality checkpoints.
Zero-defect commitment backed by our [X]-year warranty.
```
（中文说明：品质卖点要有具体数字支撑，"100%检验"、"X年保修"比泛泛的"高品质"更有说服力）

模板B — 价格/效率类：
```
💰 Factory-Direct Competitive Pricing
Eliminate middlemen. Get manufacturer prices directly from our [X,000]㎡ production base.
Flexible MOQ starting from [X] pieces with volume discount tiers.
```
（中文说明：价格卖点要说明为什么价格有竞争力，"工厂直供"比"价格低"更有说服力）

模板C — 交期类：
```
⚡ Fast Delivery
Sample ready in [X] days. Bulk order [X]-[X] days lead time.
[X]+ shipping routes available. DHL/FedEx/Sea Freight options.
```
（中文说明：交期是B端买家高频关注点，给出具体天数，并说明有哪些物流选项）

模板D — 定制类：
```
🔧 Full OEM/ODM Capability
Your logo, your design, your brand. Minimum [X] pieces for logo customization.
In-house design team provides free artwork support within [X] business days.
```
（中文说明：OEM/ODM能力对中小品牌买家非常重要，要说清楚起订量和支持范围）

模板E — 认证类：
```
✅ International Certifications
[认证1] / [认证2] / [认证3] certified product ready for import to EU, US, AU markets.
Full compliance documentation provided with every order.
```
（中文说明：认证能消除买家进口合规顾虑，直接点明适用市场）

**图片下方纯文字描述：**
```
Key advantages of [产品名称] from [公司名]:
1. [卖点1简述]
2. [卖点2简述]
3. [卖点3简述]
4. [卖点4简述]
We offer OEM/ODM customization, factory-direct pricing, and international shipping to all major markets.
```

---

## 模块5 — 公司详细实力

### 图片设计指导
- 尺寸：1200×1500px（多段式长图）或拆分为多张
- 包含：工厂图片网格 + 设备介绍 + 出口地图 + 品控流程
- 风格：企业宣传册风格

### 文案框架

**Section A — 工厂能力**

**标题：**
```
Our Manufacturing Capabilities
```

**内容：**
```
Established in [年份], [公司名] has grown into a [行业类别] manufacturing leader
with a [X,000] m² state-of-the-art production facility in [城市], China.

Production Lines: [X] automated production lines capable of [X,000] units/month
Key Equipment: [设备1], [设备2], [设备3]
R&D Team: [X]+ engineers dedicated to product innovation and customization
Quality Lab: In-house testing laboratory equipped with [测试设备]
```
（中文说明：工厂能力介绍要具体，买家看重生产线数量、关键设备和研发能力，这些决定了供应商是否可靠）

**Section B — 品控流程**

**标题：**
```
Our Quality Control Process
```

**4步流程：**
```
Step 1: Incoming Material Inspection
All raw materials tested against [标准] standards before production.

Step 2: In-Process Quality Check
[X]% sampling inspection at key production stages by dedicated QC team.

Step 3: Final Product Inspection
100% functional testing + appearance inspection before packaging.

Step 4: Pre-Shipment Inspection
Final batch inspection available. Third-party QC inspection (SGS/Bureau Veritas) welcomed.
```
（中文说明：四步品控流程展示系统性的质量管理，消除买家对品质一致性的顾虑）

**Section C — 出口经验**

**标题：**
```
Trusted by Global Buyers in [X]+ Countries
```

**内容：**
```
We have successfully exported to: [主要出口国家列表]
Key markets: North America | Europe | Australia | Southeast Asia | Middle East

Our export experience includes:
✓ Compliance with local market regulations and certifications
✓ Multilingual customer service (English, [其他语言])
✓ Flexible payment terms: T/T, L/C, Western Union, PayPal (for samples)
✓ Multiple shipping options: Air, Sea, Express (DHL/FedEx/UPS)
```
（中文说明：列出主要出口国家和配套服务，给买家信心"你们有服务我们这类市场的经验"）

**图片下方纯文字描述：**
```
[公司名] manufacturing overview: [X,000] m² factory, [X] production lines, [X,000] units monthly capacity.
Quality management: ISO [XXXX] certified. 4-stage quality control process including incoming material inspection,
in-process checks, final inspection, and pre-shipment inspection.
Export experience: [X]+ years exporting to [X]+ countries. Major markets include [国家列表].
Services: OEM/ODM, custom packaging, multi-language support, flexible shipping options.
```

---

## 模块6 — FAQ

### 图片设计指导
- 尺寸：1200×800px 或更高（取决于问题数量）
- 简洁列表风格，Q用品牌色，A用深灰色
- 底部加CTA按钮图形

### 文案框架

**模块标题：**
```
Frequently Asked Questions
```
（中文说明：FAQ模块主动解答买家常见顾虑，减少询盘前的摩擦，提升询盘质量）

**标准问题集（根据产品类型选取或调整）：**

```
Q1: What is your Minimum Order Quantity (MOQ)?
A: Our standard MOQ is [X] pieces. For first-time orders or samples, we offer [X] piece minimum.
   Contact us to discuss your specific volume requirements.
（中文说明：MOQ是最高频的询盘前问题，要清楚说明，并给灵活性）

Q2: Can I get a sample before placing a bulk order?
A: Yes. Samples are available within [X] business days.
   Sample cost: [免费/USD XX], shipping at buyer's expense (we accept your DHL/FedEx account).
   Sample cost is refundable against your first bulk order.
（中文说明：样品政策要详细，说明费用和退款政策，降低买家试单门槛）

Q3: What customization options do you offer?
A: We support: Custom logo (printing/embroidery/engraving), custom color, custom size,
   custom packaging design, and full OEM/ODM development.
   Minimum quantity for customization: [X] pieces. Lead time: [X-X] business days.
（中文说明：列出所有定制选项，并说明起订量，让买家立刻判断是否符合需求）

Q4: What are your payment terms?
A: We accept: T/T (Bank Transfer), L/C (Letter of Credit), Western Union.
   For samples: PayPal accepted.
   Typical terms: 30% deposit, 70% balance before shipment (negotiable for long-term partners).
（中文说明：支付条款要透明，提到可协商，给大客户留空间）

Q5: How long is the production lead time?
A: Sample: [X] business days.
   Bulk order (standard products): [X]-[X] business days after order confirmation.
   Rush orders available for an additional fee — contact us for availability.
（中文说明：给出具体天数，并说明加急选项，满足买家不同交期需求）

Q6: What shipping methods do you offer?
A: Express: DHL / FedEx / UPS (3-7 days, suitable for samples and small orders)
   Air Freight: 5-10 days (suitable for medium volume)
   Sea Freight: 20-40 days depending on destination (best for large volume)
   We can ship to your nearest port or use your freight forwarder.
（中文说明：物流选项要全面，B端买家通常有自己的货代，说明可以使用买家货代很重要）

Q7: What certifications does your product hold?
A: [产品名称] holds the following international certifications: [认证列表].
   All documentation is provided with shipment. Additional testing/inspection can be arranged upon request.
（中文说明：认证列表要完整，进口商需要这些文件清关，提前说明省去后续沟通成本）

Q8: What is your after-sales policy?
A: We offer a [X]-month quality guarantee on all products.
   In case of quality issues caused by manufacturing defects, we provide:
   Free replacement / Store credit / Partial refund (based on specific situation).
   Please report any issues within [X] days of receipt with photos/videos.
（中文说明：售后政策消除买家最后的顾虑，说明具体如何处理问题，比泛泛的"我们负责"更有说服力）
```

**底部CTA文字：**
```
Still have questions? We're here to help!
📩 Send us an inquiry — our team responds within 24 hours.
We speak English | [其他语言] | We work with buyers across all time zones.
```
（中文说明：FAQ底部CTA引导买家发询盘，强调响应速度和多语言服务，降低沟通顾虑）

**图片下方纯文字描述：**
```
Frequently Asked Questions about [产品名称]:
MOQ: [X] pieces minimum. Samples available in [X] days.
Customization: Custom logo, color, packaging, OEM/ODM available from [X] pieces.
Payment: T/T, L/C, Western Union accepted.
Lead time: [X]-[X] days for bulk orders.
Shipping: Express (DHL/FedEx), Air freight, Sea freight available.
Certifications: [认证列表].
After-sales: [X]-month quality guarantee. Contact us within [X] days for any quality issues.
For inquiries, please contact us — response within 24 hours.
```

---

## 使用提示

### 文案语气原则
- **专业但不冷漠**：B端沟通要商务专业，但不要过于生硬
- **具体数字优先**：用 "12 years" 而非 "many years"，用 "100% inspection" 而非 "strict inspection"
- **买家利益导向**：每个卖点落脚在"对买家有什么好处"
- **避免夸大**：不用 "world's best"、"unbeatable" 等无法核实的说法

### 中英文说明格式规范
所有中文说明以`（中文说明：...）`格式标注，在展示给用户时：
- 在聊天界面用灰色字体或斜体显示
- 明确标注"仅供理解，不发布"
- 用户确认英文内容后，中文说明不需要上传到平台
