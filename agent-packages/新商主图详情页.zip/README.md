# 新商主图详情页

外贸新商主图与详情页制作指南，帮助新手快速上手产品图片优化与商品详情页设计。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
