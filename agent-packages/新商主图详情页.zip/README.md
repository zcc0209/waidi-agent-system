# 新商主图详情页



**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh

安装后完全退出 Accio Work 重新打开即可看到智能体。
