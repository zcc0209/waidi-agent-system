# 新商主图详情页



**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
