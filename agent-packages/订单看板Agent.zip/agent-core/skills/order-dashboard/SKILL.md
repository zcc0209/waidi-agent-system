---
name: order-dashboard
description: 外贸订单全生命周期看板。当用户要求"订单看板/订单进度/订单状态可视化/查所有订单/订单管理/订单到哪一步了/履约进度"时触发，将所有在制订单按7阶段（订金到账→备料→生产→质检→报关→出运→签收）可视化，含红绿灯预警+延期清单+客户告知话术+里程碑日历，输出多 sheet Excel 看板。
version: 1.0.0
---

# 订单看板 Agent

## 触发场景
- 老板每天早上想知道所有在制订单状态
- 业务员经常被客户追问"我的订单到哪了"
- 月底/季度末要给客户群发履约进度更新
- 跨多个工厂/多业务员的订单容易丢节点
- 节假日前需要知道哪些订单要赶工

## 输入

必需任一：
- 订单 Excel/CSV（含 PI No / 客户 / 产品 / 数量 / 金额 / 订金日期 / 交期）
- ERP 导出
- 阿里国际站后台订单数据（可用 browser MCP 抓）

可选：
- 各订单当前阶段（如已知）
- 工厂排期数据（关联 production-scheduler）
- 物流跟踪号（关联 logistics-planner）

## 7 阶段订单生命周期

| 阶段 | 状态名 | 标准时长 | 关键产出 | 风险信号 |
|---|---|---|---|---|
| 1 | 订金到账 | 1-7 天 | 银行水单 / SWIFT 回执 | 7 天未到账 → 订单异常 |
| 2 | 备料 | 5-15 天 | 物料采购单 / 入库单 | 关键料断货 / 涨价>10% |
| 3 | 生产 | 15-45 天 | 生产进度日报 | 良率<95% / 设备故障 |
| 4 | 质检 | 2-5 天 | AQL 验货报告 | 退线>5% / 客户不通过 |
| 5 | 报关备货 | 3-7 天 | 商业发票 / 装箱单 / 原产地证 | 单证不齐 / HS Code 错 |
| 6 | 出运 | 25-45 天（海运） | 提单 BL / 跟踪号 | 延船 / 港口拥堵 / 罢工 |
| 7 | 签收回款 | 5-15 天 | 客户签收回执 / 尾款到账 | OA 逾期 / 客户拒收 |

## 工作流

### Step 1: 订单数据梳理与阶段定位
- 接收订单清单
- 每单按"已发生事件"定位到 7 阶段中具体阶段
- 计算每单"已用天数 / 剩余天数 / 是否延期"

### Step 2: 红绿灯打标

按"剩余可用天数 vs 标准时长"分级：
- 🟢 正常推进（>50% 时间余量）
- 🟡 注意（20-50% 余量，开始预警）
- 🟠 紧张（<20% 余量，需加速）
- 🔴 已延期（已超过承诺交期）
- ⚫ 异常（订金未到 / 物料断 / 客户不通过等）

### Step 3: 输出 Excel 多 Sheet 看板

**Sheet 1: 总览快照**
- 在制订单总数 + 总金额
- 7 阶段订单数分布柱状图
- 红绿灯统计（绿/黄/橙/红/黑各几单）
- 本周必交订单数 + 总金额
- 本月延期订单数 + 损失预估
- 一句话健康度诊断（正常/承压/告急）

**Sheet 2: 订单全景表**
| PI No | 客户 | 产品 | 数量 | 金额 | 订金日期 | 承诺交期 | 当前阶段 | 已用天数 | 剩余天数 | 红绿灯 | 业务员 | 工厂 | 备注 |

行内填充色按红绿灯：🟢 D5F0D5 / 🟡 FFF2CC / 🟠 FFE0B2 / 🔴 FCE4E4 / ⚫ E0E0E0

**Sheet 3: 延期/告急清单（最关键）**
按延期天数排序，每条带：
- 延期原因（备料/生产/质检/报关/物流）
- 责任方（工厂/采购/质检/物流公司）
- 紧急动作（今天/本周必做）
- 客户告知话术（道歉+新预计交期+补偿方案）

**Sheet 4: 7 阶段漏斗**
按阶段统计在制订单数和金额，找出"卡点阶段"：
- 哪个阶段堆积最多订单 → 系统级问题
- 哪个阶段平均停留时间最长 → 流程瓶颈

**Sheet 5: 本周里程碑日历**
未来 7 天每天的关键节点：
- 哪天哪个订单要交付
- 哪天要订舱
- 哪天要交单证给货代
- 哪天要客户签收确认

**Sheet 6: 客户主动告知模板**
按订单状态生成 4 种客户告知话术：
- 正常进度：周报式更新（每周三定时发）
- 即将延期：提前 5 天预警，给替代方案
- 已经延期：道歉+新交期+补偿
- 提前完成：好消息+提早出运

**Sheet 7: 财务影响**
- 订金已收金额 / 待收尾款金额
- 延期罚款风险预估（按合同条款）
- 资金回笼预测（未来 30/60/90 天）
- OA 账期到期清单

**Sheet 8: 诚实提醒**
直接说：
- 哪个工厂是"延期黑洞"（建议换厂或调整下单量）
- 哪个业务员承诺交期最不靠谱
- 哪类产品易超期（系统性产能问题）
- 哪个国家客户最难伺候（频繁改单/拖签收）

字体：Microsoft YaHei
表头：#0A2540 深蓝填充 + 白色加粗 11pt + 居中
数据：10pt 左上对齐 + 无边框
文件命名：`订单看板-{日期}.xlsx`
保存路径：`/Users/wenghaofan/Desktop/AI文件/订单看板/`

## 客户告知话术模板（4 种）

**正常进度**（周报式）
```
Hi [Name], weekly update on PO [No]:
- Status: production 70% complete
- Next milestone: QC inspection on [date]
- Expected delivery: on track for [date]
Photos attached. Let me know if you have questions.
```

**即将延期预警**
```
Hi [Name], heads-up on PO [No]:
We're tracking 5-7 days behind schedule due to [specific reason].
New ETD: [date] (vs original [date]).
Options to mitigate:
1. Air freight upgrade for 50% qty (we cover $X)
2. Split shipment: 50% on time + 50% delayed by 7 days
3. Hold full shipment for [new date]
What works best for your end?
```

**已延期道歉**
```
Hi [Name], honest update on PO [No]:
Shipment is delayed by [X] days. The root cause is [specific reason — not blaming],
and we take full responsibility.

To make it right:
- Air freight upgrade at our cost (saves you 25 days)
- 3% credit on next order
- Direct line to factory manager for live updates

I owe you this delay. Won't happen again.
```

**提前完成**
```
Good news on PO [No] — production wrapped 5 days early.
Can ship as soon as [date] if you're ready.
Want me to book vessel for [date] instead of [original]?
```

## 注意事项

- **延期不要瞒**：发现延期立即告知客户，提前 5 天预警比延期当天通知好 10 倍
- **告知话术要具体**：不能写"due to unexpected issues"，要"raw material supplier delayed by 3 days due to port strike in [city]"
- **道歉话术要敢承担**：不要找借口，"we take full responsibility"+"to make it right" 比连篇借口更能挽回信任
- **里程碑日历强制每天看**：业务员每天 9 点看一遍当天必做事项
- **延期罚款要算清**：很多合同有 0.5-3%/周罚款条款，延期 4 周可能损失 12% 订单金额
- **去 AI 化**：模板腔 "we sincerely apologize for any inconvenience" 不要，直接说"I owe you this delay"
- **看板保留 1 年历史**：用于年终复盘，找系统性问题（哪个工厂/哪个业务员/哪类产品）

## 验证

- 看板能否让老板 5 分钟看出"哪些订单这周必须救火"
- 延期清单是否每条带"责任方+紧急动作+客户话术"3 要素
- 财务影响是否预估了延期罚款（不是只算回款）
- 诚实提醒是否敢点名工厂/业务员
- 里程碑日历是否覆盖未来 7 天每天的具体动作
