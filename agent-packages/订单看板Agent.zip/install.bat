@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「订单看板Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\order-dashboard"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"order-dashboard\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"订单看板Agent\",\r\n  \"description\": \"外贸订单全生命周期看板。7阶段（订金到账→备料→生产→质检→报关→出运→签收）红绿灯预警（🟢🟡🟠🔴⚫）+延期清单（责任方+紧急动作+客户话术三要素）+里程碑日历（未来7天每天必做事项）+4种客户告知话术+财务回款预测+诚实提醒（点名延期黑洞工厂/业务员）。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「订单看板Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
