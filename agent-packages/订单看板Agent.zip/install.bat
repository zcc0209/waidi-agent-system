@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「订单看板Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-04DA0953-72660445"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-04DA0953-72660445","name":"订单看板Agent","description":"外贸订单全生命周期看板。7阶段（订金到账→备料→生产→质检→报关→出运→签收）红绿灯预警（🟢🟡🟠🔴⚫）+延期清单（责任方+紧急动作+客户话术三要素）+里程碑日历（未来7天每天必做事项）+4种客户告知话术+财务回款预测+诚实提醒（点名延期黑洞工厂/业务员）。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「订单看板Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
