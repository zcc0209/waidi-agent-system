@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「订单看板Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-04DA0953-72660445"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-04DA0953-72660445","name":"订单看板Agent","description":"外贸订单全生命周期看板。7阶段（订金到账→备料→生产→质检→报关→出运→签收）红绿灯预警（🟢🟡🟠🔴⚫）+延期清单（责任方+紧急动作+客户话术三要素）+里程碑日历（未来7天每天必做事项）+4种客户告知话术+财务回款预测+诚实提醒（点名延期黑洞工厂/业务员）。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「订单看板Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
