@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「收款风控Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-9EF8F7C2-A83530B8"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-9EF8F7C2-A83530B8","name":"收款风控Agent","description":"外贸收款风控与付款方式风险扫描。四维评估（客户国家×客户类型×订单金额×付款方式）输出红黄绿风险等级+5种主流收款方式风险对比（T/T/L/C/PayPal/Stripe/信保）+国家黑白名单+信保额度评估+冻结/拒付/退单预警+替代付款方案+催收话术+坏账止损流程。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「收款风控Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
