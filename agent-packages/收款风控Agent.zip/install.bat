@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「收款风控Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-9EF8F7C2-A83530B8"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-9EF8F7C2-A83530B8`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"收款风控Agent`",`r`n  `"description`": `"外贸收款风控与付款方式风险扫描。四维评估（客户国家×客户类型×订单金额×付款方式）输出红黄绿风险等级+5种主流收款方式风险对比（T/T/L/C/PayPal/Stripe/信保）+国家黑白名单+信保额度评估+冻结/拒付/退单预警+替代付款方案+催收话术+坏账止损流程。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「收款风控Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
