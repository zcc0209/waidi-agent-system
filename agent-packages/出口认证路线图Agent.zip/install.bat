@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「出口认证路线图Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-A89B1BA1-5D001DC8"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-A89B1BA1-5D001DC8","name":"出口认证路线图Agent","description":"外贸出口产品认证路线图。输入产品品类+目标国，自动匹配30+主流认证（CE/UKCA/FCC/RoHS/FDA等）强制清单，推荐5梯队测试机构，输出申请SOP（费用/周期/材料）+不合规风险量化+续证日历，让你绝不因认证问题被扣货。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「出口认证路线图Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
