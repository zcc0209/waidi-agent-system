# 出口认证路线图Agent

外贸出口产品认证路线图。输入产品品类+目标国，自动匹配30+主流认证（CE/UKCA/FCC/RoHS/FDA等）强制清单，推荐5梯队测试机构，输出申请SOP（费用/周期/材料）+不合规风险量化+续证日历，让你绝不因认证问题被扣货。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
