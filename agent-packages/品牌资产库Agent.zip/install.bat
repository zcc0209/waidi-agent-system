@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「品牌资产库Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-B5591E90-BC5C814D"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-B5591E90-BC5C814D","name":"品牌资产库Agent","description":"外贸品牌资产统一管理。覆盖8大类资产（LOGO/VI/产品图/视频/文案/营销物料/版权/案例）+3级分级+强制命名规范+5大对象差异化分发SOP+5大盗用监测渠道+Brand Book 10模块，终结「LOGO最终版-真的最终版-改1」乱象。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「品牌资产库Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
