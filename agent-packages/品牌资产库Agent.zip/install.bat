@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「品牌资产库Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-B5591E90-BC5C814D"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-B5591E90-BC5C814D","name":"品牌资产库Agent","description":"外贸品牌资产统一管理。覆盖8大类资产（LOGO/VI/产品图/视频/文案/营销物料/版权/案例）+3级分级+强制命名规范+5大对象差异化分发SOP+5大盗用监测渠道+Brand Book 10模块，终结「LOGO最终版-真的最终版-改1」乱象。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「品牌资产库Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
