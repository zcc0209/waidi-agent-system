# 品牌资产库Agent

外贸品牌资产统一管理。覆盖8大类资产（LOGO/VI/产品图/视频/文案/营销物料/版权/案例）+3级分级+强制命名规范+5大对象差异化分发SOP+5大盗用监测渠道+Brand Book 10模块，终结「LOGO最终版-真的最终版-改1」乱象。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
