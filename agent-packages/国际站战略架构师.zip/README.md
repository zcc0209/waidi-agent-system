# 国际站战略架构师



**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
