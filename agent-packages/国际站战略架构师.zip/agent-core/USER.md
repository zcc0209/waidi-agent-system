# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

<!-- ACCIO_WORK:BEGIN_USER_PROFILE -->
- **What to call them:** 潮总
- **Preferred Language:** 中文
- **Notes:** 

## Context


<!-- ACCIO_WORK:END_USER_PROFILE -->

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.

<!-- ACCIO_WORK:BEGIN_CONNECTED_ACCOUNTS -->
## Connected Accounts

The user has connected the following third-party services. You can use the corresponding tools to access these services on behalf of the user.

- **Gmail**: xxu219999@gmail.com
  For Gmail operations, run `accio-mcp-cli toolkit gmail` with `bash` tool to list available tools, and read the `gmail-assistant` skill for usage patterns and examples.
- **OKKI**: passport:442304:56873874
- **OKKI**: passport:18617:55259805
- **OKKI**: passport:18137:55257804
- **OKKI**: passport:364481:57196176
- **OKKI**: passport:354782:56332870
- **LinkedIn**: queeniehsu11240@gmail.com
- **Alibaba.com**: cn1576186046cveo (user_email: 153***@163.com, connector_id: 7715a577622b, ali_id: 2500001687094, service_type: cnfm, company_name: User name)
- **Alibaba.com**: lyxingge (user_email: adm***@xgscreen.com, connector_id: 17341acda19d, ali_id: 2216626163147, service_type: cgs, company_name: Henan Xingge Metal Prouduts Co., Ltd.)
- **Twitter/X**: haomaison (x_user_id: 2070024052685848576)
  For posting / scheduling / analytics on Twitter/X, read the `social-media-publisher` skill for the supported workflow.
- **SHOPLINE**: chengzicz (scope: write_shop_policy,write_files,read_content,write_fulfillment_service,read_data_report,read_orders,read_page,read_fulfillment_service,read_store_log,read_draft_orders,read_store_staff,write_translation,read_publications,read_products,read_returns,write_products,read_store_information,read_price_rules,read_marketing_event,read_inventory,write_draft_orders,write_gift_card,write_script_tags,write_store_information,write_product_variant_images,read_product_listings,write_markets,write_inventory,read_product_sizechart,write_return,write_discounts,read_shipping,write_publications,read_store_metrics,read_translation,read_assigned_fulfillment_orders,write_product_listings,read_shop_policy,write_marketing_event,read_product_variant_images,write_page,write_customers,write_themes,read_customers,read_location,write_price_rules,read_markets,write_bulkoperation,read_gift_card,write_checkouts,write_orders,write_content,write_shipping,read_script_tags,read_bulkoperation,write_product_sizechart,read_themes,read_payment,write_assigned_fulfillment_orders,read_discounts,unauthenticated_write_checkouts_info,unauthenticated_write_customer_information,unauthenticated_write_message,unauthenticated_read_message,unauthenticated_write_cart,unauthenticated_read_metaobjects,unauthenticated_read_cart,unauthenticated_read_checkouts_info)
<!-- ACCIO_WORK:END_CONNECTED_ACCOUNTS -->
