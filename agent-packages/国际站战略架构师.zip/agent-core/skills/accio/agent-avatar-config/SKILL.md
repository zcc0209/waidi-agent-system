---
name: "[Harvest] Accio智能体头像配置"
description: 用于在Accio平台为智能体更新或匹配符合系统调性的头像。适用于需要修改profile.jsonc中avatarUrl字段的场景，特别是当默认生成图片不符合UI规范时。注意处理JSONC注释及Base64编码格式。
created_by: main_agent
---
## Workflow
1. **定位配置文件**：进入目标智能体目录 `{agent_id}/agent-core/`，读取 `profile.jsonc` 文件。注意该文件包含注释，不能直接使用标准JSON解析器。
2. **分析现有风格**：若需保持调性一致，先读取同系列其他智能体（如MID开头）的 `profile.jsonc`，提取 `avatarUrl` 字段。观察其是CDN链接还是Base64字符串，并记录图片尺寸与视觉风格（如图标化、扁平化）。
3. **生成或获取头像**：根据风格要求生成新头像。若使用AI生成，确保输出为正方形、背景简洁的专业图标或肖像。将图片转换为Base64字符串（不含前缀 `data:image/png;base64,` 或含前缀需根据现有格式决定，通常保留完整Data URI）。
4. **更新配置**：使用支持JSONC的工具或正则替换方式，将 `profile.jsonc` 中的 `"avatarUrl": "..."` 值替换为新图片数据。务必保留文件中的注释和其他格式。
5. **验证生效**：重启智能体或刷新UI，检查头像是否正确显示且无破损。若显示异常，检查Base64字符串完整性或JSONC语法错误。

## Suggestions
- 优先参考同业务线（如MID-NEWBIZ系列）的头像风格，确保视觉统一性。
- 若Base64字符串过长导致文件难以编辑，可考虑上传至内部CDN并使用URL引用（如果系统支持）。
- 使用 `python3 -c "import base64; ..."` 脚本快速转换图片格式，避免手动编码错误。

## Fallback / Edge Cases
- **JSONC解析失败**：标准JSON库无法解析带注释的文件。 fallback：使用正则表达式直接替换 `"avatarUrl"` 对应的值，或使用专门的JSONC解析库。
- **Base64损坏**：若头像显示为破碎图标，检查Base64字符串是否在复制过程中被截断或包含换行符。确保字符串连续无空格。

## Pitfalls
- **步骤4**：直接写入标准JSON会丢失 `profile.jsonc` 中的注释，可能导致配置元数据丢失。必须使用保留注释的写入方式或正则替换。
- **步骤3**：生成的图片比例非1:1可能导致UI裁剪变形。务必在生成阶段强制正方形构图。
