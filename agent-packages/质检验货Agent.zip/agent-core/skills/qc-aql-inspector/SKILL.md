---
name: qc-aql-inspector
description: 外贸 AQL 抽检方案与验货报告解读。当用户要求"验货/AQL/质检方案/抽样/验货报告解读/SGS报告/BV验货/客户来验厂/质量整改"时触发，按订单数量自动生成 AQL 抽样表（GB2828/ISO2859）+ 检验项目清单（外观/尺寸/功能/包装/标签）+ 缺陷分级（致命/严重/轻微）+ 第三方验货报告诊断+整改建议+客户沟通话术。
version: 1.0.0
---

# 质检/验货 Agent（AQL + 第三方报告解读）

## 触发场景
- 客户要求 AQL 验货，业务员不会做抽样表
- 收到 SGS/BV/TUV 验货报告看不懂
- 客户验厂/验货前要做内部预检
- 验货不通过要做整改并说服客户复检
- 老板要规范化 SOP 减少质量纠纷

## 输入

必需：
- 订单数量
- 产品类型（电子/家居/服装/玩具/工业品等，影响 AQL 等级选择）
- 检验等级要求（一般 II 级 / 严格 III 级 / 简化 I 级）
- AQL 值（致命/严重/轻微缺陷各一个，常见 0/2.5/4.0）

可选：
- 客户提供的检验标准（QC checklist）
- 第三方验货报告（SGS/BV/TUV/Intertek 等）
- 历史验货数据（用于趋势分析）

## AQL 抽样表（基于 ISO 2859-1 / GB2828.1）

### 检验等级（多数客户用 II 级）

| 订单批量 | I 级抽样字码 | II 级抽样字码 | III 级抽样字码 |
|---|---|---|---|
| 2-8 | A | A | B |
| 9-15 | A | B | C |
| 16-25 | B | C | D |
| 26-50 | C | D | E |
| 51-90 | C | E | F |
| 91-150 | D | F | G |
| 151-280 | E | G | H |
| 281-500 | F | H | J |
| 501-1200 | G | J | K |
| 1201-3200 | H | K | L |
| 3201-10000 | J | L | M |
| 10001-35000 | K | M | N |
| 35001-150000 | L | N | P |
| 150001-500000 | M | P | Q |

### 抽样字码对应抽样数量

| 字码 | 抽样数 | AQL 0 接收/拒收 | AQL 2.5 接 / 拒 | AQL 4.0 接 / 拒 | AQL 6.5 接 / 拒 |
|---|---|---|---|---|---|
| A | 2 | 0/1 | 0/1 | 0/1 | 0/1 |
| B | 3 | 0/1 | 0/1 | 0/1 | 0/1 |
| C | 5 | 0/1 | 0/1 | 0/1 | 1/2 |
| D | 8 | 0/1 | 0/1 | 1/2 | 1/2 |
| E | 13 | 0/1 | 1/2 | 1/2 | 2/3 |
| F | 20 | 0/1 | 1/2 | 2/3 | 3/4 |
| G | 32 | 0/1 | 2/3 | 3/4 | 5/6 |
| H | 50 | 0/1 | 3/4 | 5/6 | 7/8 |
| J | 80 | 0/1 | 5/6 | 7/8 | 10/11 |
| K | 125 | 0/1 | 7/8 | 10/11 | 14/15 |
| L | 200 | 0/1 | 10/11 | 14/15 | 21/22 |
| M | 315 | 0/1 | 14/15 | 21/22 | / |
| N | 500 | 0/1 | 21/22 | / | / |

### 缺陷三级分类

- **CR 致命缺陷 Critical** (AQL 0)：危及人身安全/法规违规（带电短路/有害物质超标/认证标志缺失）
- **MA 严重缺陷 Major** (AQL 2.5)：影响功能/严重影响外观（无法开机/严重划痕/包装严重破损）
- **MI 轻微缺陷 Minor** (AQL 4.0)：不影响功能/轻微外观（轻微色差/小气泡/标签轻微歪）

## 工作流

### Step 1: 抽样方案生成

输入订单数量+检验等级+AQL → 输出：
```
═══ AQL 抽样方案 ═══
订单数量：5000 件
检验等级：II 级
抽样字码：L
抽样数：200 件
AQL 标准：CR 0 / MA 2.5 / MI 4.0

判定标准：
- 致命缺陷：发现 0 接收，发现 1 立即拒收
- 严重缺陷：发现 ≤10 接收，≥11 拒收
- 轻微缺陷：发现 ≤14 接收，≥15 拒收
═══════════════
```

### Step 2: 检验项目清单（按品类）

**通用 5 大维度**：
1. **外观**：刮花/凹陷/色差/油污/拉丝纹/喷涂均匀度
2. **尺寸**：长宽高公差（±0.5mm）/ 重量公差（±5%）
3. **功能**：开关/连接/受力/绝缘/防水（按 IP 等级）
4. **包装**：彩盒印刷/内衬/外箱抗压/封箱胶位置
5. **标签**：条码扫描/原产国/型号/认证标志/警示语

**按品类细化**（举例）：
- 电子产品：电压测试 / 电流测试 / 高低温老化 / EMC / RoHS
- 服装：色牢度 / 缩水率 / 拉伸 / 洗涤标 / 吊牌
- 玩具：安全测试 EN71/ASTM F963 / 小零件可吞咽性 / 锐边
- 厨具：食品级认证 / 耐温 / 耐腐蚀
- 工业品：力学性能 / 防锈 / 焊缝 / 铭牌

### Step 3: 第三方验货报告解读

输入 SGS/BV/TUV 报告 → 输出：
```
═══ 验货报告诊断 ═══
报告号：[Report No]
检验机构：SGS
检验日期：[Date]
订单批量：5000
抽样数：200

检验结果：FAIL ❌
缺陷统计：
- CR 致命：1 处（充电短路）→ 立即拒收
- MA 严重：12 处（划痕 6 / 包装破 4 / 标签歪 2）→ 超 AQL 11，拒收
- MI 轻微：8 处 → 在 AQL 14 内，可接受

主要问题根因（推测）：
1. 产线最后一关质检不严
2. 包装环节人手不足
3. 物流震动导致破损（非工厂原因）

整改建议：
1. 工厂层面：[具体动作]
2. 物流层面：[具体动作]
3. 时间表：3-5 天整改 + 重新验货

客户沟通话术（已生成）：见 Step 5
═══════════════
```

### Step 4: 整改建议（差时给改进方案）

按缺陷类型给针对性整改：
- **外观划痕**：增加产线缓冲垫 + 终检员加强 + 作业员手套
- **尺寸超差**：模具校准 + 首件检 SOP
- **功能失效**：电路板焊接质量 / 元件批次问题排查
- **包装破损**：彩盒厚度升级 + 内衬加海绵 + 外箱抗压测试
- **标签错误**：制作前客户书面确认 + 标签上线前 100% 核对

### Step 5: 客户沟通话术（按结果分 3 种）

**A. 验货通过（PASS）**
```
Hi [Name], great news on PO [No]:
Third-party inspection (SGS, [Date]) cleared with PASS.
Report attached for your records.
We're now booking vessel for [date]. Let me know if you'd like a different schedule.
```

**B. 验货部分通过（部分整改）**
```
Hi [Name], inspection update on PO [No]:
Inspection identified [X] minor defects (within AQL 4.0 tolerance — technically PASS),
plus 5 cosmetic issues we'd like to fix anyway before shipment.

Plan: 100% rework on those 5 issues, 3 days. Then shipment as scheduled.
Photos and re-inspection report will follow. Want SGS to do a re-check (we cover the cost)?
```

**C. 验货不通过（重大整改）**
```
Hi [Name], honest update on PO [No]:
Inspection identified critical issues (1 CR + 12 MA defects). Honestly, this batch isn't shippable.

Root cause: [specific factory issue, no excuses].
Action plan:
1. 100% rework over [X days] at our cost
2. Re-inspection by [SGS] before shipment
3. New ETD: [date] (vs original [date])

To make this right:
- Air freight upgrade for 30% qty at our cost (recovers your stock timeline)
- 3% credit on next PO
- Direct line to factory manager

I take full responsibility. Photos attached showing the rework progress in real time.
```

### Step 6: 输出 Excel 报告

**Sheet 1: AQL 抽样方案**（含抽样表查询结果）
**Sheet 2: 检验项目清单**（按品类生成的 checklist）
**Sheet 3: 缺陷分级标准**（CR/MA/MI 详细定义）
**Sheet 4: 验货报告解读**（如有第三方报告）
**Sheet 5: 整改方案**（含责任人+期限+复检计划）
**Sheet 6: 客户话术**（3 种结果对应话术）

## 注意事项

- **AQL 不是越严越好**：AQL 0/2.5/4.0 是行业标准，太严工厂做不到，太松客户不接受
- **CR 致命零容忍**：哪怕只有 1 处 CR 也要全检整改，绝不蒙混过关
- **抽样不能"挑好的"**：必须从全批次随机抽，不能让工厂事先准备一批"样品"
- **第三方比内部更可信**：大客户认 SGS/BV/TUV，内部质检报告说服力低
- **整改要根因不要表象**：发现划痕不是"工人粗心"，要追到"产线缓冲不足"等系统原因
- **去 AI 化**：报告不要"建议加强质量管理"，要"产线 2 末端缓冲垫由 5mm 升级到 10mm，今晚换上"
- **报告要给客户看**：第三方原版报告+我们的整改方案+复检照片，三件套发给客户最专业
- **不要藏问题**：发现问题主动告知客户，比客户验出来后被动应对好 10 倍
- **复检要请第三方**：整改后让 SGS 复检，不能自己说"已整改 OK"

## 验证

- AQL 抽样数是否严格按 ISO 2859 标准（不是拍脑袋抽 10%）
- CR/MA/MI 缺陷判定标准是否清晰可执行
- 验货报告解读是否定位到根因（不是只列缺陷）
- 整改建议是否带责任人+期限+复检计划
- 客户话术是否敢承担责任（不是甩锅给运输/原料）
- 是否覆盖整改后的复检环节（不是整改完就完了）
