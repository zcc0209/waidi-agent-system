@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「质检验货Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\qc-aql-inspector"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"qc-aql-inspector\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"质检验货Agent\",\r\n  \"description\": \"外贸AQL抽检方案与验货报告解读。基于ISO 2859-1/GB2828自动生成AQL抽样表（订单量→字码→抽样数→CR/MA/MI判定标准）+5维度检验项目清单+第三方报告（SGS/BV/TUV）诊断解读+整改建议（根因+责任人+期限）+3种结果客户话术（通过/部分整改/不通过），CR致命缺陷零容忍。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「质检验货Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
