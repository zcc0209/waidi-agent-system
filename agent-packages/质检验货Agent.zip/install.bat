@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「质检验货Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-88A7231C-D8B3FB4D"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-88A7231C-D8B3FB4D","name":"质检验货Agent","description":"外贸AQL抽检方案与验货报告解读。基于ISO 2859-1/GB2828自动生成AQL抽样表（订单量→字码→抽样数→CR/MA/MI判定标准）+5维度检验项目清单+第三方报告（SGS/BV/TUV）诊断解读+整改建议（根因+责任人+期限）+3种结果客户话术（通过/部分整改/不通过），CR致命缺陷零容忍。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「质检验货Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
