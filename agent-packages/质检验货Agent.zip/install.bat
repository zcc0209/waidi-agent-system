@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「质检验货Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-88A7231C-D8B3FB4D"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-88A7231C-D8B3FB4D","name":"质检验货Agent","description":"外贸AQL抽检方案与验货报告解读。基于ISO 2859-1/GB2828自动生成AQL抽样表（订单量→字码→抽样数→CR/MA/MI判定标准）+5维度检验项目清单+第三方报告（SGS/BV/TUV）诊断解读+整改建议（根因+责任人+期限）+3种结果客户话术（通过/部分整改/不通过），CR致命缺陷零容"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「质检验货Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
