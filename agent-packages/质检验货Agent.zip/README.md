# 质检验货Agent

外贸AQL抽检方案与验货报告解读。基于ISO 2859-1/GB2828自动生成AQL抽样表（订单量→字码→抽样数→CR/MA/MI判定标准）+5维度检验项目清单+第三方报告（SGS/BV/TUV）诊断解读+整改建议（根因+责任人+期限）+3种结果客户话术（通过/部分整改/不通过），CR致命缺陷零容忍。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
