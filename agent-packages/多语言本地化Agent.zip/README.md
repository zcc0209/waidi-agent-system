# 多语言本地化Agent

外贸多语言本地化（文化适配不是直译）。8语种（英/西/法/德/俄/阿/日/葡）文化适配翻译+本地化SEO关键词+度量衡/货币/电压/插头转换+合规标签本地化（WEEE/VerpackG/INMETRO/PSE等）+常见翻译陷阱+RTL排版指南+母语审核SOP。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
