@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「多语言本地化Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-0AB0AE95-6DEF917D"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-0AB0AE95-6DEF917D","name":"多语言本地化Agent","description":"外贸多语言本地化（文化适配不是直译）。8语种（英/西/法/德/俄/阿/日/葡）文化适配翻译+本地化SEO关键词+度量衡/货币/电压/插头转换+合规标签本地化（WEEE/VerpackG/INMETRO/PSE等）+常见翻译陷阱+RTL排版指南+母语审核SOP。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「多语言本地化Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
