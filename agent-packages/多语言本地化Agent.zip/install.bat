@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「多语言本地化Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-0AB0AE95-6DEF917D"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-0AB0AE95-6DEF917D","name":"多语言本地化Agent","description":"外贸多语言本地化（文化适配不是直译）。8语种（英/西/法/德/俄/阿/日/葡）文化适配翻译+本地化SEO关键词+度量衡/货币/电压/插头转换+合规标签本地化（WEEE/VerpackG/INMETRO/PSE等）+常见翻译陷阱+RTL排版指南+母语审核SOP。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「多语言本地化Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
