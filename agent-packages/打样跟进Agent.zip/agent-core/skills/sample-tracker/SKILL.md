---
name: sample-tracker
description: 外贸打样跟进与样品转化智能体。当用户要求"打样/寄样/样品跟进/打样节点/样品物流/样品反馈/样品没回复/样品到了客户不说话/样品转单/如何催样品结果"时触发，覆盖打样全链路 8 阶段（需求确认→工厂打样→内部QC→寄出→在途→到达→客户反馈→决策催单）+ 物流方式选择 + 费用分摊话术 + 客户反馈结构化 + 10 类反馈状态分类 + 催单节奏表（按国家/客户类型差异化）+ 12 sheet Excel + 诚实提醒。
version: 1.0.0
---

# 打样跟进 Agent

## 触发场景
- 客户要样品，需要制定打样计划
- 样品寄出后客户不回复，不知道怎么催
- 一个月寄了 10 个样品，没一个转单
- 老板问"这个月打样费花了多少，转化几个"
- 不知道打样费该不该收 / 怎么收
- 样品到了客户说不满意，怎么处理
- 想建立打样 SOP，避免每次从零开始

## 输入信息

```
1. 产品信息
   - 产品名 / SKU / 规格
   - 标品 or 定制品（影响打样周期）
   - 工厂打样费 + 物料成本

2. 客户信息
   - 客户等级（D/G/S/B/K from customer-tier-segmentation）
   - 国家 / 时区
   - 询盘阶段（首次 / 报价后 / 谈判中）
   - 预期订单量

3. 物流偏好
   - 快递 / 空运 / 海运
   - 费用谁承担（我方 / 客户 / 各半）
```

## 打样全链路 8 阶段

```
┌──────────────────────────────────────────────┐
│ Stage 1：需求确认（Day 0）                    │
│ Stage 2：工厂打样（Day 1-7）                  │
│ Stage 3：内部 QC 验样（Day 7-8）              │
│ Stage 4：包装寄出（Day 8-9）                  │
│ Stage 5：在途追踪（Day 9-15）                 │
│ Stage 6：到达确认（Day 15-18）                │
│ Stage 7：客户评估（Day 18-35）                │
│ Stage 8：决策催单 / 改样 / 关闭（Day 35+）    │
└──────────────────────────────────────────────┘
```

### Stage 1：需求确认（Day 0）

```
必确认 7 项（避免打错样）：
□ 1. 产品型号/规格/材质/颜色
□ 2. 数量（几个样？含配件不含？）
□ 3. 是否带 LOGO / 印刷 / 定制标签
□ 4. 包装要求（内盒/外箱/标准or出口）
□ 5. 客户用途（自己评估/给终端客户/送检/上架测试）
□ 6. 费用约定（免费/收费/到付/预付）
□ 7. 时间要求（紧急 3 天 / 标准 7 天 / 不急 15 天）

⚠️ 80% 的打样问题来自 Stage 1 确认不够：
- 颜色色差（没确认 Pantone 号）
- 尺寸错误（单位 inch vs cm）
- 材质错误（客户说"metal"没确认不锈钢型号）
```

### Stage 2：工厂打样（Day 1-7）

```
打样周期参考：
- 标品（有现成）：1-3 天
- 轻定制（改色/改 LOGO）：3-5 天
- 重定制（开模/改结构）：7-15 天
- 全新开模：15-30 天

跟厂节奏：
- Day 1：确认工厂收到需求 + 排期
- Day 3：确认进度（照片/视频）
- Day 5：提醒交期（如 7 天承诺）
- Day 7：收样 + 拍照留存
```

### Stage 3：内部 QC 验样（Day 7-8）

```
验样 5 项（寄出前必查）：
□ 1. 外观（色差/毛刺/划痕/气泡）
□ 2. 尺寸（实测 vs 图纸）
□ 3. 功能（通电/开关/承重等）
□ 4. 包装完整度（标签/说明书/配件齐全）
□ 5. 与客户需求逐项对照

⚠️ 铁律：不合格的样品绝不寄出
   → 宁可延迟 3 天 + 通知客户，不可寄次品（信任一次崩完）
```

### Stage 4：包装寄出（Day 8-9）

```
打包标准：
- 防震：气泡膜 3 层 + 四角加固
- 防水：PE 袋密封
- 标识：外贴样品标签（产品名/型号/数量/联系方式）
- 附件：装箱清单 + 名片 + 产品说明书

物流选择：
| 方式 | 时效 | 费用 | 适合 |
|---|---|---|---|
| DHL | 3-5 天 | $40-80/kg | 紧急 / VIP |
| FedEx | 3-5 天 | $35-70/kg | 美国快 |
| UPS | 4-7 天 | $35-60/kg | 备选 |
| 顺丰国际 | 5-7 天 | $25-50/kg | 性价比 |
| EMS | 7-12 天 | $15-30/kg | 经济 |
| 海运寄样 | 25-40 天 | $5-10/kg | 大件/非紧急 |
```

### Stage 5：在途追踪（Day 9-15）

```
跟踪节奏：
- 寄出当天：发运单号 + 预计到达日期给客户
- Day +3：确认过关/在途
- Day +5：如延误，主动通知客户

邮件模板（寄出当天）：
"Hi [Name],
Good news! Your samples have been shipped via DHL.
Tracking number: XXXXXX
Estimated delivery: [Date]
Please let me know once you receive them. Looking forward to your feedback!
Best regards"
```

### Stage 6：到达确认（Day 15-18）

```
到达后 48h 内必做：
1. 发消息确认是否收到
2. 确认包装是否完好
3. 温馨提示评估时注意事项

邮件模板（到达确认）：
"Hi [Name],
According to tracking, your samples should have arrived.
Could you confirm receipt? If you need any help evaluating them 
(spec sheets, testing guidelines, comparison charts), I'm happy to provide.
Take your time — I'll follow up next [Day] for your feedback."
```

### Stage 7：客户评估（Day 18-35）

```
客户评估周期（按国家/客户类型）：
- 欧美大客户：2-4 周（要过采购委员会）
- 中东客户：1-2 周（决策快但需要 push）
- 日本客户：4-8 周（极慢，但一旦确认忠诚度极高）
- 东南亚客户：1-2 周
- 印度客户：2-4 周（还价为主）
```

### Stage 8：决策催单

详见下方"催单节奏表"。

## 客户反馈 10 类状态分类

| # | 状态 | 含义 | 下一步 |
|---|---|---|---|
| 1 | ✅ 满意-下单 | 样品 OK，准备下大货 | → 报价 → 合同 |
| 2 | ✅ 满意-暂缓 | OK 但非现在买 | → 加入复购周期管理 |
| 3 | ⚠️ 部分满意 | 主体 OK，细节要改 | → 确认改点 → 改样 |
| 4 | ⚠️ 未达预期 | 不满意但不拒绝 | → 了解痛点 → 改良方案 |
| 5 | ❌ 不满意 | 样品与需求差距大 | → 判断能否补救 or Kill |
| 6 | 👻 已收到-不回 | 收了但沉默 | → 催单 3 波 |
| 7 | 🔄 转给终端 | 样品给了下游客户 | → 跟进终端反馈 |
| 8 | 💰 压价 | 以样品为由砍价 | → 谈判教练介入 |
| 9 | 🔍 还在测 | 在做内部测试/送检 | → 等结果 + 提供测试辅助 |
| 10 | ☠️ 消失 | 完全失联 | → 60 天 Kill or 最后一搏 |

## 催单节奏表（⭐ 杀手锏）

### 按客户等级差异化

| 等级 | 催单频率 | 话术风格 | 底线 |
|---|---|---|---|
| D 钻石 | 7 天 1 次（轻催） | 关怀型 | 不主动催 → 等他们 |
| G 金牌 | 5 天 1 次 | 价值型 | 3 轮不回转电话 |
| S 银牌 | 4 天 1 次 | 紧迫型 | 3 轮不回转 WhatsApp |
| B 青铜 | 3 天 1 次 | 直接型 | 2 轮不回 Kill |

### 按国家时差节奏

| 国家 | 联系时间 | 催单频率 | 特殊注意 |
|---|---|---|---|
| 美国 | 北京 21:00-次日 02:00 | 5 天 | 周末不联系 |
| 欧洲 | 北京 15:00-22:00 | 7 天 | 休假期长 |
| 中东 | 北京 13:00-19:00 | 3 天 | 周五不联系（Juma'ah）|
| 日本 | 北京 09:00-17:00 | 10 天 | 不催，等 |
| 印度 | 北京 11:00-18:00 | 4 天 | 习惯还价 |
| 东南亚 | 北京 09:00-17:00 | 3 天 | 节奏快 |

### 3 波催单话术

```
第 1 波（到达后 7 天）—— 温和确认
"Hi [Name], just checking in — have you had a chance to review the samples? 
Happy to answer any questions or provide additional info for your evaluation."

第 2 波（到达后 14 天）—— 提供价值
"Hi [Name], I'd love to hear your thoughts on the samples.
FYI, we have a batch going into production on [Date] — if you'd like to be 
included in this run, we can offer [优势：时间/价格/数量]."

第 3 波（到达后 21 天）—— 直接但不逼
"Hi [Name], I understand you're busy. Just wanted to let you know our pricing 
for this item is valid until [Date]. After that, raw material costs may change.
No pressure — if the timing isn't right, we can revisit later."

最终波（到达后 35 天）—— 关闭或转入长期
"Hi [Name], since I haven't heard back, I'll assume the timing isn't right 
for now. I'll keep you updated on new products/pricing changes.
Feel free to reach out anytime — we're here when you're ready."
```

## 打样费用分摊话术

### 话术 1：免费策略（VIP / 年框客户）

```
"We'd love to provide free samples for your evaluation. 
We'll cover sample cost; you only need to pay shipping 
(approximately $XX via DHL, 3-5 days delivery)."
```

### 话术 2：收费策略（新客户 / 定制品）

```
"Since this is a customized sample, the cost is $XX (covers material + labor).
The good news: this amount will be fully deducted from your first order.
So effectively, it's free once you place the order."
```

### 话术 3：打样费筛选低质客户

```
规则：
- D/G 客户：一律免费（含运费）
- S/B 客户：样品免费 + 运费到付
- 新客户（未分级）：样品收费 + 运费到付
  → 愿意付 = 认真客户
  → 不愿意付 = 大概率浪费样品

⚠️ 打样费不是为了赚钱，是筛选工具：
   愿意付 $50 样品费的客户，下单概率是不愿意付的 5 倍
```

## 打样 ROI 看板

```
月度打样 ROI 计算：

打样投入 = 样品成本 + 物流费 + 人力（业务员时间）
打样产出 = 打样后 90 天内成交订单金额

ROI = 打样产出 / 打样投入

健康基线：
🟢 ROI ≥ 5x：打样策略正确
🟡 ROI 2-5x：可以优化（提高筛选精度）
🔴 ROI < 2x：打样太多 / 客户筛选差

每月追踪：
- 本月寄样数
- 本月样品成本
- 90 天内转单数
- 转化率 = 转单数 / 寄样数（基线 15-25%）
```

## 3 档方案

| 档位 | 策略 | 适合 | 月打样上限 |
|---|---|---|---|
| **保守** 严筛 | 只给付费客户/VIP 打样 | 资金紧 / 小团队 | 10 个 |
| **中性** 标准 | 按客户等级差异化 | 主流 | 20-30 个 |
| **激进** 广撒网 | 低成本品全免费 | 标品 / 获客期 | 50+ |

## 12 sheet Excel 输出

| # | Sheet | 关键列 |
|---|---|---|
| 1 | 一句话决策 | 月转化率 / ROI / 打样费优化建议 |
| 2 | 在途样品看板 | 客户/产品/寄出日/运单/状态/下一步 |
| 3 | 8 阶段进度表 | 每个样品在哪个 Stage / 超时预警 |
| 4 | 10 类反馈统计 | 10 种状态分布 / 占比 / 趋势 |
| 5 | 催单节奏记录 | 客户/波次/日期/方式/回复/结果 |
| 6 | 费用分摊汇总 | 月度打样费/物流费/谁承担/回收额 |
| 7 | 打样 ROI | 月度 ROI / 累计 / 趋势 / 基准对照 |
| 8 | 客户等级×打样策略 | D/G/S/B/K 分别怎么给 |
| 9 | 物流方式对照 | DHL/FedEx/UPS/顺丰/EMS 时效&费用 |
| 10 | 超时预警 | 超 7 天未收到反馈的客户清单 |
| 11 | 改样记录 | 改样原因/改点/次数/最终结果 |
| 12 | 诚实提醒 | 打样 8 大坑 + Kill 信号 |

## Kill List

```
🛑 Kill 1：同一客户 3 次免费寄样 + 0 成交 → 停止供样
🛑 Kill 2：不愿付 $30 运费的客户 → 95% 不会下单
🛑 Kill 3：催 3 轮完全不回复 → 标记 Kill + 60 天后最后尝试
🛑 Kill 4：只要最低价样品 + 无具体需求 → 对标型买家（偷你方案）
🛑 Kill 5：打样后压价 50%+ → 不尊重成本
🛑 Kill 6：改样 > 3 次 + 每次都换方向 → 客户自己不知道要什么
🛑 Kill 7：转给终端后终端不明 → 中间商没有决策权
```

## 工作流（标准 SOP）

```
Step 1：用户输入（产品 + 客户 + 物流偏好）
        ↓
Step 2：确认 7 项（Stage 1）
        ↓
Step 3：安排打样 + 跟厂（Stage 2-3）
        ↓
Step 4：QC 验样 + 寄出（Stage 3-4）
        ↓
Step 5：在途追踪 + 到达确认（Stage 5-6）
        ↓
Step 6：等客户评估 + 催单 3 波（Stage 7-8）
        ↓
Step 7：分类反馈（10 类状态）→ 对应下一步
        ↓
Step 8：月度 ROI 复盘 + 12 sheet Excel
```

## 上下游 Agent 衔接接口

```
←── 输入来源
    supplier-matcher：确认供应商后打样
    inquiry-triage：高级别询盘 → 立即打样
    buyer-icp-persona：VIP 客户优先打样

──→ 输出去向
    quote-generator：样品确认 → 报价
    negotiation-coach：客户压价 → 谈判策略
    sample-conversion-tracker：样品到客户后转化跟踪
    lost-customer-recovery：样品后失联 → 挽回
    customer-complaint-handler：样品问题 → 客诉处理
```

## 诚实提醒（强制）

```
🔴 免费样品 ≠ 善心：是投资，要算 ROI
🔴 寄 100 个样品转 5 个 → 你在烧钱：提高筛选精度比多寄样重要
🔴 样品好 ≠ 一定下单：客户 50% 只是在比价
🔴 催太频 = 赶走客户：日本客户催 1 次就够，催 3 次就反感
🔴 打样费收不收 = 战略选择：不是谁都免费，这是筛选工具
🔴 次品样品寄出 = 信任崩塌：宁可迟到 3 天不可寄残品
🔴 "到了告诉我" ≠ 跟进策略：要主动追踪 + 多波触达
🔴 改样 3 次以上 = 客户不知道要什么：考虑 Kill
```

## 验证

成功标准：
- 8 阶段 SOP 每个都有具体动作 + 时间节点
- 7 项确认清单完整
- 10 类反馈状态 → 对应下一步
- 催单 3 波 + 按国家时差差异化
- 打样费分摊话术 ≥ 3 版
- ROI 看板含基线（15-25% 转化率 / 5x ROI）
- Kill List ≥ 7 条
- 12 sheet Excel 完整

⚠️ 没有阶段化 SOP / 没有催单差异化 / 没有 ROI 的打样管理 = 不达标。
