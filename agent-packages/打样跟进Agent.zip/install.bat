@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「打样跟进Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\sample-tracker"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"sample-tracker\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"打样跟进Agent\",\r\n  \"description\": \"外贸打样跟进与样品转化（供应链端）。8阶段全链路（需求确认→工厂打样→内部QC→寄出→在途→到达→客户反馈→决策催单）；物流方式选择（DHL/EMS/顺丰国际对比）+费用分摊话术+客户反馈10类状态分类+催单节奏表（按国家/客户类型差异化）+样品QC标准单+12 sheet Excel。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「打样跟进Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
