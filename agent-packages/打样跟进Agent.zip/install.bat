@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「打样跟进Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-449E3F14-D7DB5130"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-449E3F14-D7DB5130","name":"打样跟进Agent","description":"外贸打样跟进与样品转化（供应链端）。8阶段全链路（需求确认→工厂打样→内部QC→寄出→在途→到达→客户反馈→决策催单）；物流方式选择（DHL/EMS/顺丰国际对比）+费用分摊话术+客户反馈10类状态分类+催单节奏表（按国家/客户类型差异化）+样品QC标准单+12 sheet Excel。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「打样跟进Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
