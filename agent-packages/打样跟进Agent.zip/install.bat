@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「打样跟进Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-449E3F14-D7DB5130"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-449E3F14-D7DB5130","name":"打样跟进Agent","description":"外贸打样跟进与样品转化（供应链端）。8阶段全链路（需求确认→工厂打样→内部QC→寄出→在途→到达→客户反馈→决策催单）；物流方式选择（DHL/EMS/顺丰国际对比）+费用分摊话术+客户反馈10类状态分类+催单节奏表（按国家/客户类型差异化）+样品QC标准单+12 sheet Excel。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「打样跟进Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
