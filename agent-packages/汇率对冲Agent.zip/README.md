# 汇率对冲Agent

外贸汇率对冲与锁汇建议。主流货币走势研判（USD/EUR/GBP/JPY/RUB）+订单层面汇率敞口测算（签单到收款期间汇率波动对毛利的影响）+5种对冲工具对比（远期结汇/期权/NDF/锁汇产品/币种切换）+银行报价比对+锁汇时机建议+毛利保护阈值+汇兑损益看板。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
