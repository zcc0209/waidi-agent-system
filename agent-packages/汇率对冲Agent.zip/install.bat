@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「汇率对冲Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-06E2BB38-171EB620"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-06E2BB38-171EB620","name":"汇率对冲Agent","description":"外贸汇率对冲与锁汇建议。主流货币走势研判（USD/EUR/GBP/JPY/RUB）+订单层面汇率敞口测算（签单到收款期间汇率波动对毛利的影响）+5种对冲工具对比（远期结汇/期权/NDF/锁汇产品/币种切换）+银行报价比对+锁汇时机建议+毛利保护阈值+汇兑损益看板。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「汇率对冲Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
