@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「团队OKR Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-09F9A156-DE126983"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-09F9A156-DE126983","name":"团队OKR Agent","description":"外贸团队OKR季度对齐与跟踪。公司O→部门KO→个人KR三层拆解+SMART检查+跨部门依赖矩阵+每周Check-in（红黄绿进度）+季末复盘评分（0-1.0分制）+激励机制（不挂提成），帮你把年度战略落到每周行动，OKR 0.7分即优秀。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「团队OKR Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
