@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「战略路线图Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-1DAB0FA6-1DCC1E69"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-1DAB0FA6-1DCC1E69","name":"战略路线图Agent","description":"外贸战略路线图（12/24/36个月里程碑）。整合业务诊断+市场洞察+目标国家+品牌定位，输出三阶段路线图+阶段KPI+资源配置（人/钱/工厂/渠道）+关键决策门（Go/No-Go判断条件）+风险对冲方案+退出条件+12 sheet Excel，是战略到落地的桥梁，也是本批智能体的总指挥。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「战略路线图Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
