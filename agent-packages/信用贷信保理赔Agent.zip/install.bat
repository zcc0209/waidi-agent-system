@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「信用贷信保理赔Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-CCE08454-AB906A06"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-CCE08454-AB906A06","name":"信用贷信保理赔Agent","description":"外贸信用贷与信保理赔全流程。信用贷产品对比（出口退税贷/订单贷/保单融资/阿里融资）+中信保/Coface额度申请SOP+理赔全流程（90天内报损必做事项+证据清单8项+追偿话术+拒赔申诉步骤）+信保保费优化建议+案件进度跟踪模板，坏账不等于损失，关键是90天内行动。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「信用贷信保理赔Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
