@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「信用贷信保理赔Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-CCE08454-AB906A06"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-CCE08454-AB906A06","name":"信用贷信保理赔Agent","description":"外贸信用贷与信保理赔全流程。信用贷产品对比（出口退税贷/订单贷/保单融资/阿里融资）+中信保/Coface额度申请SOP+理赔全流程（90天内报损必做事项+证据清单8项+追偿话术+拒赔申诉步骤）+信保保费优化建议+案件进度跟踪模板，坏账不等于损失，关键是90天内行动。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「信用贷信保理赔Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
