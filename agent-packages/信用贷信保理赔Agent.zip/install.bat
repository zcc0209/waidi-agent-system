@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「信用贷信保理赔Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\trade-finance-claims"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"trade-finance-claims\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"信用贷信保理赔Agent\",\r\n  \"description\": \"外贸信用贷与信保理赔全流程。信用贷产品对比（出口退税贷/订单贷/保单融资/阿里融资）+中信保/Coface额度申请SOP+理赔全流程（90天内报损必做事项+证据清单8项+追偿话术+拒赔申诉步骤）+信保保费优化建议+案件进度跟踪模板，坏账不等于损失，关键是90天内行动。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「信用贷信保理赔Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
