@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   =========================================
echo     安装「利润分析Agent」到 Accio Work
echo   =========================================
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录后重试
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-F568CC77-BD53FBBA"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    (echo {"id":"DID-F568CC77-BD53FBBA","name":"利润分析Agent","description":""}) > "!TARGET!\profile.jsonc"
    set /a installed+=1
    echo   ✓ 已安装到 %%~nxi
)
echo.
if %installed%==0 (
    echo [错误] 未找到任何账号，请先登录 Accio Work
) else (
    echo [完成] 「利润分析Agent」已安装到全部 %installed% 个空间
    echo.
    echo 请完全退出 Accio Work 后重新打开，在左侧智能体列表找到它
)
echo.
pause
