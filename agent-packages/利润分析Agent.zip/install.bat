@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「利润分析Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-F568CC77-BD53FBBA"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-F568CC77-BD53FBBA","name":"利润分析Agent","description":"外贸利润穿透分析（揪出'看着赚其实亏'的订单）。三层穿透：账面毛利→隐藏成本扣除（退货/售后/广告/汇损/坏账/返工）→真实利润；识别'血汗订单/血汗客户/血汗产品/血汗业务员'红黑清单+利润提升5大杠杆+改进路线图，让每张订单的钱花得明明白白。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「利润分析Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
