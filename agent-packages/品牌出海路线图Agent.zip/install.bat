@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「品牌出海路线图Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-946064E0-ACE96A28"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-946064E0-ACE96A28","name":"品牌出海路线图Agent","description":"外贸商家品牌出海年度路线图（⭐指挥棒）。按「贸易商→白牌→出海品牌→集团」4阶段输出阶段诊断+北极星升级指标+5年路线图+4大典型路径（Anker/SHEIN/Insta360/华为）+各阶段预算结构+5大升级坑预警，帮你想清楚要不要做品牌、什么时候做。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「品牌出海路线图Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
