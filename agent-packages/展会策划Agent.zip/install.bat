@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「展会策划Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\exhibition-planner"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"exhibition-planner\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"展会策划Agent\",\r\n  \"description\": \"外贸展会策划与客户管理全流程（展前/展中/展后）。选展评分矩阵（ROI预测）+展位设计6要素+预算分配公式（展位费/物料/差旅/邀约/跟进）+客户邀约模板（展前8周开始）+展中5分钟快速判客SOP+名片分级（A/B/C/D四级）+展后黄金48h跟进序列+ROI计算模板+线上展会适配方案+12 sheet Excel。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「展会策划Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
