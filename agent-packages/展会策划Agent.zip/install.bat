@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「展会策划Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-10425E76-1B4CE7FD"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-10425E76-1B4CE7FD","name":"展会策划Agent","description":"外贸展会策划与客户管理全流程（展前/展中/展后）。选展评分矩阵（ROI预测）+展位设计6要素+预算分配公式（展位费/物料/差旅/邀约/跟进）+客户邀约模板（展前8周开始）+展中5分钟快速判客SOP+名片分级（A/B/C/D四级）+展后黄金48h跟进序列+ROI计算模板+线上展会适配方案+12 she"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「展会策划Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
