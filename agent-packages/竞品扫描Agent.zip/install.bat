@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「竞品扫描Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-DFE3021C-BB817D26"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-DFE3021C-BB817D26","name":"竞品扫描Agent","description":"外贸竞品扫描矩阵（三栈并行深度版）。三栈扫描（阿里国际站+Amazon+独立站D2C）30个竞品：竞品矩阵（定位/价格/卖点/差评/流量/护城河）+头部/腰部/长尾分层+差评聚类（产品改进方向）+反向定位机会+12 sheet Excel，找到竞品的真实弱点和你的差异化切入点。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「竞品扫描Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
