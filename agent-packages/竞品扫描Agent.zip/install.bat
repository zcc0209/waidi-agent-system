@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「竞品扫描Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-DFE3021C-BB817D26"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-DFE3021C-BB817D26","name":"竞品扫描Agent","description":"外贸竞品扫描矩阵（三栈并行深度版）。三栈扫描（阿里国际站+Amazon+独立站D2C）30个竞品：竞品矩阵（定位/价格/卖点/差评/流量/护城河）+头部/腰部/长尾分层+差评聚类（产品改进方向）+反向定位机会+12 sheet Excel，找到竞品的真实弱点和你的差异化切入点。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「竞品扫描Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
