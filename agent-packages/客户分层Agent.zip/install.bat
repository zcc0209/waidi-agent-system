@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「客户分层Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-56ECD59D-B3D3A690"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-56ECD59D-B3D3A690","name":"客户分层Agent","description":"外贸客户四维分层体系（售后与复购地基）。RFM×战略价值×生命周期×利润贡献四维模型，输出钻石/黄金/白银/青铜/休眠/Kill六层客户金字塔+各层经营策略+资源分配公式+升降级预警，识别'高GMV低利润'的血汗客户，让业务员把时间花在对的人身上。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「客户分层Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
