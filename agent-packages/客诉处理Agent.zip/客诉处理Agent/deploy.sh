#!/bin/bash
# 部署脚本：客诉处理Agent
set -e
DEPLOY_SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GREEN='\033[0;32m'; BLUE='\033[0;34m'; NC='\033[0m'
log_info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[OK]${NC}   $1"; }

echo ""
echo "正在部署：客诉处理Agent"
echo "========================================"

ACCIO_BASE="$HOME/.accio/accounts"
ACCOUNT_ID=""
for dir in "$ACCIO_BASE"/*/; do
  d=$(basename "$dir")
  echo "$d" | grep -qE '^[0-9]+$' && ACCOUNT_ID="$d" && break
done
[ -z "$ACCOUNT_ID" ] && read -r -p "请输入Accio账户ID（纯数字）: " ACCOUNT_ID

AGENTS_DIR="$ACCIO_BASE/$ACCOUNT_ID/agents"
SIMOBIX_MAP="$ACCIO_BASE/$ACCOUNT_ID/simobix_map.json"
AGENT_ID="DID-D41CB43F-D07D1787"
AGENT_UUID="1c411ccf483c48e697324549b5db28f3"
SRC="$DEPLOY_SOURCE/agent"
DST="$AGENTS_DIR/$AGENT_ID"

log_info "账户：$ACCOUNT_ID"
log_info "目标：$DST"

[ -d "$DST" ] && rm -rf "$DST"
cp -r "$SRC" "$DST"

[ -f "$DST/profile.jsonc" ] && {
  sed -i '' "s|\"accountId\": \"[^\"]*\"|\"accountId\": \"$ACCOUNT_ID\"|g" "$DST/profile.jsonc" 2>/dev/null || true
  sed -i '' "s|\"dir\": \"[^\"]*\"|\"dir\": \"$DST/project\"|g" "$DST/profile.jsonc" 2>/dev/null || true
}

find "$DST" -name "skills.jsonc" | while read sf; do
  python3 -c "
import re
with open('$sf', encoding='utf-8', errors='replace') as f: c = f.read()
skill_dir = '$DST/agent-core/skills'
for e in re.findall(r'\"entryName\"\\s*:\\s*\"([^\"]+)\"', c):
    c = re.sub(r'(\"entryName\"\\s*:\\s*\"' + re.escape(e) + r'\".*?\"installPath\"\\s*:\\s*)\"[^\"]*\"',
        r'\\1\"' + skill_dir + '/' + e + '\"', c, flags=re.DOTALL)
with open('$sf', 'w', encoding='utf-8') as f: f.write(c)
" 2>/dev/null || true
done

python3 -c "
import json, os
f = '$SIMOBIX_MAP'
data = json.load(open(f)) if os.path.exists(f) else {}
data['$AGENT_ID'] = '$AGENT_UUID'
json.dump(data, open(f,'w'), indent=2, ensure_ascii=False)
" 2>/dev/null || true

log_success "部署完成：客诉处理Agent"
echo ""
echo "请重启 Accio 客户端后即可使用「客诉处理Agent」"
echo "========================================"
