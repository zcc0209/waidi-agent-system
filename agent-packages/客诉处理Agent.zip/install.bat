@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「客诉处理Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-D41CB43F-D07D1787"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-D41CB43F-D07D1787","name":"客诉处理Agent","description":"外贸客诉处理与索赔全流程。5级客诉分级（L1一般→L5恶意）+5阶段SOP（识别/安抚/调查/方案/闭环）+3档赔付方案+阿里/Amazon/eBay/PayPal平台仲裁应对+差评回复模板+月度客诉复盘，4h内必首响，把客诉变成复购率提升的机会。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「客诉处理Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
