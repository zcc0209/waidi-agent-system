---
name: customer-complaint-handler
description: 外贸客诉处理与索赔智能体。当用户要求"客诉/投诉/索赔/质量问题/破损/少件/差评/客户生气/dispute/claim/差评回复/差评删除/平台仲裁"时触发，输出客诉分级（一般/严重/致命）+ 5 阶段处理 SOP（识别/安抚/调查/方案/闭环）+ 差异化回复话术（按客户层级与客诉严重度）+ 赔付方案 3 档 + 平台仲裁应对（阿里/Amazon/eBay）+ 差评回复模板 + 内部复盘与预防机制。
version: 1.0.0
---

# 客诉处理 Agent

## 触发场景
- 客户邮件/微信发来"product is broken/wrong/missing"
- 阿里国际站收到差评
- Amazon 收到 1-3 星 review 或 A-to-Z claim
- 客户威胁要 chargeback / dispute / 找律师
- 客户要求全额退款 / 部分退款 / 重发 / 折扣
- 业务员处理不了，老板要介入
- 月度客诉复盘，要找共性问题

## 输入

必需：
- 客户信息（公司名 / 国家 / 客户层级 D/G/S/B 见 customer-tier-segmentation）
- 订单信息（订单号 / 金额 / 出运日 / 产品）
- 客诉内容（邮件原文 / 截图 / 视频）
- 客户态度（理性反馈 / 愤怒 / 威胁 / 沉默施压）

可选：
- 客户原始诉求（退款 / 重发 / 折扣 / 其他）
- 历史客诉记录（这是第几次）
- 平台介入情况（阿里 / Amazon / eBay 已介入）
- 我方过失程度（100% 我方 / 50/50 / 客户使用问题 / 物流问题）

## 客诉分级（5 级）

| 级别 | 标志 | 响应时限 | 处理人 |
|---|---|---|---|
| L1 一般 | 单价小问题、轻微划痕、文档错误 | 24h | 业务员 |
| L2 中等 | 数量短少、规格偏差、轻微质量 | 12h | 业务员 + 主管 |
| L3 严重 | 大批量质量、关键功能、晚到延误 | 4h | 主管 + 老板 |
| L4 致命 | 安全事故、人员伤亡、法律风险、平台 A-to-Z claim、媒体曝光 | 1h + 老板亲自 | 老板 + 法务 |
| L5 恶意 | 客户欺诈、虚假索赔、敲诈 | 24h | 老板 + 法务 |

**L4 致命客诉**触发应急预案：所有发货暂停、所有产品复检、客户优先安抚、保险介入。

## 5 阶段处理 SOP

### 阶段 1: 识别（0-1h）

接收客诉 → 自动分级 → 分配处理人。

```
═══ 客诉分级判定 ═══
关键词扫描：
- "broken" "damaged" "leaking" "smoke" → L3+
- "fire" "injury" "lawyer" "lawsuit" "FDA" "EU recall" → L4
- "dispute" "chargeback" "A-to-Z" "PayPal claim" → L4
- "missing" "wrong" "size" "color" → L2
- "scratch" "minor" "small" "tiny" → L1
- "fraud" "fake claim" 多次重复同样问题→ L5

客户层级权重：
- 钻石 D 客诉 → 自动升一级（D 客户的小问题也要严肃处理）
- Kill K 客诉 → 自动降一级 / 不响应威胁
═══════════════
```

### 阶段 2: 安抚（1-4h，不解决也要先回）

**铁律：先回信，再调查**。哪怕没结论，也要在第一时间表态。

按客户层级 × 客诉级别给差异化模板：

```
═══ L3 客诉 / 黄金客户 ═══

Hi [Name],

I'm sorry to hear this — that's clearly not what we promised, 
and I take it personally.

Here's what I'm doing right now:
1. Pulling your order [No.] file and the QC report from that batch
2. Asking the production team to investigate by [date]
3. Our [Senior Manager Name] is now CC'd to escalate this

I'll have a full answer for you in 48 hours, including what 
went wrong, how we'll fix it, and how we make sure it doesn't 
happen again.

Could you send 2-3 photos of the affected units (different angles + 
batch label if visible)? That speeds up the investigation.

Sorry again — and thank you for telling me directly instead of 
going to the platform. We'll make this right.

[Sales Name]
═══════════════
```

**安抚话术 5 原则**：
1. **不甩锅**：不说"this is your fault" / "logistics company's problem"
2. **不空头承诺**：先承认问题，再说调查，不要立刻承诺退款（可能演变成索赔陷阱）
3. **给时间表**：48h 内回 vs "我们会尽快处理"
4. **CC 上级**：让客户感觉被重视
5. **要证据**：3 张图 + 批号（既调查需要，也防欺诈）

### 阶段 3: 调查（4-48h）

内部启动调查：
- 调取订单档案（PI / 合同 / 报关单）
- 调取 QC 报告（出厂检验记录）
- 与生产线/采购对账
- 与物流公司对账（如运输破损）
- 复看客户提供的证据
- 必要时第三方介入（SGS 复检 / 保险公司勘察）

输出"过失分析"：
- 100% 我方过失（产品质量 / 漏发 / 错发）
- 50/50（产品有缺陷 + 客户使用不当）
- 100% 物流方过失 → 走运输险
- 100% 客户问题（误用 / 不符合预期）
- 100% 客户欺诈（虚假索赔）

### 阶段 4: 方案（3 档）

```
═══ 客诉解决方案 3 档 ═══
客户：Bauhaus Trade（黄金客户）
订单：$12,500，2000 pcs LED灯，到货后 50 pcs 不亮（2.5%）
调查结果：批次性焊点问题，我方 100% 过失

方案 A: 退款 + 不再合作风险
- 退款 50 pcs × $6.25 = $312.5
- 客户拿到钱可能转单他厂
- 适合：Kill 客户 / 极度愤怒不接受其他

方案 B: 重发 + 维持关系（推荐）
- 免费重发 50 pcs（成本约 $200）+ 下单优惠 5% × 下次订单
- 客户不亏 + 我方留客
- 时长：5 天空运
- 适合：黄金/白银客户

方案 C: 折扣 + 加量补偿
- 直接折扣 $250（≈2%）+ 下次订单加量 100 pcs 免费
- 锁定客户复购
- 适合：钻石客户长期价值

═══ 推荐：方案 B ═══
理由：黄金客户 + 我方过失 + 重发显诚意
═══════════════
```

**赔付额度参考**（按客户层级）：

| 层级 | 单次赔付上限 | 备注 |
|---|---|---|
| 钻石 D | 订单金额 50% | 老板审批 |
| 黄金 G | 订单金额 30% | 主管审批 |
| 白银 S | 订单金额 15% | 业务员主审 |
| 青铜 B | 订单金额 10% | 业务员处理 |
| Kill K | 不赔 / 走仲裁 | — |

**额外补偿可选**：
- 折扣码（下次订单 5-10%）
- 免费样品
- 优先发货权
- 延保（从 1 年到 2 年）

### 阶段 5: 闭环（1-2 周）

- 客户确认方案 → 执行
- 跟进客户收到/满意度
- 内部归档：原因 / 损失 / 教训
- 工厂端整改（生产 SOP 修订 / 来料检验加严）
- 客户层级评估（这次客诉是否影响层级？）

## 平台仲裁应对（阿里 / Amazon / eBay）

### 阿里国际站交易纠纷

- 收到通知 → 24h 内提交应诉材料
- 提供：合同 / PI / 物流凭证 / QC 报告 / 沟通记录
- 重点：客户已确认收货 vs 未收货、是否质量问题、是否第三方破损
- 仲裁周期：7-15 天
- 防御要点：聊天记录中"已发货 / 已收到 / 满意"等截图

### Amazon A-to-Z Claim

- 24h 必须回复 buyer message
- 30 天内提交 evidence pack
- 优先与 buyer 私下解决（解决后 buyer 撤销 claim）
- Amazon 70% 倾向支持 buyer，必须证据充分

### eBay Dispute

- INR (Item Not Received): 提供 tracking + signed delivery
- INAD (Not As Described): 提供 listing 详情 + 客户使用问题证据

### PayPal Dispute

- 20 天内回复
- 提供 tracking + signed delivery + 沟通记录
- PayPal 卖家保护要求"signed signature confirmation"（签收）

## 差评回复模板（公开可见）

```
═══ Amazon 1-3 星差评回复 ═══

Hi [Customer],

Thank you for your honest feedback — and I'm sorry your experience 
didn't meet expectations.

[Specific acknowledgment of the issue, NOT generic apology]

We've already [specific action taken]. I've sent you a private 
message with [solution] and would love the chance to make this right.

For other readers: this is not the standard we hold ourselves to. 
If you experience any issue with our products, please email us at 
[email] and we'll respond within 24 hours.

— [Brand Name] Customer Service
═══════════════
```

**差评回复 5 原则**：
1. 不与客户公开吵架
2. 承认具体问题（不是"sorry for any inconvenience"模板腔）
3. 私下解决（公开层面留 50% 关于其他读者）
4. 说明已采取的具体行动
5. 不要求客户改评（可能违反平台政策）

## 月度客诉复盘

```
═══ 月度客诉看板 ═══
本月客诉：14 单
- L1: 8（57%）
- L2: 4（29%）
- L3: 2（14%）
- L4-5: 0

按产品：
- LED 灯系列 9 单（焊点问题反复）→ 必须工厂整改
- 包装盒 3 单（运输破损）→ 加强外箱+换 EPE 内衬
- 文档 2 单（说明书翻译错）→ 翻译复核流程

按国家：
- 美国 5 单（标准严，对包装敏感）
- 德国 3 单（细节挑剔，色差敏感）

赔付总额：$1,850（订单总额 0.4%，行业平均 0.5-1%）
平均处理时长：38h（KPI 48h 内）
满意度：12/14 客诉客户继续合作（86% 留存）
═══════════════
```

## 输出 Excel 客诉处理报告

**Sheet 1: 客诉分级（L1-L5）+ 响应时限标准**
**Sheet 2: 当前进行中客诉**（按级别+剩余响应时间排序）
**Sheet 3: 安抚话术库**（按客户层级 × 客诉级别 25 套）
**Sheet 4: 调查清单**（材料 / 责任方判定）
**Sheet 5: 解决方案 3 档**（含赔付额度按层级）
**Sheet 6: 平台仲裁应对指南**（阿里 / Amazon / eBay / PayPal）
**Sheet 7: 差评回复模板**（按平台+星级）
**Sheet 8: 月度客诉看板**（产品 / 国家 / 赔付额 / 满意度）
**Sheet 9: 共性问题诊断**（产品端 / 物流端 / 沟通端）
**Sheet 10: 内部整改清单**（生产 SOP / 来料 / 包装 / 翻译）
**Sheet 11: 诚实提醒**（哪些客诉处理得太软 / 哪些太硬 / 哪个产品线必须整改）

## 注意事项

- **先回再查**：4h 内必有响应（哪怕只是"已收到，正在调查"）
- **不要立刻承诺退款**：可能引发更多索赔，先调查清楚
- **要图要批号**：3 张图 + 批号 = 调查证据 + 反欺诈
- **客户层级是过滤器**：钻石客诉自动升级，Kill 客诉冷处理（甚至不响应威胁）
- **不甩锅给物流**：哪怕真是物流责任，对客户也要"我们已联系物流并跟进"，不能"是物流的问题，找他们去"
- **L4 客诉立即升级**：人员伤亡 / 法律风险 / 平台介入 / 媒体曝光 → 老板 + 法务介入
- **欺诈索赔不退让**：同一客户 30 天内 3 次同样问题、要求高于订单的赔付、提供不出证据 → 标 L5，必要时反诉
- **去 AI 化**：报告不要"建议加强客户关系管理"，要"LED 焊点问题 9 单/月，工厂今天必须召开整改会，否则 7 月停发"
- **客诉是金矿**：50% 的客诉可以变成产品改进 + 客户更忠诚（处理得好的客诉客户复购率高于无客诉客户）
- **保留所有证据**：聊天记录截图 / 邮件 / QC 报告 / 物流签收单——平台仲裁全靠这些
- **赔付预算化**：年度赔付预算 = 总营收 0.5-1%，超过红线必须老板介入

## 验证

- 客诉是否在 1h 内分级（不是慢慢分析）
- 安抚邮件是否在 4h 内发出（不是等调查完才回）
- 解决方案是否给 3 档（不是只推一个）
- 赔付额度是否按客户层级（不是一刀切）
- 平台仲裁是否覆盖 4 大平台（阿里/Amazon/eBay/PayPal）
- 月度复盘是否找出"共性问题"（不只是统计数字）
- 是否有内部整改清单（不止处理客户，还要修流程）
- 欺诈识别是否有标准（不是无脑赔付）
