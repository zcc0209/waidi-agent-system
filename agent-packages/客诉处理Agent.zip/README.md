# 客诉处理Agent

外贸客诉处理与索赔全流程。5级客诉分级（L1一般→L5恶意）+5阶段SOP（识别/安抚/调查/方案/闭环）+3档赔付方案+阿里/Amazon/eBay/PayPal平台仲裁应对+差评回复模板+月度客诉复盘，4h内必首响，把客诉变成复购率提升的机会。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
