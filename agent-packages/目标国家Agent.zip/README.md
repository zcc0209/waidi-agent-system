# 目标国家Agent

外贸目标国家市场矩阵（深度版）。30国全景打分（10维100分制）+Top 10进入排序+不进入清单（Kill List）+买家结构+合规门槛+价格带+渠道偏好+3档进入方案+12 sheet Excel，明确告诉你先打哪个国家、为什么、怎么打，以及哪些国家现阶段不要碰。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
