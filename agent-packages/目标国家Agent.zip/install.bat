@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「目标国家Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-7C14389C-532D6B30"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-7C14389C-532D6B30","name":"目标国家Agent","description":"外贸目标国家市场矩阵（深度版）。30国全景打分（10维100分制）+Top 10进入排序+不进入清单（Kill List）+买家结构+合规门槛+价格带+渠道偏好+3档进入方案+12 sheet Excel，明确告诉你先打哪个国家、为什么、怎么打，以及哪些国家现阶段不要碰。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「目标国家Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
