@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「目标国家Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-7C14389C-532D6B30"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-7C14389C-532D6B30","name":"目标国家Agent","description":"外贸目标国家市场矩阵（深度版）。30国全景打分（10维100分制）+Top 10进入排序+不进入清单（Kill List）+买家结构+合规门槛+价格带+渠道偏好+3档进入方案+12 sheet Excel，明确告诉你先打哪个国家、为什么、怎么打，以及哪些国家现阶段不要碰。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「目标国家Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
