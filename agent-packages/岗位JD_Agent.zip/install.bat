@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「岗位JD Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\role-job-description"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"role-job-description\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"岗位JD Agent\",\r\n  \"description\": \"外贸岗位JD与能力模型。覆盖12大外贸岗位×4层级（专员/主管/经理/总监）标准JD七大模块（任职资格/职责/能力模型/薪酬带宽/KPI/发展路径/面试题），薪酬带宽透明（P25/P50/P75分位），输出招聘画像直接送BOSS直聘招聘Agent使用。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「岗位JD Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
