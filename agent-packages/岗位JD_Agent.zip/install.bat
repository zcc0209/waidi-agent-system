@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「岗位JD Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-76EB8806-4E2F9431"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-76EB8806-4E2F9431","name":"岗位JD Agent","description":"外贸岗位JD与能力模型。覆盖12大外贸岗位×4层级（专员/主管/经理/总监）标准JD七大模块（任职资格/职责/能力模型/薪酬带宽/KPI/发展路径/面试题），薪酬带宽透明（P25/P50/P75分位），输出招聘画像直接送BOSS直聘招聘Agent使用。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「岗位JD Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
