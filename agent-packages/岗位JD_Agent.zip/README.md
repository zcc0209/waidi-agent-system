# 岗位JD Agent

外贸岗位JD与能力模型。覆盖12大外贸岗位×4层级（专员/主管/经理/总监）标准JD七大模块（任职资格/职责/能力模型/薪酬带宽/KPI/发展路径/面试题），薪酬带宽透明（P25/P50/P75分位），输出招聘画像直接送BOSS直聘招聘Agent使用。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
