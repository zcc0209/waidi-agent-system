# 趋势选品Agent

外贸趋势选品（反推潜力品）。5大渠道反推：TikTok热销+Amazon BSR/Movers&Shakers+Google Trends 5年图+阿里国际站热搜+社媒爆款；输出30候选品打分矩阵+潜力指数公式+生命周期阶段判断（萌芽/成长/成熟/衰退）+进入窗口期+Kill List（已过红利期品类）+3档方案+12 sheet Excel。

分类：选品找货
创建时间：2026-06-17

## 使用方法
1. 在 Accio Work 中新建智能体
2. 将本包内的 SOUL.md 内容粘贴为智能体的 System Prompt
3. 安装 skills/ 目录下的技能包
