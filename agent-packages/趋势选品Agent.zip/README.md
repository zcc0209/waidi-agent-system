# 趋势选品Agent

外贸趋势选品（反推潜力品）。5大渠道反推：TikTok热销+Amazon BSR/Movers&Shakers+Google Trends 5年图+阿里国际站热搜+社媒爆款；输出30候选品打分矩阵+潜力指数公式+生命周期阶段判断（萌芽/成长/成熟/衰退）+进入窗口期+Kill List（已过红利期品类）+3档方案+12 sheet Excel。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
