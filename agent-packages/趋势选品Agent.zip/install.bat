@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「趋势选品Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-F9B4B2E0-6E83DC8C"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-F9B4B2E0-6E83DC8C`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"趋势选品Agent`",`r`n  `"description`": `"外贸趋势选品（反推潜力品）。5大渠道反推：TikTok热销+Amazon BSR/Movers&Shakers+Google Trends 5年图+阿里国际站热搜+社媒爆款；输出30候选品打分矩阵+潜力指数公式+生命周期阶段判断（萌芽/成长/成熟/衰退）+进入窗口期+Kill List（已过红利期品类）+3档方案+12 sheet Excel。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「趋势选品Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
