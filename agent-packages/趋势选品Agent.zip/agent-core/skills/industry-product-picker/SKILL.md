---
name: industry-product-picker
displayName: 行业选品分析 Agent（含图Excel输出）
description: >
  海外行业选品月报智能体。输入任意行业关键词（如"室内游乐设备""宠物用品""厨房电器"），
  自动从5大数据源并行采集，输出含产品主图+真实市场数据支撑的Excel选品报告。
  触发词："选品分析/帮我选品/行业选品/月度选品/XX行业有什么好卖的/海外爆款分析/给我出一份选品报告"。
version: 1.0.0
---

# 行业选品分析 Agent

## 一、触发识别

当用户说：
- "帮我分析 [行业] 的选品"
- "[行业] 有哪些好卖的品"
- "给我出一份 [行业] 选品报告"
- "月度选品推送 / 定时选品"
- "海外 [行业] 爆款"
- 或直接输入一个行业名称 + "选品/热销/潜力品/分析"

→ **立即进入本技能流程，不要先向用户确认，直接开始执行。**

## 二、输入解析

从用户消息中提取：

```
INDUSTRY_CN  = 行业中文名（如"室内游乐设备"）
INDUSTRY_EN  = 行业英文关键词（如"indoor playground equipment"）
MARKET       = 目标市场（未指定默认"全球，重点美/欧/中东"）
OUTPUT_DIR   = 输出目录（默认 workspace 根目录）
REPORT_MONTH = 报告月份（默认当前年月，如"2026年7月"）
```

若用户未明确给出英文关键词，由 Agent 自行翻译推断。

## 三、执行 SOP（严格按步骤顺序）

### Step 1 — 5大数据源并行采集（全部同时发起）

同时执行以下5组 web_search，不要串行等待：

```
搜索1: "[INDUSTRY_EN] Amazon best seller BSR 2025 2026 trending monthly sales"
搜索2: "[INDUSTRY_EN] market size growth CAGR 2025 2026 statistics revenue report"
搜索3: "[INDUSTRY_EN] alibaba international buyer inquiry hot search 2025 export data"
搜索4: "[INDUSTRY_EN] TikTok viral trending hashtag views 2025 popular products"
搜索5: "[INDUSTRY_EN] Google Trends new emerging products 2026 rising demand"
```

同时再补充：
```
搜索6: "site:alibaba.com [INDUSTRY_EN] hot selling 2025 popular products"
product_supplier_search: "[INDUSTRY_EN]" (intent=product, 抓取前30个产品)
product_supplier_search: "[INDUSTRY_EN] new design 2025 2026" (intent=product)
product_supplier_search: "[INDUSTRY_EN] trending innovative" (intent=product)
```

### Step 2 — 整理候选品清单

从搜索结果 + product_supplier_search 结果中整理：
- **热销品（需求量大）**：目标 ≥30 个，优先选阿里国际站有链接的产品
- **潜力新品（萌芽/增长早期）**：目标 ≥20 个
- 两类合计 **≥50 个**，不足则再补充搜索

每个产品记录：
```
序号 | 产品名称 | 图片URL | 产品链接 | 价格区间 | 推荐理由(含真实数据) | 关键词 | 生命周期 | 潜力指数 | 类别
```

### Step 3 — 潜力指数打分（每品必须打分）

```
潜力指数(0-10) = 趋势分×30% + 市场分×25% + 竞争分×20% + 供应链分×15% + 利润分×10%
```

评级：
- 🔥 9.0–10.0：A级，立即跟进
- ⭐ 8.5–8.9：B+级，强烈推荐
- ✅ 8.0–8.4：B级，建议跟进
- 🟡 7.5–7.9：C级，可选
- 🔴 <7.5：Kill List，排除

### Step 4 — 下载产品图片

对所有入选产品，用 `urllib.request` 下载图片到本地 `img_cache/` 目录，失败则留空单元格。

### Step 5 — 生成 Excel（含嵌入图片）

调用 Python (openpyxl) 生成 Excel，严格包含以下 Sheet：

#### Sheet1：🔥热销品（需求量/销售量大）
表头：序号 | 产品主图(嵌入图) | 产品名称 | 产品链接 | 销售价格 | 推荐理由（真实数据支撑） | 相关关键词 | 生命周期阶段 | 潜力指数 | 产品类别

#### Sheet2：⭐潜力新品（未来爆发）
同表头

#### Sheet3：📋数据说明
- 核心数据来源列表（机构名+数据摘要）
- 潜力指数公式说明
- Kill List 及排除理由
- 免责声明

**Excel 样式要求：**
- CJK字体：Microsoft YaHei（不能用Calibri）
- 行高：100px（留给嵌入图）
- 图片列宽：18（Excel单位）
- 产品名加粗，链接蓝色带下划线，价格红色加粗
- 生命周期用色块区分：萌芽期绿、增长期蓝、成熟期黄、衰退期红
- 潜力指数 ≥9.0 深绿底，8.5–8.9 蓝底，其余黄底
- 隔行浅色填充，冻结第3行（表头行）

**文件命名：** `{INDUSTRY_CN}_{REPORT_MONTH}海外选品分析.xlsx`

### Step 6 — 输出总结

在对话中输出：
1. 文件路径链接
2. 核心发现摘要（3–5条，含数据）：
   - 本月最热销品类 Top3（含潜力指数+关键数据点）
   - 最值得进入的潜力新品 Top3（含窗口期判断）
   - Kill List 重点排除项（含原因）

## 四、推荐理由写作规范（最重要）

❌ 禁止写泛泛描述，如：
> "市场需求旺盛，买家反馈良好"

✅ 必须包含至少2条真实数据，格式：
```
📊 [数据类型]：[具体数字/百分比/来源机构+年份]
📱 [社媒信号]：[平台+具体播放量/搜索量+时间]
🏭 [供应链]：[厂龄+具体能力指标]
💰 [利润/回报]：[具体ROI数字或价格区间]
🌍 [市场/地区]：[买家国家+YoY增长率来源]
🔐 [认证/壁垒]：[具体认证标准+适用市场]
```

数据来源优先级：
1. Alibaba.com官方平台数据（买家询盘量、YoY增长）
2. 第三方权威机构（Grand View Research / DataIntelo / IBISWorld / Mordor Intelligence 等）
3. Amazon BSR/月销数据（asinsight.com / Jungle Scout）
4. Google Trends 具体指数（满分100，给出实际数值）
5. TikTok/Instagram 具体播放量/话题帖子数

## 五、Kill List 判断标准

以下情况直接排除，不进入候选：
- Google Trends 5年下行通道
- Amazon Basics 已入场（大平台入场=利润终结）
- 物流成本占售价 >40%（大件+低客单）
- 强制认证费用 >$50K（中小卖家负担不起）
- 专利保护核心SKU（除非可绕过设计）
- TikTok爆品已超8周且10+卖家在做
- UFLPA涉疆原料（美国100%扣货风险）

## 六、月度自动推送模式

当从定时任务触发时（消息包含"月度自动推送"或"定时触发"字样），行业关键词从任务配置中读取，无需用户输入，直接执行 Step1→Step6 完整流程后输出报告。

## 七、质量验收标准

完成后自检以下各项，不达标则补充：
- [ ] 热销品 ≥30 个，潜力新品 ≥20 个，合计 ≥50 个
- [ ] 每个产品有阿里国际站真实链接
- [ ] 每个推荐理由包含 ≥2 条真实数据（含来源机构/平台）
- [ ] 图片嵌入成功率 ≥85%
- [ ] Excel 三个 Sheet 均有内容
- [ ] 生命周期阶段均已标注
- [ ] 潜力指数均已打分（0–10）
- [ ] Kill List 明确列出排除品类及原因

## 八、诚实提醒（定时推送时附在报告末尾）

```
⚠️ 数据局限说明：
1. 平台询盘数据存在 ±15% 采样误差
2. Amazon BSR 月销估算误差 ±50%（Helium10/JungleScout 均为采样）
3. 趋势窗口判断具有不确定性，最终决策需结合自身供应链能力
4. 本报告仅供参考，不构成投资建议
5. 生命周期判断可能因市场事件快速变化，请每月复核
```
