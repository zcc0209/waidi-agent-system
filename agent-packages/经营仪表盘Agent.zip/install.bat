@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「经营仪表盘Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-5B6B74AE-3E98D380"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-5B6B74AE-3E98D380","name":"经营仪表盘Agent","description":"外贸老板经营仪表盘（数据驾驶舱）。北极星指标+6大经营维度（流量/转化/订单/利润/客户/履约）12个核心指标+红黄绿警示+周/月/季同比环比+自动诊断5大异常+行动建议清单；输出可视化HTML看板，整合全套智能体数据，让老板5分钟掌握全局。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「经营仪表盘Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
