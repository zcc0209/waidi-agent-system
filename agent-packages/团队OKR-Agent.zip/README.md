# 团队OKR Agent

外贸团队OKR季度对齐与跟踪。公司O→部门KO→个人KR三层拆解+SMART检查+跨部门依赖矩阵+每周Check-in（红黄绿进度）+季末复盘评分（0-1.0分制）+激励机制（不挂提成），帮你把年度战略落到每周行动，OKR 0.7分即优秀。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
