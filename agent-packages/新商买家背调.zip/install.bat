@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo 安装「新商买家背调」...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\MID-NEWBIZ-S04-BUYER-RESEARCH"
    if not exist "!TARGET!" mkdir "!TARGET!"
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"MID-NEWBIZ-S04-BUYER-RESEARCH","name":"新商买家背调","description":"外贸新商买家背调智能体。通过深度分析买家背景、采购历史和公司实力，帮助外贸新手快速判断买家质量，制定针对性跟进策略。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「新商买家背调」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，找到左侧智能体
echo.
pause
