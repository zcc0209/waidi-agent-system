# 新商买家背调



**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
