# 新商买家背调

外贸新商买家背调，深度分析买家背景与采购意向，助力精准跟进。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
