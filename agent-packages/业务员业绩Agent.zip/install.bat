@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「业务员业绩Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\DID-6B5D80D6-C614373F"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "$c='// Accio Agent config`r`n{`r`n  `"id`": `"DID-6B5D80D6-C614373F`",`r`n  `"accountId`": `"!ACCT_ID!`",`r`n  `"name`": `"业务员业绩Agent`",`r`n  `"description`": `"外贸业务员业绩诊断与排行。6维度业绩+8段销售漏斗+4类业务员画像（猎手/农夫/守门员/僵尸）；输出GMV+净利双榜排行+漏斗瓶颈定位+个人诊断报告+提成方案优化+培训计划+末位淘汰建议，让奖罚有据可依，让管理层决策不靠感觉。`",`r`n  `"model`": {`"provider`": `"auto`", `"name`": `"auto`"},`r`n  `"runtime`": `"local`",`r`n  `"creator`": `"user`",`r`n  `"agentType`": `"general`",`r`n  `"createdAt`": `"2026-01-01T00:00:00.000Z`"`r`n}`r`n';Set-Content -Path '!PROF!' -Value $c -Encoding UTF8" 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「业务员业绩Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
