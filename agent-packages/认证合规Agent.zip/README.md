# 认证合规Agent

外贸产品认证合规（按目标国自动列清单）。5大市场30+认证标准矩阵（CE/FCC/RoHS/UL/FDA/REACH/UKCA/CB/DOT/Prop 65/CPC/CPSC等）；强制vs推荐分类+费用/时间/机构推荐+不合规罚款量化+取证SOP+认证日历（维护/续证提醒）+Kill线（认证成本超出预算的放弃方案）+12 sheet Excel。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
