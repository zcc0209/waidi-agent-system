@echo off
chcp 65001 >nul
echo 正在安装「认证合规Agent」...
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo 请先登录 Accio Work & pause & exit /b 1)
for /d %%i in ("%BASE%\*") do (set "ACCT=%%i" & goto :ok)
:ok
set "TARGET=%ACCT%\agents\DID-984B0756-476F9280"
if not exist "%TARGET%" mkdir "%TARGET%"
xcopy /E /I /Y "%~dp0agent-core" "%TARGET%\agent-core\" >nul
(echo {"id":"DID-984B0756-476F9280","name":"认证合规Agent","description":""}) > "%TARGET%\profile.jsonc"
echo.
echo [完成] 请退出并重启 Accio Work，在左侧找到智能体
pause
