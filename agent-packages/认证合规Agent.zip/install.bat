@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「认证合规Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-984B0756-476F9280"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-984B0756-476F9280","name":"认证合规Agent","description":"外贸产品认证合规（按目标国自动列清单）。5大市场30+认证标准矩阵（CE/FCC/RoHS/UL/FDA/REACH/UKCA/CB/DOT/Prop 65/CPC/CPSC等）；强制vs推荐分类+费用/时间/机构推荐+不合规罚款量化+取证SOP+认证日历（维护/续证提醒）+Kill线（认证成本超出"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「认证合规Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
