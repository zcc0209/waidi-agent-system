@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「认证合规Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\certification-compliance"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"certification-compliance\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"认证合规Agent\",\r\n  \"description\": \"外贸产品认证合规（按目标国自动列清单）。5大市场30+认证标准矩阵（CE/FCC/RoHS/UL/FDA/REACH/UKCA/CB/DOT/Prop 65/CPC/CPSC等）；强制vs推荐分类+费用/时间/机构推荐+不合规罚款量化+取证SOP+认证日历（维护/续证提醒）+Kill线（认证成本超出预算的放弃方案）+12 sheet Excel。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「认证合规Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
