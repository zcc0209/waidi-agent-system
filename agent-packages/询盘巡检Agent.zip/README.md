# 询盘巡检Agent

阿里国际站后台询盘全面巡检（v1.1）。登录阿里后台，7维度分析近期询盘：响应速度、回复质量、跟进密度、转化漏斗、丢单原因、团队共性问题、重要客户漏网，输出8-sheet Excel报告+业务员排行+诚实提醒。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
