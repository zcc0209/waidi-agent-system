@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「询盘巡检Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-C0EABD5B-AA1784D4"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-C0EABD5B-AA1784D4","name":"询盘巡检Agent","description":"阿里国际站后台询盘全面巡检（v1.1）。登录阿里后台，7维度分析近期询盘：响应速度、回复质量、跟进密度、转化漏斗、丢单原因、团队共性问题、重要客户漏网，输出8-sheet Excel报告+业务员排行+诚实提醒。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「询盘巡检Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
