@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「询盘巡检Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-C0EABD5B-AA1784D4"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-C0EABD5B-AA1784D4","name":"询盘巡检Agent","description":"阿里国际站后台询盘全面巡检（v1.1）。登录阿里后台，7维度分析近期询盘：响应速度、回复质量、跟进密度、转化漏斗、丢单原因、团队共性问题、重要客户漏网，输出8-sheet Excel报告+业务员排行+诚实提醒。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「询盘巡检Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
