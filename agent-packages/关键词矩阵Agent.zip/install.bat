@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「关键词矩阵Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\keyword-matrix"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"keyword-matrix\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"关键词矩阵Agent\",\r\n  \"description\": \"外贸关键词三梯队矩阵（问鼎/明星/长尾深度版）。3梯队×3平台（阿里/Amazon/Google）关键词池：问鼎词5-8个（搜索量最高）+明星词15-20个（转化最佳）+长尾词30-50个（精准收割）；出价区间+预算分配公式+季节波动日历+国别化关键词变体+竞品关键词反查+12 sheet Excel。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「关键词矩阵Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
