@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo 安装「关键词矩阵Agent」...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-99298CFD-837334B4"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-99298CFD-837334B4","name":"关键词矩阵Agent","description":"外贸关键词三梯队矩阵（问鼎/明星/长尾深度版）。3梯队×3平台（阿里/Amazon/Google）关键词池：问鼎词5-8个（搜索量最高）+明星词15-20个（转化最佳）+长尾词30-50个（精准收割）；出价区间+预算分配公式+季节波动日历+国别化关键词变体+竞品关键词反查+12 sheet Excel。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「关键词矩阵Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开
echo.
pause
