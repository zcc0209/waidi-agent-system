@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「关键词矩阵Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-99298CFD-837334B4"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-99298CFD-837334B4","name":"关键词矩阵Agent","description":"外贸关键词三梯队矩阵（问鼎/明星/长尾深度版）。3梯队×3平台（阿里/Amazon/Google）关键词池：问鼎词5-8个（搜索量最高）+明星词15-20个（转化最佳）+长尾词30-50个（精准收割）；出价区间+预算分配公式+季节波动日历+国别化关键词变体+竞品关键词反查+12 sheet Exce"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「关键词矩阵Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
