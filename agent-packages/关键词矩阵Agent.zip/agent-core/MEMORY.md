# 记忆
> `diary/...` 在日记来源中为 `agent-core/diary/` 下的本地文件路径，非 URL；请勿通过 HTTP 获取。
## 日记来源
- 2026-06-27：完成气调包装机阿里国际站关键词分析与 PPC 投放策略制定。 [diary/2026-06-27.md](diary/2026-06-27.md)

## 🪪 个人信息
- (none recorded)

## 🌿 个人习惯与偏好
- **电商运营策略**：倾向于使用“顶级展位底价×1.3-1.5”和“明星词底价×0.8-1.1”的出价策略进行 PPC 广告投放。
- **选词偏好**：在阿里国际站推广中，注重区分高竞争核心大词（如 `modified atmosphere packaging machine`）与高 ROI 精准长尾词（如 `automatic MAP tray sealer`）。

## 👥 人物与宠物
- (none recorded)

## 📈 财经与新闻兴趣
- **B2B 跨境电商**：关注阿里国际站（Alibaba.com）的流量获取、关键词矩阵构建及付费推广（PPC）优化。
