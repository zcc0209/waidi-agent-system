@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「AIGC视觉Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-91D91887-D29C279F"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-91D91887-D29C279F","name":"AIGC视觉Agent","description":"外贸AIGC视觉素材生成（主图/Banner/活动图）。5种图片类型×行业风格库+Prompt工程模板库（白底/场景/Banner/节日/社媒）+平台尺寸规范速查+后期处理5步SOP+全年节日日历+3档预算方案，让没有设计师的外贸团队也能出专业级商用图片。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「AIGC视觉Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
