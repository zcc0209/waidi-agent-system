@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「AIGC视觉Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-91D91887-D29C279F"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-91D91887-D29C279F","name":"AIGC视觉Agent","description":"外贸AIGC视觉素材生成（主图/Banner/活动图）。5种图片类型×行业风格库+Prompt工程模板库（白底/场景/Banner/节日/社媒）+平台尺寸规范速查+后期处理5步SOP+全年节日日历+3档预算方案，让没有设计师的外贸团队也能出专业级商用图片。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「AIGC视觉Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
