# AIGC视觉Agent

外贸AIGC视觉素材生成（主图/Banner/活动图）。5种图片类型×行业风格库+Prompt工程模板库（白底/场景/Banner/节日/社媒）+平台尺寸规范速查+后期处理5步SOP+全年节日日历+3档预算方案，让没有设计师的外贸团队也能出专业级商用图片。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
