---
name: aigc-visual-creator
description: 外贸 AIGC 视觉素材智能体（主图/Banner/活动图）。当用户要求"AIGC 主图/AI 生图/Banner 设计/节日活动图/产品主图/首页 Banner/活动海报/AI 作图/Midjourney/DALL-E/主图生成/图片生成/白底图/场景图/促销图/产品渲染"时触发，输出 5 种图片类型（白底主图/场景图/Banner/活动图/社媒图）× 行业风格库 + Prompt 工程模板 + 平台尺寸规范 + 后期处理 SOP + 12 sheet Excel + 诚实提醒。
version: 1.0.0
---

# 外贸 AIGC 视觉素材智能体

> 一句话定位：用 AI 生图工具快速产出外贸级商用视觉素材——从白底主图到节日 Banner，给 Prompt、给规范、给后期流程，让没有设计师的外贸团队也能出专业级图片。

---

## 触发场景

- "帮我用 AI 生成产品主图"
- "做一张黑五 Banner"
- "圣诞节活动图怎么做"
- "我没有设计师，产品图怎么搞"
- "Midjourney 怎么写 Prompt 出外贸图"
- "帮我做个阿里国际站首页 Banner"
- "场景图用 AI 能做吗"

---

## 输入要求

| 项目 | 必须 | 示例 |
|---|---|---|
| 产品图（白底原图） | ✅ | 手机拍的白底图/抠图后的 PNG |
| 图片用途 | ✅ | 主图/Banner/活动图/社媒 |
| 目标平台 | ✅ | 阿里/Amazon/独立站/TikTok |
| 目标市场 | ✅ | 美国/欧洲/中东 |
| 品牌色/视觉风格 | - | 科技蓝+白/暖木色 |
| 行业品类 | ✅ | 消费电子/家居/服装 |
| 文案需求 | - | Banner 上要放什么文字 |

---

## 工作流

### Phase 1：图片类型 × 用途定位

```
5 种外贸商用图片类型：

1. 白底主图（Product White Background）
   用途：搜索结果展示/阿里主图/Amazon 主图
   要求：纯白底 #FFFFFF、产品占 85%、无文字水印
   AI 用法：产品抠图 + 背景替换白色 + 阴影

2. 场景图（Lifestyle/In-situ）
   用途：Listing 第 2-3 张图/详情页/社媒
   要求：产品在真实使用场景中
   AI 用法：用 AI 生成场景，嵌入产品（Photoshop+AI 混合）

3. Banner 首页图（Hero Banner）
   用途：店铺首页/活动页/独立站
   要求：品牌色+口号+CTA+产品
   AI 用法：AI 生成背景+人工排版文字+产品

4. 节日活动图（Campaign/Holiday）
   用途：黑五/圣诞/斋月/双 11/展会
   要求：节日氛围+促销信息+产品
   AI 用法：AI 生成节日场景+叠加促销元素

5. 社媒图（Social Media Visual）
   用途：Instagram/TikTok 封面/LinkedIn 帖图
   要求：抓眼球+信息密度高+品牌一致
   AI 用法：AI 生成创意背景+产品+文案
```

### Phase 2：AIGC 工具选择矩阵

```
主流 AI 图片生成工具对比（2026 年）：

| 工具 | 适合场景 | 优点 | 缺点 | 价格 |
|---|---|---|---|---|
| Midjourney | 场景图/氛围图 | 美学最好 | 产品还原度低 | $10/月起 |
| DALL-E 3 | 概念图/Banner 背景 | 理解指令准 | 商用授权条件限制 | 按量付费 |
| Stable Diffusion | 批量生成/自训练 | 免费+可控 | 学习曲线陡 | 免费（需 GPU）|
| Adobe Firefly | 产品扩展/背景替换 | 商用安全+PS 集成 | 创意度一般 | Adobe 订阅 |
| QoderWork ImageGen | 快速出图 | 一句话生成 | 精细控制有限 | 含在 QoderWork |
| Canva AI | Banner/社媒图 | 模板丰富+易用 | AI 生成质量中等 | 免费/Pro |
| remove.bg | 抠图 | 一键抠图 | 只能抠图 | 免费有水印 |

推荐组合（按预算）：
├── ¥0 方案：QoderWork ImageGen + Canva 免费 + remove.bg
├── ¥100/月：Midjourney + Canva Pro + remove.bg
├── ¥500/月：Adobe Creative Cloud（PS+Firefly+LR）
└── 专业方案：SD WebUI 本地部署 + LoRA 训练
```

### Phase 3：Prompt 工程模板库

#### 白底产品图 Prompt

```
通用模板：
"Professional product photo of [产品名], pure white background (#FFFFFF), 
[材质/颜色] finish, studio lighting with soft shadows, 
shot at 3/4 angle from slightly above, 
high resolution, 8K, product photography, commercial quality, 
no text, no watermark, clean composition"

示例（LED Panel Light）：
"Professional product photo of a square LED panel light 600x600mm, 
pure white background, brushed aluminum frame silver finish, 
soft diffused lighting showing the slim profile, 
slight shadow underneath for depth, 
shot at 3/4 angle, product photography, 8K, commercial grade"

参数调整：
├── 角度：3/4 view / front view / top view / side profile
├── 光线：studio lighting / soft box / rim light / natural daylight
├── 材质：matte / glossy / brushed metal / frosted glass / fabric
├── 风格：minimalist / premium / industrial / lifestyle
└── 后缀：--ar 1:1 --s 750 --q 2（Midjourney 参数）
```

#### 场景图 Prompt

```
通用模板：
"[产品] in a [场景环境], [光线描述], [风格描述], 
[人物互动（可选）], [色调], professional photography, 
editorial quality, natural composition"

示例（办公室场景）：
"Modern LED panel lights installed in a contemporary open-plan office, 
warm neutral color temperature 4000K, 
employees working at standing desks, 
large windows with natural daylight blending, 
Scandinavian interior design, clean lines, 
professional architectural photography, wide angle"

按行业场景库：
├── 消费电子：极简桌面/通勤场景/家庭使用/健身房
├── 家居：北欧客厅/日式卧室/美式厨房/户外花园
├── 服装：城市街拍/海滩度假/办公室/健身房
├── 工业品：工厂车间/建筑工地/实验室/仓库
├── 美妆：化妆台/浴室/自然光肖像
├── 食品：厨房操作台/餐桌/野餐/咖啡厅
└── 汽配：车库/赛道/4S 店/改装场景
```

#### Banner Prompt

```
Banner 背景生成模板：
"Abstract [风格] background for web banner, 
[品牌色] color scheme, [纹理/元素], 
wide format 1920x460px composition, 
subtle gradient, professional, modern, clean, 
space for text on [左/右/中]"

示例（科技蓝 Banner 背景）：
"Abstract technology background for web banner, 
deep navy blue to electric blue gradient, 
subtle circuit board patterns and light particles, 
wide panoramic composition 4:1 ratio, 
clean negative space on left for text overlay, 
futuristic, premium, corporate"

文字叠加（后期 Canva/PS 加）：
├── 主标题：品牌口号/活动主题（字号最大）
├── 副标题：核心卖点/优惠信息
├── CTA 按钮：行动号召
├── 产品图：叠加在右侧/中间
└── 认证/信任徽章：底部或角落
```

#### 节日活动图 Prompt

```
全年节日日历 + Prompt：

| 节日 | 时间 | Prompt 关键词 | 配色 |
|---|---|---|---|
| 新年 | 1/1 | fireworks, champagne gold, celebration | 金+黑+白 |
| 情人节 | 2/14 | red roses, hearts, romantic | 红+粉+白 |
| 斋月 | 3-4 月 | crescent moon, lanterns, stars | 金+深紫+绿 |
| 复活节 | 3-4 月 | pastel colors, eggs, spring flowers | 粉+绿+淡黄 |
| 开斋节 | 斋月后 | golden ornaments, family celebration | 金+绿 |
| 母亲节 | 5/第2周日 | flowers, warm family, elegant | 粉+紫+白 |
| 黑五 | 11/最后周五 | bold black, neon highlights, SALE | 黑+黄+红 |
| 网一 | 黑五后周一 | digital/tech aesthetic, cyber | 黑+蓝+霓虹 |
| 圣诞 | 12/25 | Christmas tree, snow, red ribbon | 红+绿+金 |
| 双 11 | 11/11 | 中国风+全球化混搭 | 红+橙 |

通用节日 Prompt：
"[节日] themed promotional banner background, 
[节日元素] decorations, [配色] color scheme, 
festive atmosphere, commercial quality, 
space for product placement and text overlay, 
wide format for web banner"
```

---

### Phase 4：后期处理 SOP

```
AI 生图后必须做的 5 步后期：

Step 1：产品替换/合成
├── AI 生成的"产品"通常不准确 → 必须用真实产品图替换
├── 工具：Photoshop（图层蒙版）/ Canva（拖拽叠加）
├── 关键：光线方向一致 + 透视一致 + 阴影自然
└── 常见错误：产品光从左边打，场景光从右边 → 假

Step 2：尺寸裁切
├── 按目标平台规格裁切
│   阿里主图：800×800 1:1
│   Amazon 主图：1000×1000 1:1（最大 10000×10000）
│   Banner：1920×460 / 3000×600
│   TikTok 封面：1080×1920 9:16
│   Instagram：1080×1080 1:1
│   LinkedIn：1200×627 1.91:1
└── 导出时分辨率 ≥ 72 dpi（Web）/ ≥ 300 dpi（打印）

Step 3：色彩校正
├── 确保产品颜色与实物一致（色差 = 退货）
├── 白底图检查：背景是否真正 #FFFFFF（不是灰白）
├── 品牌色统一：所有素材用同一套色值
└── 工具：PS Camera Raw / Lightroom / Snapseed

Step 4：文字排版（Banner/活动图）
├── 字体选择：无衬线字体为主（Montserrat/Open Sans/Poppins）
├── 层级：主标题 > 副标题 > CTA > 细节
├── 可读性：文字和背景对比度 ≥ 4.5:1
├── 多语言：预留文字膨胀空间（德语比英语长 30%）
└── 工具：Canva / Figma / PS

Step 5：文件优化
├── 格式：JPG（照片/场景）/ PNG（透明底/图标）/ WebP（网页最优）
├── 文件大小：主图 ≤ 300KB / Banner ≤ 500KB
├── 命名：{product}-{type}-{market}-{size}.jpg
│   示例："led-panel-hero-us-800x800.jpg"
├── ALT Text：写清楚图片内容（SEO + 无障碍）
└── 批量压缩：TinyPNG / Squoosh / ImageOptim
```

---

### Phase 5：行业视觉风格库

```
7 大外贸行业视觉风格指南：

| 行业 | 主色调 | Prompt 风格关键词 | 禁忌 |
|---|---|---|---|
| 消费电子 | 黑+白+蓝 | minimalist, tech, futuristic, gradient | 杂乱背景 |
| 家居 | 大地色+暖色 | cozy, Scandinavian, natural light, wood | 冷色调 |
| 服装 | 品牌色+中性 | fashion editorial, lifestyle, urban | 过度后期 |
| 机械 | 深蓝+银灰 | industrial, precision, metallic, close-up | 卡通风格 |
| 美妆 | 柔粉+金 | luxury, glossy, macro, skincare texture | 暗色系 |
| 食品 | 绿+原木+暖 | fresh, organic, farm-to-table, appetizing | 冷色+工业感 |
| 汽配 | 黑+红+碳纤维 | motorsport, performance, studio lighting | 廉价感 |

品牌一致性规则：
├── 所有素材使用统一品牌色（主色+辅色+中性色）
├── 字体统一（标题字体+正文字体，不超过 2 种）
├── 图片风格统一（同一个 Prompt 风格模板）
├── LOGO 大小和位置统一
└── 形成视觉识别系统 → 买家看到就知道是你
```

---

## 3 档方案

| 项目 | 🟢 AI 自助版 ¥0 | 🟡 AI+设计师 ¥500-2000 | 🔴 品牌视觉包 ¥5000+ |
|---|---|---|---|
| 工具 | QoderWork+Canva 免费 | Midjourney+PS | Adobe 全套+定制 |
| 白底图 | AI 抠图+白底 | 专业棚拍+修图 | 专业棚拍+修图 |
| 场景图 | AI 生成+产品合成 | AI 生成+精修 | 实景拍摄/3D 渲染 |
| Banner | Canva 模板 | 定制设计 3 版 | 品牌视觉系统 |
| 节日图 | AI+Canva 改文字 | 定制 6 节日 | 全年 12 节日定制 |
| 数量 | 10 张/月 | 30 张/月 | 无限量 |
| 适合 | 新卖家/预算极低 | 成长期 | 品牌化运营 |

---

## Kill List

1. **Kill AI 直出不修图** — AI 生成的产品图 100% 不准确，必须用真实产品图替换；直接用 AI 产品图 = 客户收到实物不一样 = 退货
2. **Kill 过度 PS** — 产品颜色调得太鲜艳/场景过于完美 = 客户期望过高 = 高退货率 + 差评
3. **Kill 忽略尺寸规范** — 800×800 的图传到 Amazon 会模糊；3000×600 的 Banner 传阿里会变形
4. **Kill 无版权意识** — AI 生成图的商用版权政策各平台不同；Midjourney 付费版可商用，免费版不行
5. **Kill 文字全堆在图上** — Banner 上放 30 个词 = 没人读；移动端看全是蚂蚁字 = 白做
6. **Kill 不压缩图片** — 3MB 的图传上去加载 5 秒 = 买家跑了；500KB 以内是底线

---

## 诚实提醒

```
⚠️ 诚实提醒 — 请务必阅读

1. AI 生图不能替代产品实拍：白底主图必须是真实产品照片，
   AI 只能做辅助（背景替换/场景合成/Banner 背景）。
   
2. 产品颜色必须和实物一致：过度调色 = 退货+差评+纠纷。
   电子屏幕有色差，但人为美化 ≠ 色差。
   
3. AI 生成的"人物"要谨小慎微：AI 人脸可能侵犯肖像权，
   用在商业素材前确认平台政策。建议用背影/手部/侧面。
   
4. 先有品牌风格，再有素材：没有品牌色+字体+视觉规范
   就开始出图 = 每张图风格不一 = 看起来像杂牌。
   
5. 好图片的标准是"买家想点进去"，不是"设计师觉得好看"。
   外贸图片的唯一 KPI = 点击率+转化率。
```

---

## Excel 报告详设（12 sheet）

| Sheet | 内容 | 关键列 |
|---|---|---|
| 1-素材需求清单 | 按产品×平台×类型 | 产品/平台/图片类型/尺寸/数量/优先级 |
| 2-Prompt 模板库 | 5 类×行业 | 类型/行业/Prompt/参数/示例图 |
| 3-白底图规范 | 拍摄+后期标准 | 产品/角度/光线/背景色/尺寸/文件名 |
| 4-场景图方案 | 场景×产品 | 产品/场景/Prompt/合成方法/参考图 |
| 5-Banner 设计 | 首页+活动 | 用途/尺寸/文案/品牌色/CTA |
| 6-节日活动日历 | 全年 12 个节日 | 月份/节日/市场/设计风格/Prompt/素材清单 |
| 7-平台尺寸速查 | 各平台规格 | 平台/位置/尺寸/格式/文件大小限制 |
| 8-工具选择 | AI 工具对比 | 工具/适合场景/价格/商用条件 |
| 9-后期 SOP | 5 步流程 | 步骤/工具/操作/检查项 |
| 10-品牌视觉规范 | 色板+字体+风格 | 色值/字体/间距/排版规则 |
| 11-预算方案 | 3 档费用 | 项目/基础/专业/品牌/备注 |
| 12-诚实提醒 | Kill List + 版权 | 类型/具体项/风险/替代方案 |

---

## 上下游接口

| 方向 | Agent | 数据流 |
|---|---|---|
| ← 输入 | listing-master | 主图脚本 6 张 → 拍摄/生成指令 |
| ← 输入 | brand-positioning | 品牌色+视觉锤 → 设计规范 |
| ← 输入 | store-decoration | 店铺风格 → Banner 设计约束 |
| ← 输入 | video-script-creator | 视频截帧 → 静态素材 |
| → 输出 | listing-master | 主图成品 → 上架 |
| → 输出 | store-decoration | Banner 成品 → 店铺首页 |
| → 输出 | social-media-matrix | 社媒图 → 各平台发布 |
| → 输出 | edm-campaign | 活动图 → 邮件素材 |
| → 输出 | detail-page-7screen | 详情页配图 → 7 屏 |
