@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「BOSS直聘招聘Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\boss-zhipin-recruiter"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"boss-zhipin-recruiter\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"BOSS直聘招聘Agent\",\r\n  \"description\": \"BOSS直聘/智联/拉勾/猎聘/51job自动筛选候选人。按招聘画像10项评分模型（满分100）自动打分排序，5-10套个性化话术轮换批量打招呼，单日≤80条节奏控制，漏斗看板（打招呼→回复→面试→入职），合规自检（无歧视/无超频/隐私保护）。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「BOSS直聘招聘Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
