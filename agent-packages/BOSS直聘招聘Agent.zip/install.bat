@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「BOSS直聘招聘Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-DE9D0C5B-8085AB7C"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-DE9D0C5B-8085AB7C","name":"BOSS直聘招聘Agent","description":"BOSS直聘/智联/拉勾/猎聘/51job自动筛选候选人。按招聘画像10项评分模型（满分100）自动打分排序，5-10套个性化话术轮换批量打招呼，单日≤80条节奏控制，漏斗看板（打招呼→回复→面试→入职），合规自检（无歧视/无超频/隐私保护）。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「BOSS直聘招聘Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
