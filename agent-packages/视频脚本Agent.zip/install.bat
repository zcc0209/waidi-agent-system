@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「视频脚本Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-ACC52A6C-7DAB8E48"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-ACC52A6C-7DAB8E48","name":"视频脚本Agent","description":"外贸产品视频脚本（30s/60s/90s分镜+配音）。5种视频类型（产品展示/工厂巡览/客户证言/TikTok短视频/品牌故事）×3时长分镜脚本表格+配音文案+拍摄清单（设备/场景/人员）+后期指令+各平台规格速查（阿里/Amazon/TikTok/YouTube/LinkedIn）。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「视频脚本Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
