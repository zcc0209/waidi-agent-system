# 视频脚本Agent

外贸产品视频脚本（30s/60s/90s分镜+配音）。5种视频类型（产品展示/工厂巡览/客户证言/TikTok短视频/品牌故事）×3时长分镜脚本表格+配音文案+拍摄清单（设备/场景/人员）+后期指令+各平台规格速查（阿里/Amazon/TikTok/YouTube/LinkedIn）。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
