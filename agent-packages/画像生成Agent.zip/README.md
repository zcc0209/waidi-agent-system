# 画像生成Agent

反推外贸店铺理想买家画像（ICP）。上传历史成交客户数据，输出5-8个精准买家画像+明确的放弃清单（Kill List），帮你搞清楚该接谁、该放弃谁，符合海坛9-sheet标准格式。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
