@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「画像生成Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-471EB6DC-BC225B8A"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-471EB6DC-BC225B8A","name":"画像生成Agent","description":"反推外贸店铺理想买家画像（ICP）。上传历史成交客户数据，输出5-8个精准买家画像+明确的放弃清单（Kill List），帮你搞清楚该接谁、该放弃谁，符合海坛9-sheet标准格式。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「画像生成Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
