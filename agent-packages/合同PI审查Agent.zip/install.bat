@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「合同PI审查Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-213265D6-EB0AF010"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-213265D6-EB0AF010","name":"合同PI审查Agent","description":"外贸合同/PI/PO智能起草与风险扫描。输出标准PI模板（按客户类型）或对现有合同做红黄绿三级风险扫描：付款方式陷阱+INCOTERMS错配+不可抗力条款漏洞+违约责任不对等+知识产权归属+争议解决条款（仲裁地/适用法律），每项风险给出修改建议文本。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「合同PI审查Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
