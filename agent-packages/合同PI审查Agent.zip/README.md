# 合同PI审查Agent

外贸合同/PI/PO智能起草与风险扫描。输出标准PI模板（按客户类型）或对现有合同做红黄绿三级风险扫描：付款方式陷阱+INCOTERMS错配+不可抗力条款漏洞+违约责任不对等+知识产权归属+争议解决条款（仲裁地/适用法律），每项风险给出修改建议文本。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
