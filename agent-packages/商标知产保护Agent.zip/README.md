# 商标知产保护Agent

外贸商标与知识产权全球保护。提供商标全球申请路线（中美欧英+马德里130+国）、Nice 45类目防护策略、抢注5大预警、Amazon BR/阿里IPP/eBay VeRO 4大平台备案SOP、撤三异议进攻工具，让你的品牌资产零法律敞口。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
安装后完全退出 Accio Work 重新打开即可。
