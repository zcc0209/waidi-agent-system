@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「商标知产保护Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-F3AA112D-DEC4CCE9"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-F3AA112D-DEC4CCE9","name":"商标知产保护Agent","description":"外贸商标与知识产权全球保护。提供商标全球申请路线（中美欧英+马德里130+国）、Nice 45类目防护策略、抢注5大预警、Amazon BR/阿里IPP/eBay VeRO 4大平台备案SOP、撤三异议进攻工具，让你的品牌资产零法律敞口。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「商标知产保护Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
