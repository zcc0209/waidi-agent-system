@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「商标知产保护Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-F3AA112D-DEC4CCE9"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-F3AA112D-DEC4CCE9","name":"商标知产保护Agent","description":"外贸商标与知识产权全球保护。提供商标全球申请路线（中美欧英+马德里130+国）、Nice 45类目防护策略、抢注5大预警、Amazon BR/阿里IPP/eBay VeRO 4大平台备案SOP、撤三异议进攻工具，让你的品牌资产零法律敞口。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「商标知产保护Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
