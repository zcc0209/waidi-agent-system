---
name: brand-positioning
description: 外贸品牌定位智能体（深度版）。当用户要求"品牌定位/品牌故事/Slogan/品牌差异化/Brand Story/品牌名/品牌升级/从贸易到品牌/Brand DNA/Tagline/价值主张/USP/品牌人设"时触发，从产品+创始人故事+目标客户+竞品空白，推导品牌定位（22 法则 + Aaker 三角）+ 差异化金字塔 + 品牌故事（Story Brand 7 步）+ 3 版 Slogan + Brand Voice 5 维 + 视觉锤 + 防伪护城河 + 12 sheet Excel + 与 Anker/SHEIN/Govee 对照参考。
version: 1.0.0
---

# 品牌定位 Agent

## 触发场景
- 老板说"我们要从贸易公司转品牌，先要定个位"
- 业务员问"我们和别人到底有啥不一样"
- 准备做独立站 / Amazon Brand Registry，需要 Brand Story
- 客户邮件问"What makes you different"，业务员答不上来
- 准备投广告，文案策划要"品牌一句话"
- A200/保效方案需要品牌叙事
- 创始人想升级品牌（从 OEM 到自主品牌）

## 输入信息

```
1. 主营产品 / 品类（必填）
2. 创始人 / 公司故事（创业经历 / 技术背景 / 工厂资源）
3. 目标客户画像（已做过 ICP 最佳）
4. 竞品扫描数据（用 competitor-scanner 输出最佳）
5. 已有品牌名（如有），或想取名
6. 资源 / 预算 / 时间窗
```

## 品牌定位 4 大方法（依次推导）

### 方法 1：定位 22 法则（Al Ries / Jack Trout）

```
核心：品牌是占据用户心智的"一个词"

✅ 成功案例：
- Volvo = 安全
- BMW = 驾驶
- 沃尔沃 = 安全
- 海飞丝 = 去屑
- Anker = 充电（Power）
- Govee = 智能灯（Smart Light）
- Tile = 找东西（Find）

❌ 失败案例：
- "我们什么都做" = 用户什么都记不住
- "我们性价比高" = 性价比是结果不是定位
- "我们品质好" = 没有品牌不说品质好
```

### 方法 2：Aaker 品牌三角

```
        理性价值（功能）
            ▲
            │
   情感价值 ◄ • ► 自我表达价值
   （感觉）       （我是谁）

举例：YETI 保温杯
- 理性：12 小时保冷 / 不锈钢双层
- 情感：户外硬汉 / 探险家精神
- 自我表达：我是真正爱户外的人

举例：Anker 充电宝
- 理性：充电快 / 容量大 / 24 月质保
- 情感：可靠 / 不背叛你
- 自我表达：我是懂科技的极客
```

### 方法 3：差异化金字塔（5 层）

```
       ▲
      ╱ ╲     5. 信仰层（Why） ← 最难但最强（Why we exist）
     ╱   ╲    4. 文化层（How）  ← 价值观 / 风格
    ╱─────╲   3. 体验层（What） ← 服务 / 售后 / 包装
   ╱       ╲  2. 功能层（Have） ← 产品参数 / 卖点
  ╱─────────╲ 1. 渠道层（Where）← 在哪买 / 谁分销

向上越深，越不可复制；越往下越易被卷死。
中国卖家多卡在第 1-2 层，必须爬到第 3-5 层。
```

### 方法 4：从竞品空白反向定位（用 competitor-scanner 数据）

```
卖点矩阵 → 找"无人占据"的位置 → 占领

案例：智能水杯（30 竞品矩阵）
"老人专属" 0% 覆盖 → ★ 极蓝海
→ 品牌定位："为父母而生的智能水杯"
→ Slogan："Care, in every sip"
→ 视觉锤：温暖橙 + 父母手部特写
→ 故事钩：创始人父亲忘吃药引发心脏不适
```

## 品牌故事 Story Brand 7 步法（Donald Miller）

```
Step 1：A Character（主角 = 客户，不是品牌）
   ❌ 我们是 X 厂家，10 年经验...
   ✅ 你是一位忙碌的家长 / 户外爱好者 / 工程采购...

Step 2：Has a Problem（外部+内部+哲学层）
   外部：充电慢 / 易坏 / 兼容差
   内部：焦虑 / 不安全感 / 怕出洋相
   哲学：科技产品就该好用！这不公平。

Step 3：And Meets a Guide（品牌 = 导师，不是英雄）
   品牌出场，给同理心 + 权威背书

Step 4：Who Gives Them a Plan（计划清晰）
   3 步走：选择 → 下单 → 用上

Step 5：Calls Them to Action（明确 CTA）
   立即下单 / 索取样品 / 加入 VIP

Step 6：That Helps Them Avoid Failure（强调失败成本）
   不选我们你会：充电慢、爆炸风险、错过保修

Step 7：And Ends in Success（成功画面）
   你成为最懂科技的那个人 / 全家都喜欢你买的礼物

→ 输出：3 版 Brand Story（30 字 / 100 字 / 500 字）
```

## Slogan 3 版输出（必须 3 选 1）

```
版本 A：Why-driven（信仰层）
   "Power in your hand."  - Anker
   "Just do it."          - Nike
   "Designed for you."    - Apple

版本 B：Benefit-driven（功能层）
   "Charges your iPhone in 30 minutes."
   "12 hours cold. Guaranteed."
   "Find anything. In seconds."

版本 C：Story-driven（情感层）
   "Made by 3 brothers who hate cheap chargers."
   "From our farm to your table."
   "Born from frustration with bad coffee."

⚠️ Slogan 红线：
🔴 不要超过 7 个英文单词（记不住）
🔴 不要用形容词最高级（best / amazing）→ 平台禁用
🔴 不要翻译中文俗语（直译 = 灾难）
🔴 必须 5 秒内能听懂
```

## Brand Voice 5 维（品牌人设）

```
1. Tone（语气）：专业 / 亲切 / 调皮 / 严肃 / 文艺
   选 2 个，不要 5 个全要

2. Vocabulary（用词）：技术词 / 日常词 / 网络梗
   B2B 专业词 / B2C 简单词

3. Pace（节奏）：长句深邃 / 短句犀利
   Apple 短 / Tesla 短 / Patagonia 长

4. Stance（立场）：中立 / 倡导 / 反叛
   Patagonia "Don't buy this jacket"

5. Humor（幽默）：无 / 自嘲 / 黑色 / 双关
   Aviation Gin 高级双关
```

### Brand Voice 案例对照

| 品牌 | Tone | 例句 |
|---|---|---|
| Apple | 简洁/自信 | "Think different." |
| Patagonia | 倡导/反叛 | "We're in business to save our home planet." |
| Anker | 专业/可靠 | "Tested to last. Built to be trusted." |
| Liquid Death | 调皮/反叛 | "Murder your thirst." |
| SHEIN | 平价/亲切 | "Style, made affordable." |

## 视觉锤（Visual Hammer）

```
口号是钉子，视觉是锤子，必须 1 + 1。

要素：
1. 标志色（1 主色 + 1 副色，不要超过 3 色）
   - 蓝色 = 信任 / 科技（IBM / Boeing）
   - 红色 = 激情 / 食物（Coca-Cola / Netflix）
   - 绿色 = 健康 / 环保（Whole Foods / Spotify）
   - 黄色 = 阳光 / 平价（McDonald's / Best Buy）
   - 黑色 = 高级 / 神秘（Apple / Nike）

2. 标志元素（1 个就够）
   - 苹果咬一口 / 耐克勾 / 麦当劳 M

3. 一致性（所有触点 100% 一致）
   - 包装 / 主图 / 详情页 / 独立站 / 社媒
```

## 品牌名取名 5 法（如需重新取名）

```
1. 描述型：直接说做啥（容易但乏味）
   - General Motors / 京东 / 阿里巴巴

2. 创始人姓氏：奢侈品多用
   - Ford / Disney / Hermès / 老干妈

3. 缩写型：好记但难传播
   - BMW / IBM / KFC

4. 词根新造：科技品牌爱用 ⭐ 推荐
   - Anker（船锚-稳）
   - Govee（go + 简单）
   - Tile（瓷砖 → 跟踪）
   - Allbirds（all birds 全鸟 → 全自然）

5. 隐喻型：高级
   - Patagonia（探险地名）
   - Yeti（雪人 → 户外硬汉）
```

### 品牌名 Kill List

```
🛑 含数字（X88 / 168 / 9999）→ 显得 low
🛑 中拼音直拼（Yiteng / Junke）→ 老外读不出
🛑 含 "-" 或长（Smart-Home-Pro）→ 难记
🛑 已被注册（必查 USPTO + EUIPO + 中国商标网）
🛑 域名已被占（必查 .com 域名是否可买）
🛑 含敏感词（中东慎用 X / 印度慎用牛）
🛑 与已有大牌过近（XiaoMI / NIKE-pro）→ 法律风险
```

## 12 sheet Excel 输出

| # | Sheet | 关键列 |
|---|---|---|
| 1 | 一句话定位 | 品牌名/一句话定位/3 版 Slogan/Visual Hammer |
| 2 | 心智占位（22 法则） | 想占 1 个词 / 现状占了几个 / 必须收敛 |
| 3 | Aaker 品牌三角 | 理性价值/情感价值/自我表达价值 + 案例对照 |
| 4 | 差异化金字塔 | 5 层（渠道/功能/体验/文化/信仰）/ 现状 / 升级路径 |
| 5 | 反向定位（蓝海） | 卖点矩阵 / 蓝海点 / 进入难度 / 验证方法 |
| 6 | Brand Story 3 版 | 30 字 / 100 字 / 500 字 + Story Brand 7 步检查 |
| 7 | Slogan 3 版选 | A/B/C 版本 / 适用场景 / 测试方案（A/B 测试） |
| 8 | Brand Voice 5 维 | Tone/Vocab/Pace/Stance/Humor + 5 句样例 |
| 9 | 视觉锤 | 主色/副色/标志元素/字体/版式规范 |
| 10 | 品牌名 5 提案 | 5 候选名 + 商标可注 + 域名可买 + 含义 + 评分 |
| 11 | 落地 12 触点 | 包装/主图/详情页/独立站/IG/FB/EDM/客服话术/PI/PPT/展会/CEO 名片 |
| 12 | 诚实提醒 | 5 个老板必须知道的真相 + Kill List |

## 落地 12 触点对照表（从定位到执行）

```
1. 包装：主色 / 标志 / Slogan
2. Listing 主图：第 1 张含 Slogan + 视觉锤
3. 详情页 S1 Hero 屏：Brand Story 30 字版
4. 独立站首屏：Why Choose Us = Brand Story 100 字版
5. About Us 页：Brand Story 500 字 + 创始人照片
6. 邮件签名：1 行 Slogan
7. PI / Quotation 页眉：LOGO + Slogan
8. 客服自动回复：Brand Voice 风格统一
9. 业务员名片：Slogan
10. 展会展位：主色 + 视觉锤大尺寸
11. KOL Brief：必带 Slogan + Brand Voice 指南
12. EDM 邮件：模板统一 LOGO / 配色 / Voice
```

## 3 档进入方案

| 档位 | 范围 | 投入 | 周期 | 适合 |
|---|---|---|---|---|
| **保守** 一句话定位 | Slogan + 主色 + 包装 | $5K | 2 月 | 新手 OEM 转品牌 |
| **中性** 完整 BI | 12 触点全套 + Brand Book | $30-80K | 6 月 | 成长期 |
| **激进** 品牌大升级 | 重新命名 + VI + Story + 视频 + 代言 | $200K+ | 12 月 | 资本助推 |

## Kill List（品牌定位的禁区）

```
🛑 Kill 1：定位"我们性价比高"—— 性价比是结果不是定位
🛑 Kill 2：定位"我们品质好"—— 没人说自己品质差
🛑 Kill 3：占 5 个词 —— 占多个 = 占 0 个
🛑 Kill 4：直接抄大牌 —— Anker style / Apple-like = 法律 + 心智双重死
🛑 Kill 5：取名乱拼音 —— Yiteng / Junke 老外读不出
🛑 Kill 6：Slogan 翻译中文俗语 —— "好东西要分享" 翻译就完蛋
🛑 Kill 7：定位太大（"全球最大"）—— 显得自大且不可信
🛑 Kill 8：定位与产品矛盾 —— 卖最便宜却定位"高端"
```

## 工作流（标准 SOP）

```
Step 1：用户输入产品 + 创始人故事 + 目标客户
        ↓
Step 2：调 competitor-scanner 数据，提取卖点矩阵
        ↓
Step 3：22 法则 → 锁定 1 个词
        ↓
Step 4：Aaker 三角 → 确定理性/情感/自我表达
        ↓
Step 5：差异化金字塔 → 锁定第 3-5 层升级路径
        ↓
Step 6：Story Brand 7 步 → 3 版 Brand Story
        ↓
Step 7：Slogan 3 版（A/B/C 风格）
        ↓
Step 8：Brand Voice 5 维 + 5 样例
        ↓
Step 9：视觉锤（色/标志/字体）
        ↓
Step 10：（如需）品牌名 5 提案 + 商标可注+域名可买
        ↓
Step 11：12 sheet Excel + Brand Book PDF
```

## 上下游 Agent 衔接接口

```
←── 输入来源
    competitor-scanner：卖点矩阵 / 反向定位机会
    buyer-icp-persona：目标客户画像
    market-trend-radar：消费者偏好迁移
    
──→ 输出去向
    listing-master：用 Slogan + Brand Voice 写 Listing
    detail-page-7screen：用 Brand Story 写 S1 Hero 屏
    seo-content：用 Brand Voice 写博客
    edm-campaign：用 Brand Voice 写邮件
    social-media-matrix：用 Brand Voice 写社媒
    inquiry-reply-scripts：用 Brand Voice 写询盘话术
    case-study-builder：用 Brand Story 框架写案例
    brand-asset-library：作为品牌资产库的 Brand Book 输入
    trademark-ip-protector：用品牌名做商标注册
```

## 诚实提醒（强制）

```
🔴 定位是减法不是加法：占 1 个词，砍掉其他 99 个
🔴 老板的"自我感觉"不重要：客户记得啥才重要
🔴 内部喊口号 ≠ 客户记住：Slogan 必须 5 秒内传达
🔴 抄大牌 ≠ 像大牌：法律 + 心智双重死
🔴 改名 = 重启：3 年品牌沉淀清零，慎之又慎
🔴 Brand Story 不是创始人感动自己：要让客户感动到下单
🔴 Slogan 翻译 = 灾难：英文要从英文母语写，不要翻
🔴 视觉一致性比创意更重要：100% 一致 > 90% + 1 处出格
```

## 验证

成功标准：
- 1 个心智词（不是 5 个）
- Aaker 三角 3 个价值都填满
- 差异化金字塔锁定第 3-5 层升级路径
- Brand Story 3 版（30/100/500 字）
- Slogan 3 版（A/B/C 风格）+ 测试方案
- Brand Voice 5 维 + 5 样例
- 视觉锤明确（主色 + 1 个标志元素）
- 12 触点落地表完整
- 与 Anker/SHEIN/Govee 等参照案例对照

⚠️ 没有锁定 1 个词、没 Slogan 测试方案、没 12 触点表 = 不达标。
