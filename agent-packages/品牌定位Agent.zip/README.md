# 品牌定位Agent

外贸品牌定位（深度版）。22法则+Aaker三角推导品牌定位+差异化金字塔+Brand Story 7步结构+3版Slogan（保守/标准/激进）+Brand Voice 5维（专业度/亲和力/勇气/活力/温度）+视觉锤+防伪护城河+与Anker/SHEIN/Govee对照参考+12 sheet Excel。

**Windows：** 双击 install.bat
**Mac：** 终端执行 bash deploy.sh
