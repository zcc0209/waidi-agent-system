# 品牌定位Agent

外贸品牌定位（深度版）。22法则+Aaker三角推导品牌定位+差异化金字塔+Brand Story 7步结构+3版Slogan（保守/标准/激进）+Brand Voice 5维（专业度/亲和力/勇气/活力/温度）+视觉锤+防伪护城河+与Anker/SHEIN/Govee对照参考+12 sheet Excel。

分类：其他
创建时间：2026-06-17

## 使用方法
1. 在 Accio Work 中新建智能体
2. 将本包内的 SOUL.md 内容粘贴为智能体的 System Prompt
3. 安装 skills/ 目录下的技能包
