@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「品牌定位Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-B3D50A9D-0A9D51C7"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-B3D50A9D-0A9D51C7","name":"品牌定位Agent","description":"外贸品牌定位（深度版）。22法则+Aaker三角推导品牌定位+差异化金字塔+Brand Story 7步结构+3版Slogan（保守/标准/激进）+Brand Voice 5维（专业度/亲和力/勇气/活力/温度）+视觉锤+防伪护城河+与Anker/SHEIN/Govee对照参考+12 sheet Excel。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「品牌定位Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
