# 客户背调Agent

外贸客户深度背调。提供买家邮箱/公司名/网站，自动抓取官网+LinkedIn+新闻，输出公司画像卡：业务模式、规模、估算采购量、关键决策人、合作匹配度、风险信号，大单签约前必备。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
