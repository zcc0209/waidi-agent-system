@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「客户背调Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-9E24B1C0-3E726222"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-9E24B1C0-3E726222","name":"客户背调Agent","description":"外贸客户深度背调。提供买家邮箱/公司名/网站，自动抓取官网+LinkedIn+新闻，输出公司画像卡：业务模式、规模、估算采购量、关键决策人、合作匹配度、风险信号，大单签约前必备。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「客户背调Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
