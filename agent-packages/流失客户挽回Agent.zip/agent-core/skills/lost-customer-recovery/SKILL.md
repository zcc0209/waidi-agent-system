---
name: lost-customer-recovery
description: 外贸流失客户智能挽回。当用户要求"挽回客户/老客户唤醒/沉睡客户/流失客户/客户激活/dormant customer/win back"时触发，按"流失时长×客户价值×流失原因"三维聚类输出挽回名单优先级+4种挽回策略（调研型/利益型/关系型/刺激型）+6阶段触达节奏+8套话术模板+挽回 ROI 预测+Kill List（确认放弃名单）。
version: 1.0.0
---

# 流失客户挽回 Agent

## 触发场景
- 老客户突然不下单 3-6 个月
- CRM 里几百个"曾经询盘但没成交"的客户在睡觉
- 业务员离职后客户跟丢
- 年底/季度末业绩压力大需要"捡回失单"
- 新业务员需要"启动单"，捡老盘活

## 输入

必需：
- 流失客户清单（含：客户名/最后联系日期/最后状态/最后产品/最后金额）

可选：
- 流失原因（如已知）
- 客户类型/国家
- 历史成交总额（用于价值评估）
- 业务员（用于派单）

## 三维聚类分级

### 维度 1: 流失时长

| 时长 | 状态名 | 挽回难度 | 推荐策略 |
|---|---|---|---|
| 7-30 天 | 短期冷却 | 易 | 利益型 + 强制 CTA |
| 30-90 天 | 中期沉睡 | 中 | 关系型 + 案例触发 |
| 90-180 天 | 长期沉睡 | 中难 | 调研型 + 新品/新政策切入 |
| 180-365 天 | 深度流失 | 难 | 调研型主导 + 利益重启 |
| 365 天+ | 战略流失 | 极难 | 关系型 + 重新建联 |

### 维度 2: 客户价值

| 价值等级 | 标准 | 投入资源 |
|---|---|---|
| 钻石 | 历史成交>$100K 或 L4 集团 | 老板亲自挽回 + 视频会议 + 工厂参观 |
| 金 | 历史成交 $30-100K 或 L3 品牌 | 业务经理挽回 + 定制方案 |
| 银 | 历史成交 $10-30K 或 L2 批发 | 资深业务员挽回 + 标准利益包 |
| 铜 | 历史成交<$10K 或 L1 小卖 | 群发邮件 + 自助下单链接 |

### 维度 3: 流失原因（聚类 8 类）

1. **价格 Price** → 让步空间挽回（关联 negotiation-coach）
2. **质量 Quality** → 升级+整改证明+第三方检测报告
3. **交期 Lead Time** → 提速方案+海外仓+空运备选
4. **服务 Service** → 道歉+换业务员+总经理介入
5. **认证 Cert** → 补证明+新增认证清单
6. **MOQ** → 小批量试单+组合订单
7. **付款 Payment** → 信保+OA 试水
8. **项目暂停 Pause** → 行业新闻保持联系，待项目重启
9. **去了竞品 Switched** → 调研为什么换，对症下药
10. **不明 Unknown** → 调研型话术为主

## 4 种挽回策略

### 策略 A: 调研型（最有效，80%+ 客户会回）
**核心**：不推销，问原因
**适用**：流失原因不明的所有客户
**话术骨架**：
```
Hi [Name],
[Time period] ago we worked on [project/order], and then things went quiet.
No sales pitch this time — I genuinely want to understand:
- Was it a price/quality/timing issue?
- Did you find a better solution elsewhere?
- Or did the project pause?
Your honest feedback (even if harsh) helps me serve clients like you better.
```
**预期**：60% 回复，30% 重启对话，10% 直接成单

### 策略 B: 利益型（短期冷却最有效）
**核心**：限时优惠+老客户专属
**适用**：流失 7-90 天 + 价格敏感客户
**话术骨架**：
```
Hi [Name],
We've just released our Q[X] pricing for returning customers like you:
- 5% off your previous unit price
- Free sample for any new SKU
- Lead time reduced from [X] to [Y] days
Valid only for 14 days, exclusive for past customers.
Reply if interested, no pressure.
```

### 策略 C: 关系型（高价值客户最有效）
**核心**：节日问候+行业新闻+案例分享，不卖东西
**适用**：钻石/金客户 + 流失>90 天
**话术骨架**：
```
Hi [Name],
Hope you and the team had a great [holiday/quarter].

Wanted to share — we just shipped a 10K-unit order to [similar brand in
their region], achieving [specific result]. Their full case study attached.

Not pitching anything. Just thought you'd find it useful given your work
on [their product line].

Always here if you want to grab a virtual coffee.
```

### 策略 D: 刺激型（项目重启信号客户最有效）
**核心**：新品/新政策/新市场切入
**适用**：长期沉睡 + 已知客户行业有新动作
**话术骨架**：
```
Hi [Name],
Noticed [industry news / their new product / regulation change].

We've just developed [new product/feature] specifically for this. It might
or might not fit your roadmap — happy to send a 1-pager if curious.
```

## 6 阶段触达节奏

```
Day 0: 首封挽回邮件（按策略 A-D）
Day 7: 跟进 1（换角度，强化价值，禁止"following up"）
Day 14: 跟进 2（换渠道：邮件 → LinkedIn / WhatsApp）
Day 30: 跟进 3（换人：老板/经理署名）
Day 60: 最终触达（明说"如果不感兴趣告诉我一声，我就不再打扰"）
Day 90: 归档进 Kill List 或转策略 C 长线关系养护
```

## 工作流

### Step 1: 客户清单梳理与三维打标
- 接收清单 → 按流失时长 × 价值 × 原因三维聚类
- 计算每个客户的"挽回优先级分数"：
  优先级 = 价值权重(40%) × (1/流失时长) × 原因可挽回度(0-1)

### Step 2: 挽回名单按优先级排序

```
═══ 挽回名单 Top 50 ═══
🥇 P1 优先（10 个，本周必须触达）：
- [客户A] 钻石/流失 45 天/价格原因 → 策略 B + 老板亲自发
- [客户B] 金/流失 60 天/服务原因 → 策略 A + 换业务员
...

🥈 P2 重点（20 个，本月触达）：
...

🥉 P3 常规（20 个，下月触达）：
...
═══════════════
```

### Step 3: Kill List 输出（确认放弃名单）

明确"不再挽回"的客户类型：
- 已明确去了竞品且无回头意愿（说"已签长期合同"）
- 历史投诉记录+恶意压价的（合作了亏更多）
- 流失>2 年且无任何回应的（基本归零）
- 国家进入制裁名单（合规风险）

每条 Kill List 写明"为什么放弃"+"如何释放业务员精力到 P1 名单"

### Step 4: 个性化话术生成
- 每个 P1 客户生成 1 套定制话术（不是模板套）
- P2-P3 用半定制话术（模板+客户名+历史订单）
- Kill List 不发触达，直接归档

### Step 5: 挽回 ROI 预测

```
═══ 挽回 ROI 预测 ═══
P1 名单（10 客户）：
- 预期回复率 60%（6 个回复）
- 预期重启对话率 30%（3 个进入谈判）
- 预期成单率 10%（1 个签约）
- 平均订单金额 $30K → 预期回收 $30K

P1+P2+P3 合计预测回收：$150K-200K
业务员投入：约 30 小时（话术编写+触达+跟进）
ROI：约 $5K/小时
═══════════════
```

### Step 6: 跟进执行表（派单）

| 客户 | 业务员 | 策略 | Day 0 话术 | Day 7 跟进 | Day 14 跟进 | Day 30 跟进 | 截止评估 |

输出 Excel，按业务员维度拆分，每个业务员一个 sheet。

## 注意事项

- **调研型最被低估**：很多业务员不敢问"为什么不买"，但这是最高 ROI 的话术，80% 客户会告诉你真原因
- **不要见客户就给优惠**：钻石客户用利益型会掉价感，要用关系型
- **节假日是挽回好时机**：圣诞/新年/春节客户心情松弛，回复率比平时高 30%
- **跨渠道触达提升 3x**：只发邮件回复率 15%，邮件+LinkedIn+WhatsApp 三管齐下回复率 45%+
- **换人 = 换关系**：原业务员可能就是流失原因，换人挽回比同人挽回成功率高 2x
- **去 AI 化**：话术里不要"We value our partnership"，直接"Wanted to be honest — we miss working with you, and I'd love to know what we could have done differently"
- **Kill List 要勇敢放弃**：业务员精力有限，把 P1 的 10 个客户做透比挽回 100 个回不来的强
- **挽回不是给折扣**：折扣是最后一招；优先解决原始流失原因（如服务问题→换业务员，质量问题→给整改证明）

## 验证

- 挽回名单是否真按"价值×可挽回度"排序（不是按流失时间）
- 每个 P1 客户是否有"针对性原因+针对性策略"（不是套模板）
- Kill List 是否敢于"明确放弃"（不是留着浪费业务员精力）
- ROI 预测是否给出"具体回收预期"（不是"提升成单率"这种废话）
- 话术是否"去 AI 化"且体现"客户名+历史订单"个性化
