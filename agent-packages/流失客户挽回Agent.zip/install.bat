@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   正在安装「流失客户挽回Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (echo [错误] 请先登录 Accio Work & pause & exit /b 1)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "DIR_NAME=%%~nxA"
    if /i "!DIR_NAME!" neq "guest" (
        set "TARGET=%%A\agents\DID-5DD0D11B-67DCEA4E"
        if not exist "!TARGET!" mkdir "!TARGET!"
        if exist "%~dp0agent-core" (xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1)
        (echo {"id":"DID-5DD0D11B-67DCEA4E","name":"流失客户挽回Agent","description":"外贸流失客户智能挽回。三维聚类（流失时长×客户价值×流失原因）输出挽回名单优先级+4种挽回策略（调研型/利益型/关系型/刺激型）+6阶段触达节奏+8套话术模板+挽回ROI预测+Kill List（确认放弃名单），让沉睡客户有序复活，不把资源浪费在不可挽回的客户身上。"}) > "!TARGET!\profile.jsonc"
        set /a installed+=1
        echo   [!installed!] 已安装到: !DIR_NAME!
    )
)
echo.
echo ================================================
echo   [完成] 「流失客户挽回Agent」已安装到全部 !installed! 个空间
echo ================================================
echo.
echo 请完全退出 Accio Work（右键任务栏图标 退出）
echo 重新打开后在左侧智能体列表找到它
echo.
pause
