@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「流失客户挽回Agent」到 Accio Work
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 请先打开并登录 Accio Work
    pause & exit /b 1
)
set installed=0
for /d %%i in ("%BASE%\*") do (
    set "TARGET=%%i\agents\DID-5DD0D11B-67DCEA4E"
    if not exist "!TARGET!" mkdir "!TARGET!"
    xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    powershell -Command "Set-Content -Path '!TARGET!\profile.jsonc' -Encoding UTF8 -Value '{"id":"DID-5DD0D11B-67DCEA4E","name":"流失客户挽回Agent","description":"外贸流失客户智能挽回。三维聚类（流失时长×客户价值×流失原因）输出挽回名单优先级+4种挽回策略（调研型/利益型/关系型/刺激型）+6阶段触达节奏+8套话术模板+挽回ROI预测+Kill List（确认放弃名单），让沉睡客户有序复活，不把资源浪费在不可挽回的客户身上。"}'"
    set /a installed+=1
    echo   已安装到 %%~nxi
)
echo.
echo [完成] 「流失客户挽回Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧找到智能体
echo.
pause
