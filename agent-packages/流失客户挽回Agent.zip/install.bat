@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo.
echo   安装「流失客户挽回Agent」到 Accio Work...
echo.
set "BASE=%USERPROFILE%\.accio\accounts"
if not exist "%BASE%" (
    echo [错误] 未找到 Accio Work，请先登录
    pause & exit /b 1
)
set installed=0
for /d %%A in ("%BASE%\*") do (
    set "ACCT_ID=%%~nxA"
    set "TARGET=%%A\agents\lost-customer-recovery"
    if not exist "!TARGET!" mkdir "!TARGET!"
    if exist "%~dp0agent-core" (
        xcopy /E /I /Y "%~dp0agent-core" "!TARGET!\agent-core\" >nul 2>&1
    )
    set "PROF=!TARGET!\profile.jsonc"
    powershell -NoProfile -Command "
        $content = @\"\r\n// Accio Agent config\r\n{\r\n  \"id\": \"lost-customer-recovery\",\r\n  \"accountId\": \"!ACCT_ID!\",\r\n  \"name\": \"流失客户挽回Agent\",\r\n  \"description\": \"外贸流失客户智能挽回。三维聚类（流失时长×客户价值×流失原因）输出挽回名单优先级+4种挽回策略（调研型/利益型/关系型/刺激型）+6阶段触达节奏+8套话术模板+挽回ROI预测+Kill List（确认放弃名单），让沉睡客户有序复活，不把资源浪费在不可挽回的客户身上。\",\r\n  \"model\": {\"provider\": \"auto\", \"name\": \"auto\"},\r\n  \"runtime\": \"local\",\r\n  \"creator\": \"user\",\r\n  \"agentType\": \"general\",\r\n  \"createdAt\": \"2026-01-01T00:00:00.000Z\"\r\n}\r\n\"@\r\n        Set-Content -Path '!PROF!' -Value $content -Encoding UTF8
    " 2>nul
    set /a installed+=1
    echo   已安装到 %%~nxA
)
echo.
echo [完成] 「流失客户挽回Agent」已安装到全部 %installed% 个空间
echo 请完全退出 Accio Work 后重新打开，左侧智能体列表查看
echo.
pause
