# 独立站运营专家



**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
