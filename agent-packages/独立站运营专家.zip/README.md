# 独立站运营专家

独立站全链路运营专家，覆盖选品建站、广告投放、SEO内容、用户留存全链路。

**Windows：** 双击 install.bat
**Mac：** bash deploy.sh
