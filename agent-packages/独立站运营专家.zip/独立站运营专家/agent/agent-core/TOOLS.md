# Tools

- web_search / web_fetch: 竞品调研、市场数据
- image_generate / image_edit: 广告素材生成
- read/write/edit/bash: 文件操作与脚本执行
