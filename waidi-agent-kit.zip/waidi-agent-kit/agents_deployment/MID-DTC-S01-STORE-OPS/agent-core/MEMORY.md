# 记忆
> `diary/...` 在日记来源中是 `agent-core/diary/` 下的本地文件，而非 URL；请勿通过 HTTP 获取。

## 日记来源
- 2026-06-23 完成数据追踪部署、转化优化及 SEO 基础配置。 [diary/2026-06-23.md](diary/2026-06-23.md)
- 2026-06-24 迁移至 GitHub + Netlify 架构并集成 Decap CMS。 [diary/2026-06-24.md](diary/2026-06-24.md)
- 2026-06-25 实现全站内容动态化联动，接入百度统计并启动博客自动化。 [diary/2026-06-25.md](diary/2026-06-25.md)
- 2026-06-26 成功执行首批 5 篇博客自动生成与百度推送。 [diary/2026-06-26.md](diary/2026-06-26.md)
- 2026-06-29 完成托管迁移至 Cloudflare Pages、上线中英双语切换及移动端全面优化。 [diary/2026-06-29.md](diary/2026-06-29.md)
- 2026-06-30 执行每日 SEO 博客自动化发布并推送百度收录。 [diary/2026-06-30.md](diary/2026-06-30.md)
- 2026-07-03 撰写 5 篇深度博客但因公司网络限制导致 Git 推送失败，代码暂存本地。 [diary/2026-07-03.md](diary/2026-07-03.md)
- 2026-07-06 更新 42 篇博客库并生成专属 AI 配图，因百度配额用尽转为手动提交 Google 收录。 [diary/2026-07-06.md](diary/2026-07-06.md)

## 🪪 个人信息
- **姓名**：朱潮潮
- **职位**：阿里巴巴国际站温州客户经理
- **联系方式**：186 6873 5837
- **核心职责**：负责温州地区供应商招募，运营招商落地页 `newsalibaba.com`

## 🌿 个人习惯与偏好
- **技术栈偏好**：采用静态站点生成（SSG）结合 Headless CMS（Decap CMS），托管平台已稳定迁移至 Cloudflare Pages。
- **内容创作原则**：坚持“去 AI 味”，以老板实战视角撰写博客（如关税新政、RFQ 技巧），严禁捏造询盘量等统计数据。
- **SEO/GEO 策略**：针对百度和 Google 双引擎优化，特别注重对豆包等国内 AI 爬虫的关键词埋点；每日早 8-10 点自动发布 5 篇 SEO 博客。
- **移动端设计标准**：参考 `yixingkuajing.com`，采用极简单列布局，底部固定双 CTA 栏；卡片尺寸严格对齐基准（`padding:16px 14px`，`min-height:160px`）。
- **多语言体验**：已实现全站中英双语切换，通过 JS 批量替换文本并利用 LocalStorage 记忆用户选择。
- **留资转化路径**：主 CTA 指向独立诊断页 `/consult` 或弹窗，集成 Server酱 实现微信实时通知，确保线索零遗漏。
- **网络环境约束**：公司网络存在 GitHub 443 端口拦截及 HTTP/2 兼容问题，推送代码时需使用 `-c http.version=HTTP/1.1` 参数或切换网络。
- **配图策略关注**：正在评估长期使用 AI 生成专属配图还是 Unsplash 免费图库，以平衡视觉效果与运营成本。

## 👥 人物与宠物
- **(none recorded)**

## 📈 财务与新闻兴趣
- **广告投放意向**：计划启动百度信息流广告，日预算设定为 50-100 元，用于获取初始精准流量。
- **关注领域**：温州产业带出口动态（乐清电气、永嘉泵阀、瑞安汽配）、国际贸易政策变化、跨境电商实战技巧。

---

## 🌐 网站项目：newsalibaba.com

### 核心架构
- **线上地址**：https://www.newsalibaba.com
- **GitHub 仓库**：`zcc0209/newsalibaba`（私有），分支 `main`
- **本地路径**：`~/Desktop/newsalibaba/`
- **托管平台**：Cloudflare Pages（替代原 Netlify，支持自动构建）
- **构建命令**：`node build.js`（读取 `blog/*.md` + `content/*.json` → 生成 `data.js` + 博客 HTML）
- **DNS**：阿里云域名，CNAME www → newsalibaba.pages.dev
- **git push 注意**：公司网络有时需加 `-c http.version=HTTP/1.1` 解决 HTTP/2 兼容问题

### CMS 后台
- **地址**：https://www.newsalibaba.com/admin/
- **系统**：Decap CMS，GitHub OAuth 认证
- **OAuth Worker**：`https://newsalibaba-oauth.1141424377.workers.dev`
- **GitHub OAuth**：Client ID `Ov23lihzbJeWZbir4NJA`
- **集合**：博客文章、国际站动态、贸易政策、商家故事、线下课程、FAQ、网站设置、Banner文案（共8类）

### 数据追踪
- GA4：`G-BVJ58GX6VS`
- Hotjar：`hjid:6735773`
- Contentsquare：`c097e2ce9b6b8`
- 百度统计：`3829de0ed40cd08b848d1dab5d5d9f4d`

### 表单 & 通知
- **主留资表单**：Formspree `mdardkvj`（提交后触发 Server酱 推送微信）
- **线下课程报名**：Formspree `xqevlaov`
- **微信推送**：Server酱 key `SCT372065TJJ4JDIpks2URwO0lVplOaLVB`，通知到 `1141424377@qq.com`

### AI 聊天框
- **通义千问**（Qwen）API，通过 Cloudflare Worker 代理
- **Worker 地址**：`https://newsalibaba-qwen.1141424377.workers.dev`
- **前端**：固定在页面右下角，`aiHistory` 保留最近8条上下文

### 内容文件结构
```
~/Desktop/newsalibaba/
├── index.html          # 主页（含所有CSS/JS，约3000行）
├── build.js            # 构建脚本
├── data.js             # 自动生成（勿手动改）
├── blog/               # .md 博客源文件 + 生成的 .html
├── blog.html           # 博客列表页（自动生成）
├── content/
│   ├── news/           # 国际站动态 JSON
│   ├── policy/         # 贸易政策 JSON
│   ├── stories/        # 商家故事 JSON
│   ├── faq/            # FAQ JSON
│   ├── courses/        # 线下课程 JSON
│   └── settings/       # site.json + banner.json
├── consult.html        # 留资诊断表单页（主CTA落地页）
├── courses.html        # 线下课程页
├── admin/
│   ├── index.html      # CMS 前端
│   └── config.yml      # Decap CMS 配置
└── images/             # 本地图片（wechat-qr.jpg 等）
```

### 自动化任务
- **每日博客**：定时任务（ID: `cron-1782377510080-d39zlb5k`），每天早8点自动生成5篇SEO博客并推送到GitHub
- **SEO收录**：百度已通过 meta tag 验证并主动推送（需注意配额限制）；Google需手动在GSC提交新博客URL

## ⚠️ 已知坑点（新会话务必注意）

1. **git push 失败**：公司网络 HTTP/2 有问题，加 `-c http.version=HTTP/1.1` 解决
2. **data.js 勿手改**：由 `node build.js` 自动生成，手改会被覆盖
3. **移动端CSS改动需谨慎**：曾因大范围 flex 覆盖导致全站布局崩溃，改完必须 git revert 保底
4. **CMS OAuth 域名**：config.yml 的 `base_url` 必须是 `1141424377.workers.dev`，不是 `zcc0209.workers.dev`
5. **商家故事卡片**：JS动态生成（inline style），CSS覆盖需用属性选择器 `[style*="..."]` 精准匹配
6. **博客定时任务**：需实际写文件到磁盘再 git commit，只在对话里输出内容不会上线
7. **统计数据真实性**：页面上所有数字（询盘量、企业数等）必须有据可查，不能捏造
