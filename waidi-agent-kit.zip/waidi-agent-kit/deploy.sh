#!/bin/bash
# ============================================================
# 外贸智能体一键部署脚本 (waidi-agent-kit deploy.sh)
# 版本：v1.0.0
# 功能：将9个外贸智能体一键部署到当前用户的 Accio 客户端
# 兼容：macOS（bash 3.2+），使用 plutil 注册智能体
# ============================================================

set -e

# 获取脚本所在的绝对路径（避免裸相对路径问题）
DEPLOY_SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENTS_SOURCE="$DEPLOY_SOURCE/agents_deployment"

# ──────────────────────────────────────────
# 颜色输出
# ──────────────────────────────────────────
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[OK]${NC}   $1"; }
log_warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error()   { echo -e "${RED}[ERR]${NC}  $1"; }

# ──────────────────────────────────────────
# 欢迎信息
# ──────────────────────────────────────────
echo ""
echo "========================================================"
echo "  🚀 外贸AI智能体一键部署系统"
echo "     waidi-agent-kit v1.0.0"
echo "========================================================"
echo ""

# ──────────────────────────────────────────
# Step 1: 检测 Accio 账户目录
# ──────────────────────────────────────────
log_info "正在检测 Accio 账户..."

ACCIO_BASE="$HOME/.accio/accounts"

if [ ! -d "$ACCIO_BASE" ]; then
  log_error "未找到 Accio 账户目录：$ACCIO_BASE"
  echo "请确认已安装并登录过 Accio 客户端，然后重试。"
  exit 1
fi

# 自动检测账户ID（取第一个数字命名的目录）
ACCOUNT_ID=""
for dir in "$ACCIO_BASE"/*/; do
  dirname=$(basename "$dir")
  if echo "$dirname" | grep -qE '^[0-9]+$'; then
    ACCOUNT_ID="$dirname"
    break
  fi
done

if [ -z "$ACCOUNT_ID" ]; then
  log_error "无法自动检测账户ID。请手动输入："
  read -r -p "账户ID（纯数字，如 1760471906）: " ACCOUNT_ID
fi

ACCIO_ROOT="$ACCIO_BASE/$ACCOUNT_ID"
AGENTS_DIR="$ACCIO_ROOT/agents"
SIMOBIX_MAP="$ACCIO_ROOT/simobix_map.json"

log_success "检测到账户：$ACCOUNT_ID"
log_info "智能体目录：$AGENTS_DIR"

# ──────────────────────────────────────────
# Step 2: 确认部署
# ──────────────────────────────────────────
echo ""
echo "即将部署以下9个智能体："
echo "  ├── 新商选品美工 (MID-NEWBIZ-S01-PRODUCT-SELECT)"
echo "  ├── 新商供应链落地 (MID-NEWBIZ-S02-SUPPLIER)"
echo "  ├── 新商主图详情页 (MID-NEWBIZ-S03-LISTING)"
echo "  ├── 新商买家背调 (MID-NEWBIZ-S04-BUYER-CHECK)"
echo "  ├── 新商询盘诊断 (MID-NEWBIZ-S05-INQUIRY-DIAG)"
echo "  ├── 新商运营巡逻 (MID-NEWBIZ-S06-OPS-PATROL)"
echo "  ├── 独立站运营专家 (MID-DTC-S01-STORE-OPS)"
echo "  ├── 社媒运营文案专家 (MID-CN-S01-SOCIAL-MEDIA)"
echo "  └── 经营情报中心 (MID-MARKETINTEL-C7F0EB-0001-9A1B2C)"
echo ""
read -r -p "确认部署到账户 $ACCOUNT_ID？[Y/n] " confirm
confirm="${confirm:-Y}"
if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
  echo "已取消部署。"
  exit 0
fi

echo ""

# ──────────────────────────────────────────
# Step 3: 定义智能体列表（bash 3.2兼容写法）
# ──────────────────────────────────────────
AGENT_1_ID="MID-NEWBIZ-S01-PRODUCT-SELECT"
AGENT_1_NAME="新商选品美工"
AGENT_1_UUID="5d0b8cd632a841efbd6c5d9439586388"

AGENT_2_ID="MID-NEWBIZ-S02-SUPPLIER"
AGENT_2_NAME="新商供应链落地"
AGENT_2_UUID="af9277bf134e4d68b55d3d5733d2d77e"

AGENT_3_ID="MID-NEWBIZ-S03-LISTING"
AGENT_3_NAME="新商主图详情页"
AGENT_3_UUID="7f8cc6a84c67490ca98426a8b8c311d8"

AGENT_4_ID="MID-NEWBIZ-S04-BUYER-CHECK"
AGENT_4_NAME="新商买家背调"
AGENT_4_UUID="f0f8f71017454bc88523f3e24b0114a3"

AGENT_5_ID="MID-NEWBIZ-S05-INQUIRY-DIAG"
AGENT_5_NAME="新商询盘诊断"
AGENT_5_UUID="1f8ed7b05b2b4d928e30f9cc50c3c4dc"

AGENT_6_ID="MID-NEWBIZ-S06-OPS-PATROL"
AGENT_6_NAME="新商运营巡逻"
AGENT_6_UUID="4fbe8c371f5c4f2e81595711549c9101"

AGENT_7_ID="MID-DTC-S01-STORE-OPS"
AGENT_7_NAME="独立站运营专家"
AGENT_7_UUID="9685929e14f9420caca52aba22ac2b60"

AGENT_8_ID="MID-CN-S01-SOCIAL-MEDIA"
AGENT_8_NAME="社媒运营文案专家"
AGENT_8_UUID="473ab169303e437193ce9f267ce8d7c7"

AGENT_9_ID="MID-MARKETINTEL-C7F0EB-0001-9A1B2C"
AGENT_9_NAME="经营情报中心"
AGENT_9_UUID=""   # 无profile，仅复制agent-core

# ──────────────────────────────────────────
# Step 4: 复制智能体文件夹（函数）
# ──────────────────────────────────────────
deploy_agent() {
  local agent_id="$1"
  local agent_name="$2"
  local src="$AGENTS_SOURCE/$agent_id"
  local dst="$AGENTS_DIR/$agent_id"

  if [ ! -d "$src" ]; then
    log_warn "源文件不存在，跳过：$agent_id"
    return 1
  fi

  # 清理旧版本
  if [ -d "$dst" ]; then
    rm -rf "$dst"
    log_info "已清理旧版本：$agent_id"
  fi

  # 复制新版本
  cp -r "$src" "$dst"

  # 更新 profile.jsonc 中的 defaultProject.dir 为实际路径
  local profile="$dst/profile.jsonc"
  if [ -f "$profile" ]; then
    # 将空 dir 填入实际路径
    sed -i '' "s|\"dir\": \"\"|\"dir\": \"$dst/project\"|g" "$profile" 2>/dev/null || true
    # 更新 accountId（替换原始 accountId）
    sed -i '' "s|\"accountId\": \"[0-9]*\"|\"accountId\": \"$ACCOUNT_ID\"|g" "$profile" 2>/dev/null || true
  fi

  log_success "已部署：$agent_name ($agent_id)"
  return 0
}

log_info "开始复制智能体文件..."
echo ""

deploy_agent "$AGENT_1_ID" "$AGENT_1_NAME"
deploy_agent "$AGENT_2_ID" "$AGENT_2_NAME"
deploy_agent "$AGENT_3_ID" "$AGENT_3_NAME"
deploy_agent "$AGENT_4_ID" "$AGENT_4_NAME"
deploy_agent "$AGENT_5_ID" "$AGENT_5_NAME"
deploy_agent "$AGENT_6_ID" "$AGENT_6_NAME"
deploy_agent "$AGENT_7_ID" "$AGENT_7_NAME"
deploy_agent "$AGENT_8_ID" "$AGENT_8_NAME"

# MARKETINTEL 特殊处理（只有 agent-core，无 profile.jsonc）
MARKETINTEL_SRC="$AGENTS_SOURCE/MID-MARKETINTEL-C7F0EB-0001-9A1B2C"
MARKETINTEL_DST="$AGENTS_DIR/MID-MARKETINTEL-C7F0EB-0001-9A1B2C"
if [ -d "$MARKETINTEL_SRC" ]; then
  mkdir -p "$MARKETINTEL_DST"
  cp -r "$MARKETINTEL_SRC/agent-core" "$MARKETINTEL_DST/"
  log_success "已部署：$AGENT_9_NAME ($AGENT_9_ID)"
fi

echo ""

# ──────────────────────────────────────────
# Step 5: 注册到 simobix_map.json
# ──────────────────────────────────────────
log_info "正在注册智能体到系统索引..."

register_agent() {
  local agent_id="$1"
  local agent_uuid="$2"

  if [ -z "$agent_uuid" ]; then
    return 0  # 跳过无UUID的智能体
  fi

  # 使用 plutil 安全注入键值（macOS 原生，幂等操作）
  if command -v plutil &> /dev/null; then
    # 转换为 JSON 格式操作
    python3 -c "
import json, os

map_file = '$SIMOBIX_MAP'
agent_id = '$agent_id'
agent_uuid = '$agent_uuid'

# 读取现有 map
if os.path.exists(map_file):
    with open(map_file) as f:
        data = json.load(f)
else:
    data = {}

# 注入/更新
data[agent_id] = agent_uuid

# 写回
with open(map_file, 'w') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
" 2>/dev/null && log_success "已注册：$agent_id" || log_warn "注册失败（可能需要手动注册）：$agent_id"
  else
    log_warn "未找到 plutil，使用 Python fallback 注册：$agent_id"
  fi
}

register_agent "$AGENT_1_ID" "$AGENT_1_UUID"
register_agent "$AGENT_2_ID" "$AGENT_2_UUID"
register_agent "$AGENT_3_ID" "$AGENT_3_UUID"
register_agent "$AGENT_4_ID" "$AGENT_4_UUID"
register_agent "$AGENT_5_ID" "$AGENT_5_UUID"
register_agent "$AGENT_6_ID" "$AGENT_6_UUID"
register_agent "$AGENT_7_ID" "$AGENT_7_UUID"
register_agent "$AGENT_8_ID" "$AGENT_8_UUID"

echo ""

# ──────────────────────────────────────────
# Step 6: 安装分发器 Skill（agent-distributor）
# ──────────────────────────────────────────
log_info "正在安装智能体分发器技能..."

SKILL_SRC="$DEPLOY_SOURCE/agent-distributor"
SKILL_DST="$HOME/.accio/accounts/$ACCOUNT_ID/skills/agent-distributor"

if [ -d "$SKILL_SRC" ]; then
  mkdir -p "$SKILL_DST"
  cp -r "$SKILL_SRC/"* "$SKILL_DST/"

  # 注册到 skills_config.json
  SKILLS_CONFIG="$HOME/.accio/accounts/$ACCOUNT_ID/skills/skills_config.json"
  if [ -f "$SKILLS_CONFIG" ]; then
    python3 -c "
import json

config_file = '$SKILLS_CONFIG'
with open(config_file) as f:
    config = json.load(f)

skill_id = 'agent-distributor'
if 'skills' not in config:
    config['skills'] = {}
if skill_id not in config['skills']:
    config['skills'][skill_id] = {'enabled': True}
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    print('registered')
else:
    print('already exists')
" 2>/dev/null
  fi
  log_success "分发器技能已安装：agent-distributor"
else
  log_warn "未找到分发器技能文件，跳过"
fi

echo ""

# ──────────────────────────────────────────
# Step 7: 完成汇总
# ──────────────────────────────────────────
echo "========================================================"
echo -e "  ${GREEN}✅ 部署完成！${NC}"
echo "========================================================"
echo ""
echo "已成功部署的智能体："
echo "  ✅ 新商选品美工"
echo "  ✅ 新商供应链落地"
echo "  ✅ 新商主图详情页"
echo "  ✅ 新商买家背调"
echo "  ✅ 新商询盘诊断"
echo "  ✅ 新商运营巡逻"
echo "  ✅ 独立站运营专家"
echo "  ✅ 社媒运营文案专家"
echo "  ✅ 经营情报中心"
echo "  ✅ 智能体分发器（agent-distributor 技能）"
echo ""
echo "下一步："
echo "  1. 彻底退出并重启 Accio 客户端"
echo "  2. 在智能体列表中找到上述智能体"
echo "  3. 在任意智能体中输入你的需求，"
echo "     或在 Accio 助手中说「帮我推荐智能体」"
echo ""
echo "如遇问题，请检查 ~/.accio/accounts/$ACCOUNT_ID/agents/ 目录"
echo "========================================================"
